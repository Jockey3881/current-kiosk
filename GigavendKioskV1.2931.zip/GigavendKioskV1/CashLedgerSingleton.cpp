#include "CashLedgerSingleton.h"
#include <iostream>

// Initialize static members
std::unique_ptr<CashLedgerManager> CashLedgerSingleton::instance_ = nullptr;
std::mutex CashLedgerSingleton::mutex_;
bool CashLedgerSingleton::initialized_ = false;

CashLedgerManager* CashLedgerSingleton::Instance() {
    std::lock_guard<std::mutex> lock(mutex_);

    if (!initialized_ || !instance_) {
        std::cerr << "ERROR: CashLedgerSingleton not initialized! Call Initialize() first." << std::endl;
        return nullptr;
    }

    return instance_.get();
}

bool CashLedgerSingleton::Initialize(const std::string& machine_id,
                                     const std::string& server_url,
                                     const std::string& db_path) {
    std::lock_guard<std::mutex> lock(mutex_);

    if (initialized_) {
        std::cerr << "WARNING: CashLedgerSingleton already initialized. Ignoring duplicate Initialize() call." << std::endl;
        return true;
    }

    std::cout << "Initializing CashLedgerSingleton..." << std::endl;
    std::cout << "  Machine ID: " << machine_id << std::endl;
    std::cout << "  Server URL: " << server_url << std::endl;
    std::cout << "  Database: " << db_path << std::endl;

    // Create instance
    instance_ = std::make_unique<CashLedgerManager>(machine_id, server_url, db_path);

    // Initialize
    if (!instance_->Initialize()) {
        std::cerr << "ERROR: Failed to initialize CashLedgerManager" << std::endl;
        instance_.reset();
        return false;
    }

    initialized_ = true;
    std::cout << "✓ CashLedgerSingleton initialized successfully" << std::endl;

    return true;
}

void CashLedgerSingleton::Shutdown() {
    std::lock_guard<std::mutex> lock(mutex_);

    if (!initialized_) {
        return;
    }

    std::cout << "Shutting down CashLedgerSingleton..." << std::endl;

    // Destroy instance
    instance_.reset();
    initialized_ = false;

    std::cout << "✓ CashLedgerSingleton shut down" << std::endl;
}

bool CashLedgerSingleton::IsInitialized() {
    std::lock_guard<std::mutex> lock(mutex_);
    return initialized_ && (instance_ != nullptr);
}
