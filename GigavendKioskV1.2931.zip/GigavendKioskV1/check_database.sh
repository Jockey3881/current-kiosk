#!/bin/bash
# FIXED: Use the correct path found in logs
DB_PATH="$HOME/.local/share/Gigavend/GigavendKioskV1/ej.db"

echo "=== Cash Transactions ==="
sqlite3 "$DB_PATH" -header -column "SELECT transaction_uuid, source, total_amount, total_bills, status, timestamp FROM cash_transactions ORDER BY timestamp DESC LIMIT 5;"

echo ""
echo "=== Cassette Inventory ==="
sqlite3 "$DB_PATH" -header -column "SELECT cassette_number, denomination, current_count, (denomination * current_count) as value FROM cassette_config JOIN cassette_inventory USING (machine_id, cassette_number) WHERE machine_id='KIOSK-DEV-001' ORDER BY cassette_number;"

echo ""
echo "=== Total Cash Available ==="
sqlite3 "$DB_PATH" "SELECT SUM(denomination * current_count) as total_dollars FROM cassette_config JOIN cassette_inventory USING (machine_id, cassette_number) WHERE machine_id='KIOSK-DEV-001';"
