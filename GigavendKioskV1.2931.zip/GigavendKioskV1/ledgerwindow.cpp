#include "ledgerwindow.h"
#include "CashLedgerSingleton.h" // Links to the DB logic
#include "CashLedgerManager.h"
#include "LxGenDevAppManager.h"
#include "constants.h"
#include "LxGenDevCashDispenser.h"

#include <QDir>
#include <QFile>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <QMetaObject>
#include <QLocale>
#include <QStandardPaths>
#include <QVariantMap>
#include <QTextStream>
#include <QDateTime>
#include <QTimer>
#include <algorithm>
#include <QStringList>
#include <QDebug>

namespace {
QString fromCStr(const char *value)
{
    return value ? QString::fromUtf8(value) : QString();
}
}

LedgerWindow::LedgerWindow(QObject *parent)
    : QObject(parent)
    , m_cassettes(kCassetteSlots)
    , m_visible(false)
    , m_appActive(false)
{
    APPMGR_RegisterApp(LEDGER_APPID, LEDGER_APP_NAME);
    CDURegisterCallbackObject(this);
    CDURegCallbackDispenseCompleted(&LedgerWindow::on_CDU_DispenseCompleted);
    CDURegCallbackDispenseFailed(&LedgerWindow::on_CDU_DispenseFailed);

    m_logFilePath = resolveDispenseLogPath();
    startLogTail();

    // INITIAL LOAD FROM DB
    refreshFromDatabase();
}

LedgerWindow::~LedgerWindow()
{
    APPMGR_UnregisterApp(LEDGER_APPID);
}

void LedgerWindow::refreshFromDatabase()
{
    auto* clm = CashLedgerSingleton::Instance();
    if (!clm || !clm->IsInitialized()) {
        qWarning() << "[LedgerWindow] CashLedgerManager not ready.";
        return;
    }

    // CashLedgerManager is 1-based, m_cassettes is 0-based
    for (int i = 0; i < m_cassettes.size(); ++i) {
        int dbIndex = i + 1;
        m_cassettes[i].count = clm->GetCassetteCount(dbIndex);

        // Retrieve config to display correct denomination
        CassetteConfig config = clm->GetCassetteConfig(dbIndex);
        m_cassettes[i].denomination = config.denomination;
    }

    notifyDataChanged();
}

QString LedgerWindow::resolveDispenseLogPath() const
{
    const QString name = QStringLiteral("cdu_dispense.log");
    const QString cwd = QDir::currentPath();
    if (QFile::exists(QDir(cwd).filePath(name))) {
        return QDir(cwd).filePath(name);
    }
    return QDir(cwd).filePath(name);
}

bool LedgerWindow::isVisible() const { return m_visible; }

void LedgerWindow::setVisible(bool visible)
{
    if (m_visible == visible) return;
    m_visible = visible;
    if (m_visible) {
        refreshFromDatabase(); // Always fetch fresh data when opening window
    }
    emit visibleChanged();
}

QVariantList LedgerWindow::cassetteData() const {
    QVariantList list;
    list.reserve(m_cassettes.size());
    for (int i = 0; i < m_cassettes.size(); ++i) {
        QVariantMap map;
        map.insert(QStringLiteral("index"), i);
        map.insert(QStringLiteral("label"), cassetteLabel(i));
        map.insert(QStringLiteral("denomination"), m_cassettes.at(i).denomination);
        map.insert(QStringLiteral("count"), m_cassettes.at(i).count);
        map.insert(QStringLiteral("amount"), static_cast<qint64>(m_cassettes.at(i).denomination) * m_cassettes.at(i).count);
        list.push_back(map);
    }
    return list;
}

int LedgerWindow::totalBills() const {
    int total = 0;
    for (const auto &cassette : m_cassettes) total += cassette.count;
    return total;
}

qint64 LedgerWindow::totalAmount() const {
    qint64 total = 0;
    for (const auto &cassette : m_cassettes) {
        total += static_cast<qint64>(cassette.denomination) * cassette.count;
    }
    return total;
}

QString LedgerWindow::totalAmountFormatted() const {
    const QLocale locale;
    return locale.toCurrencyString(static_cast<double>(totalAmount()));
}

QString LedgerWindow::statusMessage() const { return m_statusMessage; }

void LedgerWindow::setCassetteCount(int index, int count)
{
    if (!isValidIndex(index)) return;
    if (count < 0) count = 0;

    auto* clm = CashLedgerSingleton::Instance();
    if (clm && clm->IsInitialized()) {
        // UPDATE DATABASE
        bool ok = clm->UpdateCassetteCount(index + 1, count, "KioskAdmin", "SET");
        if (ok) {
            m_cassettes[index].count = count;
            notifyDataChanged();
            updateStatusMessage(tr("Cassette %1 count set to %2").arg(index + 1).arg(count));
        } else {
            updateStatusMessage(tr("Failed to update database for Cassette %1").arg(index + 1));
        }
    } else {
        updateStatusMessage(tr("Cash Manager not available"));
    }
}

void LedgerWindow::adjustCassetteCount(int index, int delta)
{
    if (!isValidIndex(index) || delta == 0) return;

    // Use current UI value as base, then commit to DB via setCassetteCount
    int current = m_cassettes[index].count;
    int newCount = std::max(0, current + delta);

    setCassetteCount(index, newCount);
}

// ✅ FIXED: Now calls the Manager to write denomination to DB
void LedgerWindow::setCassetteDenomination(int index, int denomination)
{
    if (!isValidIndex(index)) return;
    if (denomination < 0) denomination = 0;

    auto* clm = CashLedgerSingleton::Instance();
    if (clm && clm->IsInitialized()) {
        // Call the Manager to write to DB
        bool ok = clm->UpdateCassetteDenomination(index + 1, denomination);
        if (ok) {
            m_cassettes[index].denomination = denomination;
            notifyDataChanged();
            updateStatusMessage(tr("Cassette %1 denomination updated to $%2").arg(index + 1).arg(denomination));
        } else {
            updateStatusMessage(tr("Failed to save denomination config to DB."));
        }
    } else {
        updateStatusMessage(tr("Cash Manager not available"));
    }
}

void LedgerWindow::on_btnKioskHome_clicked()
{
    APPMGR_NotifyInactiveApp(KIOSK_APPID, KIOSK_HOME_MODE);
}

void LedgerWindow::setAppActive(bool active)
{
    if (m_appActive == active) return;
    m_appActive = active;
    if (m_appActive) {
        refreshFromDatabase();
    }
}

void LedgerWindow::setActiveAppContext(const QString &appId, bool active)
{
    if (active) {
        if (m_activeDispenseAppId == appId) return;
        m_activeDispenseAppId = appId;
    } else if (m_activeDispenseAppId == appId) {
        m_activeDispenseAppId.clear();
    }
}

void LedgerWindow::handleDispenseCompleted(const QString &count, const QStringList &details, const QString &source)
{
    appendDispenseLog(source, count, details);
    updateStatusMessage(tr("Dispensed %1 notes from %2").arg(count, source));
    refreshFromDatabase(); // Sync UI with new DB state
}

void LedgerWindow::handleDispenseFailed(short reason, const QString &count, const QStringList &details, const QString &source)
{
    const QString tagged = QStringLiteral("FAILED:%1:%2").arg(source.isEmpty() ? QStringLiteral("Unknown") : source).arg(reason);
    appendDispenseLog(tagged, count, details);
    refreshFromDatabase(); // Ensure UI is consistent
}

void LedgerWindow::startLogTail()
{
    if (m_logTailTimer) return;
    m_logTailTimer = new QTimer(this);
    m_logTailTimer->setInterval(500);
    connect(m_logTailTimer, &QTimer::timeout, this, &LedgerWindow::processLogTail);

    QFile f(m_logFilePath);
    if (f.open(QIODevice::ReadOnly | QIODevice::Text)) {
        m_logReadPos = f.size();
        f.close();
    }
    m_logTailTimer->start();
}

void LedgerWindow::processLogTail()
{
    QFile f(m_logFilePath);
    if (!f.open(QIODevice::ReadOnly | QIODevice::Text)) return;

    if (m_logReadPos > f.size()) m_logReadPos = 0;
    if (!f.seek(m_logReadPos)) { f.close(); return; }

    QTextStream ts(&f);
    while (!ts.atEnd()) {
        ts.readLine();
    }
    m_logReadPos = f.pos();
    f.close();
}

void LedgerWindow::appendDispenseLog(const QString& source, const QString& count, const QStringList& details)
{
    QMutexLocker locker(&m_logMutex);
    QFile logFile(m_logFilePath);
    if (!logFile.open(QIODevice::WriteOnly | QIODevice::Append | QIODevice::Text)) return;

    QTextStream stream(&logFile);
    stream << QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss.zzz")
           << " | source=" << (source.isEmpty() ? QStringLiteral("Unknown") : source)
           << " | count="  << (count.isEmpty()  ? QStringLiteral("0")       : count);

    if (!details.isEmpty()) {
        stream << " | cassettes=" << details.join(QLatin1Char(','));
    }
    stream << '\n';
    stream.flush();
}

void LedgerWindow::applyDispenseDetails(const QStringList &details, const QString &source) {
    Q_UNUSED(details);
    Q_UNUSED(source);
}

bool LedgerWindow::isValidIndex(int index) const { return index >= 0 && index < m_cassettes.size(); }
void LedgerWindow::updateStatusMessage(const QString &message) { if (m_statusMessage == message) return; m_statusMessage = message; emit statusMessageChanged(); }
void LedgerWindow::notifyDataChanged() { emit cassetteDataChanged(); emit totalsChanged(); }

int LedgerWindow::parseDetailCount(const QString &value) {
    const QString trimmed = value.trimmed();
    if (trimmed.isEmpty()) return 0;
    bool ok = false;
    const int count = trimmed.toInt(&ok);
    return ok ? count : 0;
}

QString LedgerWindow::cassetteLabel(int index) const { return tr("Cassette %1").arg(index + 1); }

QString LedgerWindow::currentDispenseSource() const {
    if (m_activeDispenseAppId.isEmpty()) return tr("Unknown source");
    return friendlyAppName(m_activeDispenseAppId);
}

QString LedgerWindow::friendlyAppName(const QString &appId) const {
    if (appId == QLatin1String(ATM_APPID)) return tr("ATM");
    if (appId == QLatin1String(DISPENSE_APPID)) return tr("CDU Dispense");
    if (appId == QLatin1String(LEDGER_APPID)) return tr("Ledger");
    if (appId == QLatin1String(KIOSK_APPID)) return tr("Kiosk");
    return tr("Unknown source");
}

void LedgerWindow::on_CDU_DispenseCompleted(void *pObj, const char *dispCount, const char *d1, const char *d2, const char *d3, const char *d4, const char *d5, const char *d6) {
    auto *self = static_cast<LedgerWindow*>(pObj);
    if (!self) return;
    const QString count = fromCStr(dispCount);
    QStringList details;
    details << fromCStr(d1) << fromCStr(d2) << fromCStr(d3) << fromCStr(d4) << fromCStr(d5) << fromCStr(d6);
    const QString source = self->currentDispenseSource().isEmpty() ? QStringLiteral("CDU") : self->currentDispenseSource();
    QMetaObject::invokeMethod(self, [self, count, details, source]() { self->handleDispenseCompleted(count, details, source); }, Qt::QueuedConnection);
}

void LedgerWindow::on_CDU_DispenseFailed(void *pObj, short reason, const char *dispCount, const char *d1, const char *d2, const char *d3, const char *d4, const char *d5, const char *d6) {
    auto *self = static_cast<LedgerWindow*>(pObj);
    if (!self) return;
    const QString count = fromCStr(dispCount);
    QStringList details;
    details << fromCStr(d1) << fromCStr(d2) << fromCStr(d3) << fromCStr(d4) << fromCStr(d5) << fromCStr(d6);
    const QString source = self->currentDispenseSource().isEmpty() ? QStringLiteral("CDU") : self->currentDispenseSource();
    QMetaObject::invokeMethod(self, [self, reason, count, details, source]() { self->handleDispenseFailed(reason, count, details, source); }, Qt::QueuedConnection);
}
