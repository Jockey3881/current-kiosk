#ifndef CASHLEDGERMANAGER_H
#define CASHLEDGERMANAGER_H

#include <string>
#include <vector>
#include <memory>
#include "ElectronicJournal.h"

struct CDUStatus {
    bool is_ready;
    std::string error_message;
};

struct DispenseResult {
    bool success;
    std::string error_message;
    int bills_from_cst1;
    int bills_from_cst2;
    int bills_from_cst3;
    int bills_from_cst4;
    int bills_from_cst5;
    int bills_from_cst6;
    int total_bills;
    int amount_cents;  // FIXED: int instead of double (cents)
    std::string transaction_uuid;
    std::string timestamp;
    bool synced_to_server;
};

struct CassetteAllocation {
    int bills_from_cst1;
    int bills_from_cst2;
    int bills_from_cst3;
    int bills_from_cst4;
    int bills_from_cst5;
    int bills_from_cst6;
    int total_bills;
    int amount_cents;  // FIXED: int instead of double
    bool is_exact_match;
};

class CashLedgerManager {
public:
    CashLedgerManager(const std::string& machine_id, const std::string& server_url, const std::string& ej_db_path);
    ~CashLedgerManager();

    bool Initialize();
    bool InitializeCDU();
    void Shutdown();

    // Cash Dispensing - FIXED: int amount_cents instead of double amount
    DispenseResult DispenseCash(int amount_cents, const std::string& source,
    const std::string& check_tx_id = "",
    const std::string& customer_id = "");
    CassetteAllocation CalculateBillAllocation(int amount_cents);
    bool CanDispense(int amount_cents);

    // Inventory
    int GetCassetteCount(int cassette_number);
    CassetteConfig GetCassetteConfig(int cassette_number);
    int GetTotalCashValueCents();  // FIXED: Returns cents
    bool UpdateCassetteCount(int cassette_number, int new_count,
    const std::string& operator_name, const std::string& action);
    bool UpdateCassetteDenomination(int cassette_number, int new_denomination);

    // --- NEW FOR ROBUST MANAGER ---
    std::vector<CassetteConfig> GetCassettes();
    std::string RecordDispenseToEJ(
        double amount,
        int cst1, int cst2, int cst3, int cst4, int cst5, int cst6,
        const std::string& source,
        const std::string& check_tx_id,
        const std::string& customer_id
        );
    // ------------------------------

    // Sync
    int SyncToServer();
    int GetPendingSyncCount();

    // Alerts
    bool RecordAlert(const std::string& alert_type, const std::string& severity,
                     int cassette_number, const std::string& details);

    // Status
    bool IsInitialized() const { return initialized_; }
    std::string GetMachineId() const { return machine_id_; }

    // Access to EJ (for configuration)
    ElectronicJournal* GetEJ() { return ej_.get(); }

private:
    std::string machine_id_;
    std::string server_url_;
    std::string ej_db_path_;
    bool initialized_;
    std::unique_ptr<ElectronicJournal> ej_;
    void* cdu_handle_;

    bool SendDispenseCommand(const CassetteAllocation& allocation);
};

#endif
