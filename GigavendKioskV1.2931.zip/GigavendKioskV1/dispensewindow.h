#ifndef DISPENSEWINDOW_H
#define DISPENSEWINDOW_H

#include <QObject>
#include <QString>
#include <QStringList>

class DispenseWindow : public QObject
{
    Q_OBJECT
    Q_PROPERTY(bool visible READ isVisible WRITE setVisible NOTIFY visibleChanged)
    Q_PROPERTY(QString statusMessage READ statusMessage NOTIFY statusMessageChanged)
    Q_PROPERTY(bool busy READ isBusy NOTIFY busyChanged)

public:
    explicit DispenseWindow(QObject *parent = nullptr);
    ~DispenseWindow() override;

    bool isVisible() const { return m_visible; }
    void setVisible(bool visible);

    QString statusMessage() const { return m_statusMessage; }
    bool isBusy() const { return m_busy; }

    Q_INVOKABLE void dispenseNotes(const QString &noteCountText);
    Q_INVOKABLE void on_btnKioskHome_clicked();

    void setAtmActive(bool active);
    void setAppActive(bool active);

signals:
    void visibleChanged();
    void statusMessageChanged();
    void busyChanged();
    void dispenseCompleted(const QString &count, const QStringList &details, const QString &source);
    void dispenseFailed(short reason, const QString &count, const QStringList &details, const QString &source);

private:
    enum class DispenseSource {
        Unknown,
        DispenseApp,
        ATM
    };

    void setStatusMessage(const QString &message);
    void setBusy(bool busy);
    void handleDispenseCompleted(const QString &count, const QStringList &details);
    void handleDispenseFailed(short reason, const QString &count, const QStringList &details);
    void handleDeviceError(short reason);
    void appendDispenseLog(const QString &source, const QString &count, const QStringList &details);

    static void on_CDU_DispenseCompleted(void *pObj,
                                         const char *dispCount,
                                         const char *dispInfo1,
                                         const char *dispInfo2,
                                         const char *dispInfo3,
                                         const char *dispInfo4,
                                         const char *dispInfo5,
                                         const char *dispInfo6);
    static void on_CDU_DispenseFailed(void *pObj,
                                      short reason,
                                      const char *dispCount,
                                      const char *dispInfo1,
                                      const char *dispInfo2,
                                      const char *dispInfo3,
                                      const char *dispInfo4,
                                      const char *dispInfo5,
                                      const char *dispInfo6);
    static void on_CDU_DeviceError(void *pObj, short reason);

    bool m_visible;
    QString m_statusMessage;
    bool m_busy;
    bool m_atmActive;
    bool m_appActive;
    DispenseSource m_lastRequestSource;
    int m_pendingUserCount;
};

#endif // DISPENSEWINDOW_H
