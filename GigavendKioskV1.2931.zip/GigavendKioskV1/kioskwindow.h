#ifndef KIOSKWINDOW_H
#define KIOSKWINDOW_H

#include <QObject>
#include <QProcess>

class AtmWindow;
class CashingWindow;
class DispenseWindow;
class LedgerWindow;

class KioskWindow : public QObject
{
    Q_OBJECT
    Q_PROPERTY(bool visible READ visible WRITE setVisible NOTIFY visibleChanged)
    Q_PROPERTY(QString message READ message WRITE setMessage NOTIFY messageChanged)
    Q_PROPERTY(bool atmInitialized READ atmInitialized WRITE setAtmInitialized NOTIFY atmInitializedChanged)

public:
    explicit KioskWindow(QObject *parent = nullptr);
    ~KioskWindow();

    bool visible() const { return m_visible; }
    void setVisible(bool visible);

    QString message() const { return m_message; }
    void setMessage(const QString &message);

    bool atmInitialized() const { return m_atmInitialized; }
    void setAtmInitialized(bool atmInitialized) {
        if (m_atmInitialized != atmInitialized) {
            m_atmInitialized = atmInitialized;
            emit atmInitializedChanged();
        }
    }

    void setAtmWindow(AtmWindow* atmWindow) { m_atmWindow = atmWindow; }
    void setCashingWindow(CashingWindow* cashingWindow) { m_cashingWindow = cashingWindow; }
    void setDispenseWindow(DispenseWindow* dispenseWindow) { m_dispenseWindow = dispenseWindow; }
    void setLedgerWindow(LedgerWindow* ledgerWindow) { m_ledgerWindow = ledgerWindow; }

    Q_INVOKABLE void on_btnCashingApp_clicked();
    Q_INVOKABLE void on_btnATMApp_clicked();
    Q_INVOKABLE void on_btnDispenseApp_clicked();
    Q_INVOKABLE void on_btnLedgerApp_clicked();
    Q_INVOKABLE void setCDUKey(const QString &key);

    void StartATMApplication();

signals:
    void visibleChanged();
    void messageChanged();
    void atmInitializedChanged();

    // ======================= MODIFICATION START =======================
    // ADDED: Signal to tell the QML window to activate itself.
    void requestActivate();
    // ======================= MODIFICATION END =========================

private:
    QString m_strCurrentPath;
    QString m_strExecAppPath;
    QProcess *m_lxAtmApp;
    bool m_lxAtmAppStarted;
    QString m_cduLicenseKey;

    QString m_strAppId;
    QString m_strMode;
    QString m_strPreAppId;
    bool m_bActivApp;
    bool m_bInitSucceeded;
    bool m_bActivatedATM;
    bool m_bActivatedDispense;
    bool m_bActivatedLedger;

    bool m_visible;
    bool m_atmInitialized;
    QString m_message;

    AtmWindow* m_atmWindow;
    CashingWindow* m_cashingWindow;
    DispenseWindow* m_dispenseWindow;
    LedgerWindow* m_ledgerWindow;

    bool m_isInitializing;

    void ProcessInitializedApp();
    void ProcessChangedActiveApp();
    void closeEvent();

    static void on_AppMgr_ChangedActiveApp(void* pObj, bool bActive,
                                           const char* szAppid, const char* szMode, const char* szPreviousActiveAppid);
    static void on_AppMgr_InitializedApp(void* pObj, bool bSucceeded, const char* szAppid);
};

#endif // KIOSKWINDOW_H
