#include "dispensewindow.h"

#include "LxGenDevAppManager.h"
#include "LxGenDevCashDispenser.h"
#include "constants.h"
#include "atmhostlogger.h"

#include <QDateTime>
#include <QFile>
#include <QMetaObject>
#include <QMutex>
#include <QMutexLocker>
#include <QTextStream>

namespace {
constexpr const char *kDispenseLogFile = "cdu_dispense.log";
QMutex logMutex;
}

static QString fromCStr(const char *value)
{
    return value ? QString::fromUtf8(value) : QString();
}

DispenseWindow::DispenseWindow(QObject *parent)
    : QObject(parent)
    , m_visible(false)
    , m_statusMessage()
    , m_busy(false)
    , m_atmActive(false)
    , m_appActive(false)
    , m_lastRequestSource(DispenseSource::Unknown)
    , m_pendingUserCount(0)
{
    APPMGR_RegisterApp(DISPENSE_APPID, DISPENSE_APP_NAME);

    CDURegisterCallbackObject(this);
    CDURegCallbackDispenseCompleted(&DispenseWindow::on_CDU_DispenseCompleted);
    CDURegCallbackDispenseFailed(&DispenseWindow::on_CDU_DispenseFailed);
    CDURegCallbackDeviceError(&DispenseWindow::on_CDU_DeviceError);
}

DispenseWindow::~DispenseWindow()
{
    APPMGR_UnregisterApp(DISPENSE_APPID);
}

void DispenseWindow::setVisible(bool visible)
{
    if (m_visible == visible) {
        return;
    }

    m_visible = visible;
    emit visibleChanged();
}

void DispenseWindow::setAtmActive(bool active)
{
    m_atmActive = active;
}

void DispenseWindow::setAppActive(bool active)
{
    m_appActive = active;
    if (!m_appActive) {
        m_lastRequestSource = DispenseSource::Unknown;
        m_pendingUserCount = 0;
        setBusy(false);
    }
}

void DispenseWindow::setStatusMessage(const QString &message)
{
    if (m_statusMessage == message) {
        return;
    }

    m_statusMessage = message;
    emit statusMessageChanged();
}

void DispenseWindow::setBusy(bool busy)
{
    if (m_busy == busy) {
        return;
    }

    m_busy = busy;
    emit busyChanged();
}

void DispenseWindow::dispenseNotes(const QString &noteCountText)
{
    if (m_busy) {
        setStatusMessage(tr("A dispense is already in progress."));
        return;
    }

    const QString trimmed = noteCountText.trimmed();
    if (trimmed.isEmpty()) {
        setStatusMessage(tr("Enter the number of notes to dispense."));
        return;
    }

    bool ok = false;
    const int noteCount = trimmed.toInt(&ok);
    if (!ok || noteCount <= 0) {
        setStatusMessage(tr("Enter a valid positive whole number."));
        return;
    }

    setBusy(true);
    m_lastRequestSource = DispenseSource::DispenseApp;
    m_pendingUserCount = noteCount;

    const short result = CDUDispense(noteCount, 0, 0, 0, 0, 0);
    if (result < 0) {
        setStatusMessage(tr("Dispense request failed (%1).").arg(result));
        m_lastRequestSource = DispenseSource::Unknown;
        m_pendingUserCount = 0;
        setBusy(false);
    } else {
        setStatusMessage(tr("Dispensing %1 notes...").arg(noteCount));
    }
}

void DispenseWindow::on_btnKioskHome_clicked()
{
    APPMGR_NotifyInactiveApp(KIOSK_APPID, KIOSK_HOME_MODE);
}

void DispenseWindow::handleDispenseCompleted(const QString &count, const QStringList &details)
{
    QString source;
    if (m_atmActive) {
        source = QStringLiteral("ATM");
    } else if (m_lastRequestSource == DispenseSource::DispenseApp || m_appActive) {
        source = QStringLiteral("DispenseApp");
    } else {
        source = QStringLiteral("Unknown");
    }

    appendDispenseLog(source, count, details);

    const QString resolvedCount = count.isEmpty() && m_pendingUserCount > 0
                                      ? QString::number(m_pendingUserCount)
                                      : count;

    if (source == QLatin1String("ATM")) {
        AtmHostLogger::instance().logTotalsUpdate(QStringLiteral("Dispense Completed"), count, details);
    }

    if (m_appActive && source == QLatin1String("DispenseApp")) {
        setStatusMessage(tr("Dispensed %1 notes successfully.").arg(resolvedCount));
    }

    m_lastRequestSource = DispenseSource::Unknown;
    m_pendingUserCount = 0;
    setBusy(false);

    emit dispenseCompleted(resolvedCount, details, source);
}

void DispenseWindow::handleDispenseFailed(short reason, const QString &count, const QStringList &details)
{
    const QString source = m_atmActive ? QStringLiteral("ATM") : QStringLiteral("DispenseApp");
    appendDispenseLog(source + QStringLiteral(" (failed)"), count, details);

    if (m_atmActive) {
        AtmHostLogger::instance().logTotalsUpdate(QStringLiteral("Dispense Failed"), count, details);
    }

    if (m_appActive && !m_atmActive) {
        setStatusMessage(tr("Dispense failed (%1).").arg(reason));
    }

    m_lastRequestSource = DispenseSource::Unknown;
    m_pendingUserCount = 0;
    setBusy(false);

    emit dispenseFailed(reason, count, details, source);
}

void DispenseWindow::handleDeviceError(short reason)
{
    if (m_appActive && !m_atmActive) {
        setStatusMessage(tr("CDU device error (%1).").arg(reason));
    }

    if (m_atmActive) {
        AtmHostLogger::instance().logEvent(QStringLiteral("ATM CDU device error"),
                                           {{QStringLiteral("reason"), QString::number(reason)}});
    }

    m_lastRequestSource = DispenseSource::Unknown;
    m_pendingUserCount = 0;
    setBusy(false);
}

void DispenseWindow::appendDispenseLog(const QString &source, const QString &count, const QStringList &details)
{
    QMutexLocker locker(&logMutex);
    QFile logFile(QString::fromLatin1(kDispenseLogFile));
    if (!logFile.open(QIODevice::WriteOnly | QIODevice::Append | QIODevice::Text)) {
        return;
    }

    QTextStream stream(&logFile);
    stream << QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss.zzz")
           << " | source=" << source
           << " | count=" << (count.isEmpty() ? QStringLiteral("0") : count);

    if (!details.isEmpty()) {
        stream << " | cassettes=" << details.join(QLatin1String(","));
    }

    stream << '\n';
    stream.flush();
}

void DispenseWindow::on_CDU_DispenseCompleted(void *pObj,
                                              const char *dispCount,
                                              const char *dispInfo1,
                                              const char *dispInfo2,
                                              const char *dispInfo3,
                                              const char *dispInfo4,
                                              const char *dispInfo5,
                                              const char *dispInfo6)
{
    auto *self = static_cast<DispenseWindow *>(pObj);
    if (!self) {
        return;
    }

    const QString count = fromCStr(dispCount);
    const QStringList details = {fromCStr(dispInfo1), fromCStr(dispInfo2), fromCStr(dispInfo3),
                                 fromCStr(dispInfo4), fromCStr(dispInfo5), fromCStr(dispInfo6)};

    QMetaObject::invokeMethod(self,
                              [self, count, details]() {
                                  self->handleDispenseCompleted(count, details);
                              },
                              Qt::QueuedConnection);
}

void DispenseWindow::on_CDU_DispenseFailed(void *pObj,
                                           short reason,
                                           const char *dispCount,
                                           const char *dispInfo1,
                                           const char *dispInfo2,
                                           const char *dispInfo3,
                                           const char *dispInfo4,
                                           const char *dispInfo5,
                                           const char *dispInfo6)
{
    auto *self = static_cast<DispenseWindow *>(pObj);
    if (!self) {
        return;
    }

    const QString count = fromCStr(dispCount);
    const QStringList details = {fromCStr(dispInfo1), fromCStr(dispInfo2), fromCStr(dispInfo3),
                                 fromCStr(dispInfo4), fromCStr(dispInfo5), fromCStr(dispInfo6)};

    QMetaObject::invokeMethod(self,
                              [self, reason, count, details]() {
                                  self->handleDispenseFailed(reason, count, details);
                              },
                              Qt::QueuedConnection);
}

void DispenseWindow::on_CDU_DeviceError(void *pObj, short reason)
{
    auto *self = static_cast<DispenseWindow *>(pObj);
    if (!self) {
        return;
    }

    QMetaObject::invokeMethod(self,
                              [self, reason]() {
                                  self->handleDeviceError(reason);
                              },
                              Qt::QueuedConnection);
}

