#include "cashingwindow.h"
#include <QNetworkReply>
#include <QUrlQuery>
#include <QJsonDocument>
#include <QJsonObject>
#include <QHttpMultiPart>
#include <QHttpPart>
#include <QBuffer>
#include <QCoreApplication>
#include <QDebug>
#include <QFile>
#include <QTextStream>
#include <QDateTime>
#include <QProcessEnvironment>
#include <QRegularExpression>
#include <QMessageBox>

// Utils
#include "utils/scanworker.h"
#include "utils/fingerprint.h"
#include "constants.h"
#include "LxGenDevAppManager.h"
#include "utils/imageprocess.h"

// Phase 3 Cash Management
#include "CheckCashingIntegration.h"
#include "CashLedgerSingleton.h"
#include "RobustCDUDispenseManager.h"

CashingWindow::CashingWindow(QObject *parent)
    : QObject(parent)
{
    m_visible = true;
    m_fingerWorker = nullptr;
    m_scanWorker = nullptr;
    m_reply = nullptr;
    m_EnrollmentFmd = nullptr;
    m_EnrollmentFmdSize = 0;
    m_imageProcessThread = new QThread;
    m_scanProcessThread = new QThread;

    // --- LOAD CONFIGURATION FROM ENVIRONMENT ---
    m_serverUrlBase = qEnvironmentVariable("SERVER_URL_BASE", "https://checkreview.hardcracker.com");
    m_machineUsername = qEnvironmentVariable("MACHINE_USERNAME", "123456789");
    m_machinePassword = qEnvironmentVariable("MACHINE_PASSWORD", "password123");

    m_apiMachineLogin = qEnvironmentVariable("API_MACHINE_LOGIN", "/api/auth/machine_login");
    m_apiSendCode = qEnvironmentVariable("API_SEND_CODE", "/api/customer/phone/send_code");
    m_apiVerifyCode = qEnvironmentVariable("API_VERIFY_CODE", "/api/customer/phone/verify_code");
    m_apiCustomer = qEnvironmentVariable("API_CUSTOMER", "/api/customer");
    m_apiCustomerLogin = qEnvironmentVariable("API_CUSTOMER_LOGIN", "/api/customer/login");
    m_apiCustomerCheck = qEnvironmentVariable("API_CUSTOMER_CHECK", "/api/customer/stage-check/%1");
    m_apiCheckStatus = qEnvironmentVariable("API_CHECK_STATUS", "/api/kiosk/check_status/%1");
    m_apiConfirmTransaction = qEnvironmentVariable("API_CONFIRM_TRANSACTION", "/api/kiosk/confirm_transaction");

    qInfo() << "CashingWindow Configured using Server:" << m_serverUrlBase;

    // --- STATE & TIMER INIT ---
    m_state = TransactionState::Idle;
    m_pollTimer = new QTimer(this);
    m_pollTimer->setInterval(3000);
    connect(m_pollTimer, &QTimer::timeout, this, &CashingWindow::onPollTimerTriggered);

    m_checkScanner = new CheckScanner(this);
    connect(m_checkScanner, &CheckScanner::scanSuccess, this, &CashingWindow::onCheckScanSuccess);
    connect(m_checkScanner, &CheckScanner::scanFailure, this, &CashingWindow::onCheckScanFailure);
    connect(m_checkScanner, &CheckScanner::scannerConnected, this, &CashingWindow::onScannerConnected);
}

CashingWindow::~CashingWindow()
{
    if(m_checkScanner) m_checkScanner->disconnectScanner();
    if (m_EnrollmentFmd) delete[] m_EnrollmentFmd;

    if (m_reply) {
        m_reply->disconnect(this);
        m_reply->abort();
        delete m_reply;
        m_reply = nullptr;
    }

    if (m_imageProcessThread) m_imageProcessThread->quit();
    if (m_scanProcessThread) m_scanProcessThread->quit();
    if (m_scanWorker) delete m_scanWorker;
    if (m_fingerWorker) delete m_fingerWorker;

    if (m_imageProcessThread) { m_imageProcessThread->wait(); delete m_imageProcessThread; }
    if (m_scanProcessThread) { m_scanProcessThread->wait(); delete m_scanProcessThread; }
}

void CashingWindow::setState(TransactionState newState) {
    qInfo() << "State Transition:" << m_state << "->" << newState;
    m_state = newState;
}

// Getters
bool CashingWindow::isVisible() const { return m_visible; }
QString CashingWindow::getPhone() const { return m_phone; }
QString CashingWindow::getEmail() const { return m_email; }
QString CashingWindow::getPin() const { return m_pin; }
QString CashingWindow::getVeriCode() const { return m_veriCode; }
QString CashingWindow::getErrorMessage() const { return m_errorMessage; }
QImage CashingWindow::getScanIdFrontImage() const { return m_scanFront; }
QImage CashingWindow::getScanIdBackImage() const { return m_scanBack; }
QString CashingWindow::getReviewMessage() const { return m_reviewMessage; }
bool CashingWindow::getScanSuccess() const { return m_scanSuccess; }
QImage CashingWindow::getCheckFrontImage() const { return m_checkFrontImage; }
QImage CashingWindow::getCheckBackImage() const { return m_checkBackImage; }
QImage CashingWindow::getKioskPhoto() const { return m_photo; }

// Setters
void CashingWindow::setVisible(bool visible) { if (m_visible != visible) { m_visible = visible; emit visibleChanged(); } }
void CashingWindow::setPhone(const QString& phone) { if (m_phone != phone) { m_phone = phone; emit phoneChanged(); } }
void CashingWindow::setEmail(const QString& email) { if (m_email != email) { m_email = email; emit emailChanged(); } }
void CashingWindow::setPin(const QString& pin) { if (m_pin != pin) { m_pin = pin; emit pinChanged(); } }
void CashingWindow::setVeriCode(const QString& veriCode) { if (m_veriCode != veriCode) { m_veriCode = veriCode; emit veriCodeChanged(); } }
void CashingWindow::setErrorMessage(const QString& errorMsg) { m_errorMessage = errorMsg; emit errorMessageChanged(); }
void CashingWindow::setReviewMessage(const QString& message) { if (m_reviewMessage != message) { m_reviewMessage = message; emit reviewMessageChanged(); } }

void CashingWindow::captureImage(const QImage& image) { m_photo = image; emit kioskPhotoChanged(); }
void CashingWindow::setFingerImage(unsigned char* p, unsigned int s) {
    if (p != NULL && s > 0) {
        if (m_EnrollmentFmd) delete[] m_EnrollmentFmd;
        m_EnrollmentFmdSize = s;
        m_EnrollmentFmd = new unsigned char[s];
        memcpy(m_EnrollmentFmd, p, s);
    }
}
void CashingWindow::setScanFrontImage(unsigned char* p, unsigned int s) { m_scanFront = QImage::fromData(p, s); }
void CashingWindow::setScanBackImage(unsigned char* p, unsigned int s) { m_scanBack = QImage::fromData(p, s); }

// Network & Auth
void CashingWindow::getAccessToken() {
    if (m_reply) {
        m_reply->disconnect(this);
        m_reply->abort();
        m_reply->deleteLater();
        m_reply = nullptr;
    }
    QUrlQuery query;
    query.addQueryItem("username", m_machineUsername);
    query.addQueryItem("password", m_machinePassword);
    QString url = m_serverUrlBase + m_apiMachineLogin;
    QNetworkRequest request(url);
    request.setHeader(QNetworkRequest::ContentTypeHeader, "application/x-www-form-urlencoded");
    m_reply = m_networkManager.post(request, query.toString(QUrl::FullyEncoded).toUtf8());
    connect(m_reply, &QNetworkReply::finished, this, &CashingWindow::extractAccessToken);
}

void CashingWindow::extractAccessToken() {
    if (m_reply) {
        if (m_reply->error() == QNetworkReply::NoError) {
            m_accessToken = QJsonDocument::fromJson(m_reply->readAll())["access_token"].toString();
            qInfo() << "Access Token acquired.";
        } else {
            qWarning() << "Failed to get Access Token:" << m_reply->errorString();
        }
        m_reply->deleteLater();
        m_reply = nullptr;
    }
}

// --- OTP / Verification ---
void CashingWindow::sendVerificationCode() {
    SendOTPCode();
    connect(m_reply, &QNetworkReply::finished, this, &CashingWindow::analyzeSendVerificationCodeResult);
}

void CashingWindow::resendOTPCode() {
    SendOTPCode();
    connect(m_reply, &QNetworkReply::finished, this, &CashingWindow::analyzeResendVerificationCodeResult);
}

void CashingWindow::SendOTPCode() {
    if (m_reply) {
        m_reply->disconnect(this);
        m_reply->abort();
        m_reply->deleteLater();
        m_reply = nullptr;
    }
    qInfo() << "Initiating OTP Send to:" << m_phone;
    QJsonObject obj;
    obj["phone"] = m_phone; obj["email"] = m_email;
    QNetworkRequest request(m_serverUrlBase + m_apiSendCode);
    request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");
    if (!m_accessToken.isEmpty()) request.setRawHeader("Authorization", ("Bearer " + m_accessToken).toUtf8());
    m_reply = m_networkManager.post(request, QJsonDocument(obj).toJson());
}

void CashingWindow::analyzeSendVerificationCodeResult() {
    if (!m_reply) return;

    if (m_reply->error() == QNetworkReply::NoError) {
        qInfo() << "OTP Sent Successfully";
        emit sendVerificationCodeSuccess();
    } else {
        QString err = m_reply->errorString();
        QByteArray data = m_reply->readAll();
        qWarning() << "OTP Send Failed:" << err << "Response:" << data;

        QJsonDocument doc = QJsonDocument::fromJson(data);
        if (!doc.isNull() && doc.isObject() && doc.object().contains("detail")) {
            QJsonValue detail = doc.object().value("detail");
            if (detail.isString()) err = detail.toString();
            else if (detail.isObject()) err = detail.toObject().value("reason").toString();
        }
        setErrorMessage(err);
        emit sendVerificationCodeFailure();
    }
    m_reply->deleteLater();
    m_reply = nullptr;
}

void CashingWindow::analyzeResendVerificationCodeResult() {
    if (!m_reply) return;

    if (m_reply->error() == QNetworkReply::NoError) {
        qInfo() << "OTP Resent Successfully";
    } else {
        QString err = m_reply->errorString();
        setErrorMessage(err);
        emit resendVerificationCodeFailure();
    }
    m_reply->deleteLater();
    m_reply = nullptr;
}

void CashingWindow::checkVerificationCode() {
    if (m_reply) {
        m_reply->disconnect(this);
        m_reply->abort();
        m_reply->deleteLater();
        m_reply = nullptr;
    }
    QJsonObject obj; obj["phone"] = m_phone; obj["code"] = m_veriCode;
    QNetworkRequest request(m_serverUrlBase + m_apiVerifyCode);
    request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");
    if (!m_accessToken.isEmpty()) request.setRawHeader("Authorization", ("Bearer " + m_accessToken).toUtf8());
    m_reply = m_networkManager.post(request, QJsonDocument(obj).toJson());
    connect(m_reply, &QNetworkReply::finished, this, &CashingWindow::analyzeCheckVerificationCodeResult);
}

void CashingWindow::analyzeCheckVerificationCodeResult() {
    if (m_reply) {
        if (m_reply->error() == QNetworkReply::NoError) emit checkVerificationCodeSuccess();
        else emit checkVerificationCodeFailure();
        m_reply->deleteLater(); m_reply=nullptr;
    }
}

// --- Customer Logic ---
void CashingWindow::login(const QString& phone, const QString& pin) {
    if (m_reply) {
        m_reply->disconnect(this);
        m_reply->abort();
        m_reply->deleteLater();
        m_reply = nullptr;
    }
    QJsonObject obj; obj["phone"] = phone; obj["pin"] = pin;
    QNetworkRequest request(m_serverUrlBase + m_apiCustomerLogin);
    request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");
    request.setRawHeader("Authorization", ("Bearer " + m_accessToken).toUtf8());
    m_reply = m_networkManager.post(request, QJsonDocument(obj).toJson());
    connect(m_reply, &QNetworkReply::finished, this, &CashingWindow::analyzeLoginResult);
}

void CashingWindow::analyzeLoginResult() {
    if(!m_reply) return;
    if(m_reply->error() == QNetworkReply::NoError) {
        QJsonObject o = QJsonDocument::fromJson(m_reply->readAll()).object();
        m_customerId = o["customer_id"].toString();
        emit loginSuccess(o["first_name"].toString(), o["last_name"].toString());
    } else emit loginFailure("Login failed");
    m_reply->deleteLater(); m_reply=nullptr;
}

void CashingWindow::sendForReview()
{
    if (m_reply) {
        m_reply->disconnect(this);
        m_reply->abort();
        m_reply->deleteLater();
        m_reply = nullptr;
    }

    QHttpMultiPart *multiPart = new QHttpMultiPart(QHttpMultiPart::FormDataType);

    QHttpPart phonePart; phonePart.setHeader(QNetworkRequest::ContentDispositionHeader, QVariant("form-data; name=\"phone\"")); phonePart.setBody(m_phone.toLatin1()); multiPart->append(phonePart);
    QHttpPart emailPart; emailPart.setHeader(QNetworkRequest::ContentDispositionHeader, QVariant("form-data; name=\"email\"")); emailPart.setBody(m_email.toLatin1()); multiPart->append(emailPart);
    QHttpPart pinPart; pinPart.setHeader(QNetworkRequest::ContentDispositionHeader, QVariant("form-data; name=\"pin\"")); pinPart.setBody(m_pin.toLatin1()); multiPart->append(pinPart);

    QHttpPart fmdPart; fmdPart.setHeader(QNetworkRequest::ContentTypeHeader, QVariant("application/octet-stream"));
    fmdPart.setHeader(QNetworkRequest::ContentDispositionHeader, QVariant("form-data; name=\"fmd_data\"; filename=\"fingerprint_minutia.fmd\""));
    QByteArray fmdByteArray(reinterpret_cast<char*>(m_EnrollmentFmd), m_EnrollmentFmdSize); fmdPart.setBody(fmdByteArray); multiPart->append(fmdPart);

    QHttpPart kioskPart; kioskPart.setHeader(QNetworkRequest::ContentTypeHeader, QVariant("image/jpeg"));
    kioskPart.setHeader(QNetworkRequest::ContentDispositionHeader, QVariant("form-data; name=\"kiosk_img\"; filename=\"kiosk_photo.jpeg\""));
    QByteArray kioskArray; QBuffer kioskBuffer(&kioskArray); kioskBuffer.open(QIODevice::WriteOnly); m_photo.save(&kioskBuffer, "JPEG"); kioskPart.setBody(kioskArray); multiPart->append(kioskPart);

    QHttpPart idFrontPart; idFrontPart.setHeader(QNetworkRequest::ContentTypeHeader, QVariant("image/jpeg"));
    idFrontPart.setHeader(QNetworkRequest::ContentDispositionHeader, QVariant("form-data; name=\"id_front\"; filename=\"id_image_front.jpeg\""));
    QByteArray idFrontArray; QBuffer idFrontBuffer(&idFrontArray); idFrontBuffer.open(QIODevice::WriteOnly); m_scanFront.save(&idFrontBuffer, "JPEG"); idFrontPart.setBody(idFrontArray); multiPart->append(idFrontPart);

    QHttpPart idBackPart; idBackPart.setHeader(QNetworkRequest::ContentTypeHeader, QVariant("image/jpeg"));
    idBackPart.setHeader(QNetworkRequest::ContentDispositionHeader, QVariant("form-data; name=\"id_back\"; filename=\"id_image_back.jpeg\""));
    QByteArray idBackArray; QBuffer idBackBuffer(&idBackArray); idBackBuffer.open(QIODevice::WriteOnly); m_scanBack.save(&idBackBuffer, "JPEG"); idBackPart.setBody(idBackArray); multiPart->append(idBackPart);

    QString url = m_serverUrlBase + m_apiCustomer;
    QNetworkRequest request(url);
    if (!m_accessToken.isEmpty()) request.setRawHeader("Authorization", ("Bearer " + m_accessToken).toUtf8());

    m_reply = m_networkManager.post(request, multiPart);
    multiPart->setParent(m_reply);
    connect(m_reply, &QNetworkReply::finished, this, &CashingWindow::analyzeSendForReviewResult);
}

void CashingWindow::analyzeSendForReviewResult()
{
    if (m_reply->error() == QNetworkReply::NoError) {
        QByteArray data = m_reply->readAll();
        QJsonDocument jsonDocu = QJsonDocument::fromJson(data);
        QString msg = jsonDocu["msg"].toString();
        QString customer_id = jsonDocu["customer_id"].toString();
        if (!customer_id.isEmpty()) {
            m_customerId = customer_id;
            qInfo() << "[API] new-customer: customer_id =" << m_customerId;
        } else {
            qWarning() << "[API] new-customer: response missing customer_id";
            setErrorMessage("Server did not return a customer id. Please try again.");
            emit sendReviewDataFailure();
            return;
        }
        msg += "\ncustomer_id: " + customer_id;
        setReviewMessage(msg);
        emit sendReviewDataSuccess();
    } else {
        QByteArray data = m_reply->readAll();
        QJsonDocument jsonDocu = QJsonDocument::fromJson(data);
        QJsonObject objError = jsonDocu["error"].toObject();
        QString errMsg = objError["msg"].toString();
        setErrorMessage(errMsg.isEmpty() ? QString::fromUtf8(data) : errMsg);
        emit sendReviewDataFailure();
    }
}

// --- Check Processing ---
void CashingWindow::customerCheck() {
    if (m_state != TransactionState::Idle) return;
    if (m_accessToken.isEmpty() || m_customerId.isEmpty()) {
        emit customerCheckFailure("Not authenticated or no customer ID.");
        return;
    }
    setState(TransactionState::UploadingCheck);

    if (m_reply) {
        m_reply->disconnect(this);
        m_reply->abort();
        m_reply->deleteLater();
        m_reply = nullptr;
    }

    QHttpMultiPart *multiPart = new QHttpMultiPart(QHttpMultiPart::FormDataType);

    // Normalization lambda
    auto normalizeDateForApi = [](const QString &d)->QByteArray {
        QRegularExpression re(R"(^(\d{2})\/(\d{2})\/(\d{4})$)");
        auto m = re.match(d.trimmed());
        if (m.hasMatch()) {
            return QStringLiteral("%1-%2-%3").arg(m.captured(2), m.captured(1), m.captured(3)).toUtf8();
        }
        return d.toUtf8();
    };

    auto addTextPart = [&](const char* name, const QByteArray& val) {
        QHttpPart part;
        part.setHeader(QNetworkRequest::ContentDispositionHeader, QVariant(QString("form-data; name=\"%1\"").arg(name)));
        part.setBody(val);
        multiPart->append(part);
    };

    auto addImagePart = [&](const QImage& img, const char* name, const char* filename, const char* type) {
        QByteArray arr; QBuffer buf(&arr); buf.open(QIODevice::WriteOnly); img.save(&buf, type);
        QHttpPart part;
        part.setHeader(QNetworkRequest::ContentTypeHeader, QVariant(QString("image/%1").arg(strcmp(type, "JPEG") == 0 ? "jpeg" : "tiff")));
        part.setHeader(QNetworkRequest::ContentDispositionHeader, QVariant(QString("form-data; name=\"%1\"; filename=\"%2\"").arg(name, filename)));
        part.setBody(arr);
        multiPart->append(part);
    };

    auto addRawPart = [&](const QByteArray& data, const char* name, const char* filename) {
        QHttpPart part;
        part.setHeader(QNetworkRequest::ContentTypeHeader, QVariant("image/tiff"));
        part.setHeader(QNetworkRequest::ContentDispositionHeader, QVariant(QString("form-data; name=\"%1\"; filename=\"%2\"").arg(name, filename)));
        part.setBody(data);
        multiPart->append(part);
    };

    addRawPart(m_checkFrontTiff, "check_image_front_tiff", "check_image_front.tiff");
    addRawPart(m_checkBackTiff, "check_image_back_tiff", "check_image_back.tiff");
    addImagePart(m_checkFrontImage, "check_image_front_jpeg", "check_image_front.jpeg", "JPEG");
    addImagePart(m_checkBackImage, "check_image_back_jpeg", "check_image_back.jpeg", "JPEG");
    addImagePart(m_photo, "kiosk_image", "kiosk_photo.jpeg", "JPEG");

    addTextPart("check_amount", m_checkAmount.toUtf8());
    addTextPart("check_date", normalizeDateForApi(m_checkDate));
    addTextPart("new_customer", m_newCustomer ? "true" : "false");
    addTextPart("micr", m_micrData.toUtf8());

    QString path = m_apiCustomerCheck;
    if (path.contains("%1")) path = path.arg(m_customerId);
    else path.replace("{customer_id}", m_customerId);

    QUrl url(m_serverUrlBase + path);
    QNetworkRequest request(url);
    request.setRawHeader("Authorization", ("Bearer " + m_accessToken).toUtf8());

    m_reply = m_networkManager.post(request, multiPart);
    multiPart->setParent(m_reply);
    connect(m_reply, &QNetworkReply::finished, this, &CashingWindow::analyzeCustomerCheckResult);
}

void CashingWindow::analyzeCustomerCheckResult() {
    if (!m_reply) return;

    if (m_reply->error() == QNetworkReply::NoError) {
        QJsonObject obj = QJsonDocument::fromJson(m_reply->readAll()).object();
        if (obj.contains("transaction_id")) {
            m_currentTxId = obj["transaction_id"].toString();
            m_currentCheckId = obj["check_id"].toString();
            qInfo() << "Submission Success. TxID:" << m_currentTxId;
            setState(TransactionState::PollingStatus);
            if (!m_pollTimer->isActive()) m_pollTimer->start();
            emit customerCheckSuccess();
        } else {
            setState(TransactionState::Idle);
            emit customerCheckFailure("Server response missing transaction_id");
        }
    } else {
        setState(TransactionState::Idle);
        emit customerCheckFailure("Failed to submit check.");
    }
    m_reply->deleteLater();
    m_reply = nullptr;
}

void CashingWindow::onPollTimerTriggered() {
    if (m_state != TransactionState::PollingStatus) {
        m_pollTimer->stop();
        return;
    }
    checkStatus();
}

void CashingWindow::checkStatus() {
    if (m_reply) return; // Busy
    if (m_currentTxId.isEmpty()) return;

    QString path = m_apiCheckStatus;
    if (path.contains("%1")) path = path.arg(m_currentTxId);

    QNetworkRequest request(m_serverUrlBase + path);
    if (!m_accessToken.isEmpty()) request.setRawHeader("Authorization", ("Bearer " + m_accessToken).toUtf8());

    m_reply = m_networkManager.get(request);
    connect(m_reply, &QNetworkReply::finished, this, &CashingWindow::analyzeCheckStatusResult);
}

void CashingWindow::analyzeCheckStatusResult() {
    if (!m_reply) return;

    if (m_reply->error() == QNetworkReply::NoError) {
        QJsonObject obj = QJsonDocument::fromJson(m_reply->readAll()).object();
        QString status = obj["status"].toString();
        qInfo() << "Check Status:" << status;

        if (status == "waiting_user") {
            m_pollTimer->stop();
            setState(TransactionState::FeeAcceptance);
            QJsonObject fin = obj["financials"].toObject();

            // CACHE for dispenseApprovedCheck()
            m_lastProposedFee = fin["total_fee"].toDouble();
            m_lastProposedPayout = fin["cash_payout"].toDouble();

            emit feeProposalReceived(m_lastProposedFee, m_lastProposedPayout, m_currentTxId);
        } else if (status == "rejected" || status == "denied") {
            m_pollTimer->stop();
            setState(TransactionState::Idle);
            emit checkStatusRejected(obj["reason"].toString());
        }
    }
    m_reply->deleteLater();
    m_reply = nullptr;
}

// ============================================================================
// PHASE 3: CASH DISPENSE & CONFIRMATION
// ============================================================================

void CashingWindow::confirmTransaction(const QString& checkId, double fee, double payout) {
    if (m_state != TransactionState::FeeAcceptance) return;
    setState(TransactionState::Authorizing);

    if (m_reply) { m_reply->disconnect(this); m_reply->abort(); m_reply->deleteLater(); m_reply = nullptr; }

    QJsonObject json;
    json["queue_id"] = m_currentTxId;
    json["location_id"] = "1";
    json["accepted_fee"] = fee;
    json["accepted_payout"] = payout;
    json["user_accepted_fee"] = true;

    QNetworkRequest request(m_serverUrlBase + m_apiConfirmTransaction);
    request.setHeader(QNetworkRequest::ContentTypeHeader, "application/json");
    request.setRawHeader("Authorization", ("Bearer " + m_accessToken).toUtf8());

    m_reply = m_networkManager.post(request, QJsonDocument(json).toJson());
    connect(m_reply, &QNetworkReply::finished, this, &CashingWindow::analyzeConfirmTransactionResult);
}

void CashingWindow::analyzeConfirmTransactionResult() {
    if (!m_reply) return;

    if (m_reply->error() == QNetworkReply::NoError) {
        QJsonObject obj = QJsonDocument::fromJson(m_reply->readAll()).object();
        if (obj["status"].toString() == "authorized") {
            setState(TransactionState::Dispensing);
            double amt = obj["dispense_amount"].toDouble();
            qInfo() << "Authorized amount:" << amt;

            // TRIGGER HARDWARE DISPENSE
            performHardwareDispense(amt);

        } else {
            setState(TransactionState::Idle);
            emit confirmTransactionFailed("Authorization denied");
        }
    } else {
        setState(TransactionState::Idle);
        emit confirmTransactionFailed("Network error during confirmation");
    }
    m_reply->deleteLater();
    m_reply = nullptr;
}

void CashingWindow::performHardwareDispense(double amount) {
    qInfo() << "🔧 Performing Hardware Dispense (Robust): $" << amount;

    RobustCDUDispenseManager dispenser;
    RobustDispenseResult result = dispenser.DispenseWithRetry(
        amount,
        "CheckCashing",
        m_currentTxId.toStdString(),
        m_customerId.toStdString()
        );

    if (result.success) {
        qInfo() << "✅ HARDWARE DISPENSE SUCCESS!";

        // Build breakdown string
        QStringList breakdownList;
        if (result.bills_from_cst6 > 0) breakdownList << QString("%1 x $100").arg(result.bills_from_cst6);
        if (result.bills_from_cst5 > 0) breakdownList << QString("%1 x $50").arg(result.bills_from_cst5);
        if (result.bills_from_cst4 > 0) breakdownList << QString("%1 x $20").arg(result.bills_from_cst4);
        if (result.bills_from_cst3 > 0) breakdownList << QString("%1 x $10").arg(result.bills_from_cst3);
        if (result.bills_from_cst2 > 0) breakdownList << QString("%1 x $5").arg(result.bills_from_cst2);
        if (result.bills_from_cst1 > 0) breakdownList << QString("%1 x $1").arg(result.bills_from_cst1);

        QString breakdown = breakdownList.join("\n");
        int totalBills = result.total_bills;

        emit dispenseSuccess(amount, totalBills, breakdown);
        emit dispenseAuthorized(amount, m_currentTxId);
        completeTransaction("Success", amount);
    } else {
        qCritical() << "❌ DISPENSE FAILED:" << QString::fromStdString(result.error_message);
        emit dispenseFailed(QString::fromStdString(result.error_message));
        setState(TransactionState::Idle);
    }
}

// === FIX: IMPLEMENT MISSING FUNCTIONS ===

void CashingWindow::testDispense(double amount) {
    qInfo() << "🧪 Test Dispense Requested: $" << amount;
    performHardwareDispense(amount);
}

void CashingWindow::dispenseApprovedCheck() {
    qInfo() << "[CashingWindow] dispenseApprovedCheck() called";

    if (m_state != TransactionState::FeeAcceptance) {
        qWarning() << "dispenseApprovedCheck ignored: State is not FeeAcceptance (" << m_state << ")";
        return;
    }

    if (m_lastProposedPayout <= 0) {
        emit dispenseFailed("No approved transaction amount available");
        return;
    }

    // Call confirmTransaction which will trigger performHardwareDispense on success
    confirmTransaction(m_currentTxId, m_lastProposedFee, m_lastProposedPayout);
}

void CashingWindow::completeTransaction(const QString& result, double amountDispensed) {
    qInfo() << "Transaction Complete:" << result << "Dispensed: $" << amountDispensed;

    // Logic handled by on_btnKioskHome_clicked when timer expires
    m_lastProposedFee = 0.0;
    m_lastProposedPayout = 0.0;
    m_currentTxId.clear();
    m_currentCheckId.clear();
}

// --- FIXED: ADD MISSING SLOT IMPLEMENTATION ---
void CashingWindow::analyzeCompleteTransactionResult() {
    // Stub implementation to satisfy linker
    if (m_reply) {
        m_reply->deleteLater();
        m_reply = nullptr;
    }
}

// --- SCANNER / FINGERPRINT BOILERPLATE ---
void CashingWindow::on_btnKioskHome_clicked() {
    // CRITICAL: Stop any pending network requests when hitting home
    if (m_reply) {
        m_reply->disconnect(this);
        m_reply->abort();
        delete m_reply;
        m_reply = nullptr;
    }

    setState(TransactionState::Idle);
    m_pollTimer->stop();

    // --- RESET ALL SESSION VARIABLES ---
    qInfo() << "Cleaning up session data...";
    m_phone.clear();
    m_email.clear();
    m_pin.clear();
    m_veriCode.clear();
    m_errorMessage.clear();
    m_reviewMessage.clear();
    m_scanFront = QImage();
    m_scanBack = QImage();
    m_photo = QImage();
    m_checkFrontImage = QImage();
    m_checkBackImage = QImage();
    m_checkAmount.clear();
    m_checkDate.clear();
    m_micrData.clear();
    m_customerId.clear(); // Important: user must log in again
    m_currentTxId.clear();
    m_currentCheckId.clear();
    m_newCustomer = false;

    APPMGR_NotifyInactiveApp(KIOSK_APPID, KIOSK_HOME_MODE);
}

// --- Legacy Setters (Optionally kept if used elsewhere, empty implementation) ---
void CashingWindow::setMachineUsername(const QString& u) { m_machineUsername = u; }
void CashingWindow::setMachinePassword(const QString& p) { m_machinePassword = p; }
void CashingWindow::setServerUrlBase(const QString& u) { m_serverUrlBase = u; }

void CashingWindow::closeEvent() { APPMGR_NotifyInactiveApp(KIOSK_APPID, KIOSK_HOME_MODE); }
void CashingWindow::exitApplication() { QCoreApplication::quit(); }
void CashingWindow::setNewCustomer(bool isNew) { m_newCustomer = isNew; }
void CashingWindow::setCheckAmount(const QString &amount) { m_checkAmount = amount; }
void CashingWindow::setCheckDate(const QString &date) { m_checkDate = date; }
void CashingWindow::setScanSuccess(bool s) { m_scanSuccess = s; }
bool CashingWindow::isPinValid(const QString& p) { return p.length() == 4; }

bool CashingWindow::softRearmCheckScanner() {
    if(!m_checkScanner) return false;
    if (m_checkScanner->softRearm()) {
        m_checkScannerReady = true;
        emit checkScannerReady();
        return true;
    }
    if (m_checkScanner->connectScanner()) {
        m_checkScannerReady = true;
        emit checkScannerReady();
        return true;
    }
    return false;
}

void CashingWindow::startCheckScan() { if(m_checkScanner) m_checkScanner->startScan(); }
void CashingWindow::cancelScanId() { if(m_scanWorker) m_scanWorker->cancelScanId(nullptr); }
void CashingWindow::notifyScanPageLoaded() {
    if (m_scanWorker==nullptr) m_scanWorker = new ScanWorker(this);
    if (m_scanProcessThread==nullptr) m_scanProcessThread = new QThread;
    m_scanWorker->moveToThread(m_scanProcessThread);
    connect(m_scanProcessThread, &QThread::started, m_scanWorker, &ScanWorker::doWork);
    m_scanProcessThread->start();
}
void CashingWindow::notifyScanPageUnloaded() {
    if (m_scanProcessThread) {
        disconnect(m_scanProcessThread, &QThread::started, m_scanWorker, &ScanWorker::doWork);
        m_scanProcessThread->quit(); m_scanProcessThread->wait();
    }
}
void CashingWindow::onCheckScanSuccess(QByteArray fJ, QByteArray bJ, QByteArray fT, QByteArray bT, QString m) {
    m_checkFrontImage = QImage::fromData(fJ, "JPEG");
    m_checkBackImage = QImage::fromData(bJ, "JPEG");
    m_checkFrontTiff = fT; m_checkBackTiff = bT; m_micrData = m;
    emit checkScanCompleted();
}
void CashingWindow::onCheckScanFailure(const QString& r) { emit checkScanFailed(r); }
void CashingWindow::onScannerConnected(bool ok) { m_checkScannerReady = ok; }

void CashingWindow::notifyFingerPageLoaded() {
    if (m_imageProcessThread && m_imageProcessThread->isRunning()) return;
    if (!m_imageProcessThread) m_imageProcessThread = new QThread;
    if (!m_fingerWorker) m_fingerWorker = new FingerWorker(this);
    m_fingerWorker->moveToThread(m_imageProcessThread);
    QObject::disconnect(m_imageProcessThread, &QThread::started, nullptr, nullptr);
    QObject::connect(m_imageProcessThread, &QThread::started, m_fingerWorker, &FingerWorker::doWork);
    QObject::connect(m_imageProcessThread, &QThread::finished, m_fingerWorker, &QObject::deleteLater);
    m_imageProcessThread->start();
}
void CashingWindow::notifyFingerPageUnloaded() { cancelFingerPrint(); }
void CashingWindow::cancelFingerPrint() {
    if (m_fingerWorker) m_fingerWorker->cancelFingerPrint(m_imageProcessThread);
    if (m_imageProcessThread) { m_imageProcessThread->quit(); m_imageProcessThread->wait(); m_imageProcessThread->deleteLater(); m_imageProcessThread = nullptr; }
    m_fingerWorker = nullptr;
}
void CashingWindow::logError(const QString& message) {}
