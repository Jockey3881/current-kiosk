#ifndef CASHINGWINDOW_H
#define CASHINGWINDOW_H

#include <QObject>
#include <QNetworkAccessManager>
#include <QNetworkReply>
#include <QImage>
#include <QThread>
#include "utils/CheckScanner.h"
#include <QTimer>

class FingerWorker;
class ScanWorker;
class CheckScanner;

class CashingWindow : public QObject
{
    Q_OBJECT
    Q_PROPERTY(bool visible READ isVisible WRITE setVisible NOTIFY visibleChanged)
    Q_PROPERTY(QString phone READ getPhone WRITE setPhone NOTIFY phoneChanged)
    Q_PROPERTY(QString email READ getEmail WRITE setEmail NOTIFY emailChanged)
    Q_PROPERTY(QString pin READ getPin WRITE setPin NOTIFY pinChanged)
    Q_PROPERTY(QString veriCode READ getVeriCode WRITE setVeriCode NOTIFY veriCodeChanged)
    Q_PROPERTY(QString errorMessage READ getErrorMessage WRITE setErrorMessage NOTIFY errorMessageChanged)
    Q_PROPERTY(QString reviewMessage READ getReviewMessage WRITE setReviewMessage NOTIFY reviewMessageChanged)
    Q_PROPERTY(QImage scanIdFrontImage READ getScanIdFrontImage NOTIFY scanIdFrontImageChanged)
    Q_PROPERTY(QImage scanIdBackImage READ getScanIdBackImage NOTIFY scanIdBackImageChanged)
    Q_PROPERTY(QImage checkFrontImage READ getCheckFrontImage NOTIFY checkScanCompleted)
    Q_PROPERTY(QImage checkBackImage READ getCheckBackImage NOTIFY checkScanCompleted)
    Q_PROPERTY(QImage kioskPhoto READ getKioskPhoto NOTIFY kioskPhotoChanged)

public:
    explicit CashingWindow(QObject *parent = nullptr);
    ~CashingWindow();
    Q_INVOKABLE void testDispense(double amount);

    // Triggered by QML "Confirm" button on Fee Page
    Q_INVOKABLE void dispenseApprovedCheck();

    // --- STATE MACHINE DEFINITION ---
    enum class TransactionState {
        Idle,
        UploadingCheck,
        PollingStatus,
        FeeAcceptance,
        Authorizing,
        Dispensing
    };
    Q_ENUM(TransactionState)
    // --------------------------------

    Q_INVOKABLE bool softRearmCheckScanner();
    Q_INVOKABLE bool isCheckScannerReady() const { return m_checkScannerReady; }

    bool isVisible() const;
    QString getPhone() const;
    QString getEmail() const;
    QString getPin() const;
    QString getVeriCode() const;
    QString getErrorMessage() const;
    QString getReviewMessage() const;

    QImage getScanIdFrontImage() const;
    QImage getScanIdBackImage() const;
    QImage getCheckFrontImage() const;
    QImage getCheckBackImage() const;
    Q_INVOKABLE QImage getKioskPhoto() const;
    Q_INVOKABLE void setCheckAmount(const QString &amount);
    Q_INVOKABLE void setCheckDate(const QString &date);
    Q_INVOKABLE void setNewCustomer(bool isNew);
    Q_INVOKABLE bool isNewCustomer() const { return m_newCustomer; }

    bool getScanSuccess() const;

public slots:
    void setVisible(bool visible);
    void setPhone(const QString& phone);
    void setEmail(const QString& email);
    void setPin(const QString& pin);
    void setVeriCode(const QString& veriCode);
    void setErrorMessage(const QString& errorMsg);
    void setReviewMessage(const QString& message);

    void setFingerImage(unsigned char* pEnrollmentFmd, unsigned int EnrollmentFmdSize);
    void setScanFrontImage(unsigned char* pImage, unsigned int nImageSize);
    void setScanBackImage(unsigned char* pImage, unsigned int nImageSize);
    void captureImage(const QImage& image);
    void setScanSuccess(bool scanSuccess);

    // Getters for Machine Creds (optionally used if not reading env directly)
    void setMachineUsername(const QString& machineUsername);
    void setMachinePassword(const QString& machinePassword);
    void setServerUrlBase(const QString& serverUrlBase);

    void getAccessToken();
    void sendVerificationCode();
    void checkVerificationCode();
    void resendOTPCode();
    void login(const QString& phone, const QString& pin);
    void sendForReview();
    void customerCheck();
    void startCheckScan();

    // --- NEW METHODS FOR CLOSED LOOP FLOW ---
    void checkStatus();
    void confirmTransaction(const QString& checkId, double fee, double payout);
    void completeTransaction(const QString& result, double amountDispensed);
    // ----------------------------------------

    void on_btnKioskHome_clicked();
    void closeEvent();
    void exitApplication();
    void notifyFingerPageLoaded();
    void notifyFingerPageUnloaded();
    void cancelFingerPrint();
    void notifyScanPageLoaded();
    void notifyScanPageUnloaded();
    void cancelScanId();

    bool isPinValid(const QString& pinNumber);

signals:
    void visibleChanged();
    void phoneChanged();
    void emailChanged();
    void pinChanged();
    void veriCodeChanged();
    void errorMessageChanged();
    void reviewMessageChanged();
    void scanIdFrontImageChanged();
    void scanIdBackImageChanged();
    void kioskPhotoChanged();

    void sendVerificationCodeSuccess();
    void sendVerificationCodeFailure();
    void resendVerificationCodeFailure();
    void checkVerificationCodeSuccess();
    void checkVerificationCodeFailure();
    void loginSuccess(const QString& firstName, const QString& lastName);
    void loginFailure(const QString& errorMessage);

    void sendReviewDataSuccess();
    void sendReviewDataFailure();

    // Check Scanner Signals
    void checkScanCompleted();
    void checkScanFailed(const QString& error);
    void customerCheckSuccess();
    void customerCheckFailure(const QString& errorMessage);
    void scannerReadyChanged();
    void checkScannerReady();

    // Fingerprint Scanner Signals
    void fingerPrintStarted();
    void fingerPrintCompleted();
    void fingerPrintFailure(bool, QString);

    // ID Scanner Signals
    void scanIdCompleted();
    void scanIdFailure(bool, QString);

    // --- NEW SIGNALS FOR FLOW ---
    void feeProposalReceived(double fee, double payout, QString checkId);
    void checkStatusRejected(QString reason);
    void dispenseAuthorized(double amount, QString txId);
    void confirmTransactionFailed(QString msg);

    // ⭐ NEW: Phase 3 Dispense Signals (QML-compatible)
    void dispenseSuccess(double amount, int totalBills, QString breakdown);
    void dispenseFailed(QString errorMessage);

private slots:
    void extractAccessToken();
    void analyzeSendVerificationCodeResult();
    void analyzeResendVerificationCodeResult();
    void analyzeCheckVerificationCodeResult();
    void analyzeLoginResult();
    void analyzeSendForReviewResult();
    void analyzeCustomerCheckResult();

    // NEW
    void analyzeCheckStatusResult();
    void analyzeConfirmTransactionResult();
    void analyzeCompleteTransactionResult();
    void onPollTimerTriggered(); // <--- POLLING SLOT

    void onScannerConnected(bool ok);
    void onCheckScanSuccess(QByteArray frontJpeg, QByteArray backJpeg, QByteArray frontTiff, QByteArray backTiff, QString micrData);
    void onCheckScanFailure(const QString &error);

private:
    void SendOTPCode();
    void logError(const QString& message);
    void setState(TransactionState newState); // Helper

    // ⭐ NEW: Helper to perform the actual hardware dispense after API approval
    void performHardwareDispense(double amount);

private:
    bool m_newCustomer = false;
    bool m_visible;
    QString m_phone;
    QString m_email;
    QString m_pin;
    QString m_veriCode;
    QString m_errorMessage;
    QString m_reviewMessage;
    QImage m_scanFront;
    QImage m_scanBack;
    QImage m_photo;
    QImage m_checkFrontImage;
    QImage m_checkBackImage;
    QString m_checkAmount;
    QString m_checkDate;
    bool m_checkScanInFlight = false;
    bool m_emittedFailThisAttempt = false;
    bool m_scanSuccess;
    unsigned char* m_EnrollmentFmd;
    unsigned int m_EnrollmentFmdSize;

    bool m_scannerReady = false;
    bool m_isScanning = false;
    QTimer m_scanRetryTimer;
    int m_scanRetryMs = 500;

    QNetworkAccessManager m_networkManager;
    QNetworkReply* m_reply;
    QString m_accessToken;
    QString m_customerId;

    // Track current transaction ID for the closed loop
    QString m_currentCheckId;
    QString m_currentTxId;

    // Store fee details for confirmation
    double m_lastProposedFee = 0.0;
    double m_lastProposedPayout = 0.0;

    QString m_machineUsername;
    QString m_machinePassword;
    QString m_serverUrlBase;

    // API Endpoints
    QString m_apiMachineLogin;
    QString m_apiSendCode;
    QString m_apiVerifyCode;
    QString m_apiCustomer;
    QString m_apiCustomerLogin;
    QString m_apiCustomerCheck;
    QString m_apiCheckStatus;       // NEW
    QString m_apiConfirmTransaction;// NEW

    QThread* m_imageProcessThread;
    QThread* m_scanProcessThread;
    FingerWorker* m_fingerWorker;
    ScanWorker* m_scanWorker;
    CheckScanner* m_checkScanner;
    bool m_checkScannerReady = false;

    QByteArray m_checkFrontTiff;
    QByteArray m_checkBackTiff;
    QString m_micrData;

    // --- STATE MACHINE VARS ---
    TransactionState m_state;
    QTimer* m_pollTimer;
    // --------------------------
};

#endif // CASHINGWINDOW_H
