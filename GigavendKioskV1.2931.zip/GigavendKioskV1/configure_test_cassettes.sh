#!/bin/bash
# Configure test cassettes for development

# FIXED: Match the path from your app logs
DB_PATH="$HOME/.local/share/appKiosk/ej.db"
MACHINE_ID="KIOSK-DEV-001"

# Ensure directory exists
mkdir -p "$(dirname "$DB_PATH")"

echo "Configuring test cassettes in: $DB_PATH"

sqlite3 "$DB_PATH" <<EOF
-- Configure 6 cassettes with standard denominations
INSERT OR REPLACE INTO cassette_config (machine_id, cassette_number, denomination, capacity, low_threshold, critical_threshold, is_enabled) VALUES
('$MACHINE_ID', 1, 1, 500, 100, 50, 1),      -- Cassette 1: \$1 bills
('$MACHINE_ID', 2, 5, 200, 40, 20, 1),       -- Cassette 2: \$5 bills
('$MACHINE_ID', 3, 10, 200, 40, 20, 1),      -- Cassette 3: \$10 bills
('$MACHINE_ID', 4, 20, 200, 40, 20, 1),      -- Cassette 4: \$20 bills
('$MACHINE_ID', 5, 50, 100, 20, 10, 1),      -- Cassette 5: \$50 bills
('$MACHINE_ID', 6, 100, 100, 20, 10, 1);     -- Cassette 6: \$100 bills

-- Set initial inventory (test amounts)
INSERT OR REPLACE INTO cassette_inventory (machine_id, cassette_number, current_count) VALUES
('$MACHINE_ID', 1, 500),   -- 500 x \$1 = \$500
('$MACHINE_ID', 2, 200),   -- 200 x \$5 = \$1,000
('$MACHINE_ID', 3, 200),   -- 200 x \$10 = \$2,000
('$MACHINE_ID', 4, 200),   -- 200 x \$20 = \$4,000
('$MACHINE_ID', 5, 100),   -- 100 x \$50 = \$5,000
('$MACHINE_ID', 6, 100);   -- 100 x \$100 = \$10,000
                           -- TOTAL = \$22,500
EOF

echo "✅ Test cassettes configured!"
echo "Total cash available: \$22,500"
echo ""
echo "Cassette configuration:"
sqlite3 "$DB_PATH" "SELECT cassette_number, denomination, current_count FROM cassette_config JOIN cassette_inventory USING (machine_id, cassette_number) WHERE machine_id='$MACHINE_ID';"
