#ifndef CONSTANTS_H
#define CONSTANTS_H

#define KIOSK_APPID             "com.genmega.kiosk"
#define ATM_APPID               "com.genmega.atm"
#define DISPENSE_APPID          "com.genmega.dispense"
#define LEDGER_APPID            "com.genmega.ledger"

#define KIOSK_HOME_MODE         "kiosk home"
#define KIOSK_CASHING_MODE      "cashing"
#define KIOSK_ATM_MODE          "atm"
#define ATM_TRANSACTION_MODE    "transaction"
#define DISPENSE_APP_MODE       "dispense"
#define LEDGER_APP_MODE         "ledger"

#define KIOSK_APP_NAME          "KIOSK Home"
#define ATM_APPLICATION_NAME    "LxATM"
#define DISPENSE_APP_NAME       "CDU Dispense"
#define LEDGER_APP_NAME         "CDU Ledger"

enum EVENT_EMITID {
    EVENT_EMITID_Empty = -1,
    EVENT_EMITID_InitializedApp = 0,
    EVENT_EMITID_ChangedActiveApp,

    EVENT_EMITID_CDUInitializeCompleted,
    EVENT_EMITID_CDUDispenseFailed,
    EVENT_EMITID_CDUDispenseCompleted,
    EVENT_EMITID_CDUDeviceError,

    EVENT_EMITID_MCRCardNotPresented,
    EVENT_EMITID_MCRCardPresented,
    EVENT_EMITID_MCRCardReadCompleted,
    EVENT_EMITID_MCRCardReadError,
    EVENT_EMITID_MCRAcceptCardCanceled,
    EVENT_EMITID_MCRDeviceError,

    EVENT_EMITID_EPPDeviceOpened,
    EVENT_EMITID_EPPEncryptCompleted,
    EVENT_EMITID_EPPEncryptCanceled,
    EVENT_EMITID_EPPEncryptStarted,
    EVENT_EMITID_EPPDownloadKeyCompleted,
    EVENT_EMITID_EPPDeviceError,

    EVENT_EMITID_SIUSetIndicatorCompleted,
    EVENT_EMITID_SIUAudioGuidanceChanged,
    EVENT_EMITID_SIUStatusChanged,
    EVENT_EMITID_SIUDeviceError,

    EVENT_EMITID_MAX
};

enum ATM_STATUS {
    ATM_STATUS_INITIALIZE = 0,
    ATM_STATUS_TRANSACTION,
    ATM_STATUS_AFTERTRANSACTION
};

#endif // CONSTANTS_H
