#include <QDir>
#include <QtWidgets/QMessageBox>
#include <QTimer>
#include "LxGenDevAppManager.h"
#include "constants.h"
#include "kioskwindow.h"
#include "atmwindow.h"
#include "cashingwindow.h"
#include "dispensewindow.h"
#include "ledgerwindow.h"
#include "atmhostlogger.h"

KioskWindow::KioskWindow(QObject *parent)
    : QObject{parent}
{
    // Initialize the startup flag to true.
    m_isInitializing = true;

    m_strCurrentPath = QDir::currentPath();
    APPMGR_RegisterCallbackObject(this);
    APPMGR_RegCallbackChangedActiveApp(&KioskWindow::on_AppMgr_ChangedActiveApp);
    APPMGR_RegCallbackInitializedApp(&KioskWindow::on_AppMgr_InitializedApp);
    APPMGR_RegisterApp(KIOSK_APPID, KIOSK_APP_NAME);

    m_strExecAppPath = m_strCurrentPath;
    m_lxAtmApp = new QProcess();
    m_lxAtmAppStarted = false;

    m_visible = true;
    m_atmInitialized = false;
    m_cduLicenseKey = "";
    m_message = "";
    m_atmWindow = nullptr;
    m_cashingWindow = nullptr;
    m_dispenseWindow = nullptr;
    m_ledgerWindow = nullptr;

    m_bActivatedATM = false;
    m_bActivatedDispense = false;
    m_bActivatedLedger = false;
}

KioskWindow::~KioskWindow()
{
    delete m_lxAtmApp;
}

void KioskWindow::setCDUKey(const QString &key)
{
    if (key.length() > 0)
        m_cduLicenseKey = key;
}

void KioskWindow::setVisible(bool visible)
{
    if (m_visible != visible) {
        m_visible = visible;
        emit visibleChanged();
    }
}
void KioskWindow::setMessage(const QString &message) {
    if (m_message != message) {
        m_message = message;
        emit messageChanged();
    }
}

void KioskWindow::on_btnCashingApp_clicked()
{
    APPMGR_ActivateApp(KIOSK_APPID, KIOSK_CASHING_MODE);
}

void KioskWindow::on_btnATMApp_clicked()
{
    if (m_bInitSucceeded) {
        AtmHostLogger::instance().logEvent(QStringLiteral("ATM app activation requested"),
                                           {{QStringLiteral("mode"), QString::fromLatin1(ATM_TRANSACTION_MODE)}});
        APPMGR_ActivateApp(ATM_APPID, ATM_TRANSACTION_MODE);
    } else {
        AtmHostLogger::instance().logEvent(QStringLiteral("ATM app warm activation requested"));
        APPMGR_ActivateApp(ATM_APPID, "");
    }
}

void KioskWindow::on_btnDispenseApp_clicked()
{
    APPMGR_ActivateApp(DISPENSE_APPID, DISPENSE_APP_MODE);
}

void KioskWindow::on_btnLedgerApp_clicked()
{
    APPMGR_ActivateApp(LEDGER_APPID, LEDGER_APP_MODE);
}

void KioskWindow::StartATMApplication()
{
    if (!m_lxAtmAppStarted)
    {
        char szCDUKey[256] = {0};
        strcpy(szCDUKey, m_cduLicenseKey.toLatin1().data());
        if (strlen(szCDUKey)!=15)
        {
            setMessage("CDULicenseKey must be 15 characters long.");
            AtmHostLogger::instance().logEvent(QStringLiteral("ATM startup blocked"),
                                               {{QStringLiteral("reason"), QStringLiteral("invalid CDU license key length")}});
            return;
        }
        APPMGR_SetCduLicenseKey(szCDUKey);
        AtmHostLogger::instance().logEvent(QStringLiteral("ATM CDU license key applied"));

        char szAtmExec[260] = {0};
        sprintf(szAtmExec, "%s/%s", "/usr/local/bin", ATM_APPLICATION_NAME);
        m_lxAtmApp->start(szAtmExec, QStringList() << "");
        m_lxAtmAppStarted = m_lxAtmApp->waitForStarted();
        if (!m_lxAtmAppStarted)
        {
            AtmHostLogger::instance().logEvent(QStringLiteral("ATM process launch failed"),
                                               {{QStringLiteral("executable"), QString::fromUtf8(szAtmExec)}});
            return;
        }
        AtmHostLogger::instance().logEvent(QStringLiteral("ATM process launched"),
                                           {{QStringLiteral("executable"), QString::fromUtf8(szAtmExec)}});
    }
}

void KioskWindow::on_AppMgr_ChangedActiveApp(void* pObj, bool bActive,
                                             const char* szAppid, const char* szMode, const char* szPreviousActiveAppid)
{
    KioskWindow* pWndMain = (KioskWindow*)pObj;

    pWndMain->m_strAppId = szAppid;
    pWndMain->m_strMode = szMode;
    pWndMain->m_strPreAppId = szPreviousActiveAppid;
    pWndMain->m_bActivApp = bActive;
    if(pWndMain->m_strAppId == ATM_APPID) {
        pWndMain->m_bActivatedATM = bActive;
    } else if (pWndMain->m_strAppId == DISPENSE_APPID) {
        pWndMain->m_bActivatedDispense = bActive;
    } else if (pWndMain->m_strAppId == LEDGER_APPID) {
        pWndMain->m_bActivatedLedger = bActive;
    }
    if (pWndMain->m_ledgerWindow) {
        const QString appId = szAppid ? QString::fromUtf8(szAppid) : QString();
        pWndMain->m_ledgerWindow->setActiveAppContext(appId, bActive);
    }
    pWndMain->ProcessChangedActiveApp();
}

void KioskWindow::on_AppMgr_InitializedApp(void* pObj, bool bSucceeded, const char* szAppid)
{
    KioskWindow* pWndMain = (KioskWindow*)pObj;
    pWndMain->m_strAppId = szAppid;
    pWndMain->m_bInitSucceeded = bSucceeded;
    pWndMain->ProcessInitializedApp();
}

void KioskWindow::ProcessInitializedApp()
{
    setMessage("");
    if (m_strAppId == ATM_APPID) {
        if (m_bInitSucceeded) {
            setAtmInitialized(true);
            AtmHostLogger::instance().logEvent(QStringLiteral("ATM initialization succeeded"));

            if (m_isInitializing) {
                m_isInitializing = false;

                QTimer::singleShot(100, this, [this]() {
                    APPMGR_ActivateApp(KIOSK_APPID, KIOSK_HOME_MODE);
                    // ======================= MODIFICATION START =======================
                    // Also emit the signal to explicitly grab window focus.
                    emit requestActivate();
                    // ======================= MODIFICATION END =========================
                });
            }
        } else {
            if (m_isInitializing) {
                m_isInitializing = false;
            }
            setMessage("Failed to initialized ATM application");
            AtmHostLogger::instance().logEvent(QStringLiteral("ATM initialization failed"));
        }
    }
}

void KioskWindow::ProcessChangedActiveApp()
{
    if (m_isInitializing) {
        return;
    }

    if (m_strAppId == ATM_APPID) {
        if (m_dispenseWindow)
            m_dispenseWindow->setAtmActive(m_bActivatedATM);

        if (m_bActivatedATM)
        {
            AtmHostLogger::instance().logEvent(QStringLiteral("ATM foreground control granted"));
            setVisible(false);
            if (m_cashingWindow)
                m_cashingWindow->setVisible(false);
            if (m_dispenseWindow) {
                m_dispenseWindow->setAppActive(false);
                m_dispenseWindow->setVisible(false);
            }
            if (m_ledgerWindow) {
                m_ledgerWindow->setAppActive(false);
                m_ledgerWindow->setVisible(false);
            }
            if (m_atmWindow)
                m_atmWindow->setVisible(true);
        } else
        {
            AtmHostLogger::instance().logEvent(QStringLiteral("ATM foreground control released"));
            if (m_atmWindow)
                m_atmWindow->setVisible(false);
            if (!m_bActivatedDispense && m_dispenseWindow) {
                m_dispenseWindow->setAppActive(false);
                m_dispenseWindow->setVisible(false);
            }
            if (m_ledgerWindow) {
                m_ledgerWindow->setAppActive(false);
                m_ledgerWindow->setVisible(false);
            }
            setVisible(true);
        }
    } else if (m_strAppId == DISPENSE_APPID) {
        if (m_dispenseWindow) {
            m_dispenseWindow->setAtmActive(m_bActivatedATM);
            m_dispenseWindow->setAppActive(m_bActivatedDispense);
            m_dispenseWindow->setVisible(m_bActivatedDispense);
        }

        if (m_bActivatedDispense)
        {
            setVisible(false);
            if (m_cashingWindow)
                m_cashingWindow->setVisible(false);
            if (m_atmWindow)
                m_atmWindow->setVisible(false);
            if (m_ledgerWindow) {
                m_ledgerWindow->setAppActive(false);
                m_ledgerWindow->setVisible(false);
            }
        } else
        {
            if (m_cashingWindow)
                m_cashingWindow->setVisible(false);
            if (m_atmWindow)
                m_atmWindow->setVisible(false);
            if (m_ledgerWindow) {
                m_ledgerWindow->setAppActive(false);
                m_ledgerWindow->setVisible(false);
            }
            setVisible(true);
        }
    } else if (m_strAppId == LEDGER_APPID) {
        if (m_ledgerWindow) {
            m_ledgerWindow->setAppActive(m_bActivatedLedger);
            m_ledgerWindow->setVisible(m_bActivatedLedger);
        }

        if (m_bActivatedLedger)
        {
            setVisible(false);
            if (m_cashingWindow)
                m_cashingWindow->setVisible(false);
            if (m_atmWindow)
                m_atmWindow->setVisible(false);
            if (m_dispenseWindow) {
                m_dispenseWindow->setAppActive(false);
                m_dispenseWindow->setVisible(false);
            }
        } else
        {
            if (m_cashingWindow)
                m_cashingWindow->setVisible(false);
            if (m_atmWindow)
                m_atmWindow->setVisible(false);
            if (m_dispenseWindow) {
                m_dispenseWindow->setAppActive(false);
                m_dispenseWindow->setVisible(false);
            }
            setVisible(true);
        }
    } else if (m_strAppId == KIOSK_APPID)
    {
        if (m_strMode == KIOSK_HOME_MODE)
        {
            setVisible(true);
            // ======================= MODIFICATION START =======================
            // When returning to the home screen, also request focus.
            emit requestActivate();
            // ======================= MODIFICATION END =========================
            if (m_cashingWindow)
                m_cashingWindow->setVisible(false);
            if (m_atmWindow)
                m_atmWindow->setVisible(false);
            if (m_dispenseWindow) {
                m_dispenseWindow->setAppActive(false);
                m_dispenseWindow->setVisible(false);
            }
            if (m_ledgerWindow) {
                m_ledgerWindow->setAppActive(false);
                m_ledgerWindow->setVisible(false);
            }
        } else if (m_strMode == KIOSK_CASHING_MODE)
        {
            setVisible(false);
            if (m_cashingWindow)
                m_cashingWindow->setVisible(true);
            if (m_atmWindow)
                m_atmWindow->setVisible(false);
            if (m_dispenseWindow) {
                m_dispenseWindow->setAppActive(false);
                m_dispenseWindow->setVisible(false);
            }
            if (m_ledgerWindow) {
                m_ledgerWindow->setAppActive(false);
                m_ledgerWindow->setVisible(false);
            }
        }
        char szResult[32]={0};
        if(APPMGR_GetAppResult(ATM_APPID, szResult, sizeof(szResult)) >= 0) {
            char szMessage[64] = {0};
            sprintf(szMessage, "ATM Transaction Result : %s", szResult);
            AtmHostLogger::instance().logInboundMessage(QStringLiteral("ATM host result"), QByteArray(szResult));
        }
    }
    m_strAppId.clear();
    m_strMode.clear();
    m_strPreAppId.clear();
}

void KioskWindow::closeEvent()
{
    AtmHostLogger::instance().logEvent(QStringLiteral("Kiosk shutdown initiated"));
    m_lxAtmApp->kill();
    APPMGR_UnregisterApp("com.genmega.kiosk");
}
