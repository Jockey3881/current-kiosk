#ifndef CHECKCASHINGINTEGRATION_H
#define CHECKCASHINGINTEGRATION_H

#include "CashLedgerSingleton.h"
#include <QString>
#include <QMessageBox>
#include <cmath> // Required for std::round

/**
 * Helper class for CheckCashing integration
 *
 * Provides Qt-friendly wrappers around CashLedgerManager
 */
class CheckCashingIntegration {
public:
    /**
     * Initialize cash management system
     *
     * Call this in main.cpp before showing main window
     *
     * @param machineId - Kiosk identifier (from env or config)
     * @param serverUrl - Backend API URL
     * @param dbPath - Path to SQLite database
     * @return true if successful
     */
    static bool Initialize(const QString& machineId,
                           const QString& serverUrl,
                           const QString& dbPath) {
        return CashLedgerSingleton::Initialize(
            machineId.toStdString(),
            serverUrl.toStdString(),
            dbPath.toStdString()
            );
    }

    /**
     * Dispense cash for check cashing transaction
     *
     * @param amountDollars - Amount in dollars (e.g., 100.00)
     * @param checkTxId - Check transaction UUID
     * @param customerId - Customer UUID
     * @param parent - Parent widget for error dialogs
     * @return DispenseResult with success flag and details
     */
    static DispenseResult DispenseCashForCheck(double amountDollars,
                                               const QString& checkTxId,
                                               const QString& customerId,
                                               QWidget* parent = nullptr) {
        // Get instance
        CashLedgerManager* ledger = CashLedgerSingleton::Instance();
        if (!ledger) {
            if (parent) {
                QMessageBox::critical(parent, "Error",
                                      "Cash management system not initialized");
            }

            DispenseResult error_result;
            error_result.success = false;
            error_result.error_message = "Cash management system not initialized";
            return error_result;
        }

        // Validate
        if (amountDollars <= 0.0) {
            if (parent) {
                QMessageBox::warning(parent, "Invalid Amount",
                                     "Dispense amount must be greater than zero");
            }

            DispenseResult error_result;
            error_result.success = false;
            error_result.error_message = "Invalid amount";
            return error_result;
        }

        // FIXED: Convert dollars to cents (integer arithmetic)
        int amountCents = static_cast<int>(std::round(amountDollars * 100.0));

        // Check availability (Using cents)
        if (!ledger->CanDispense(amountCents)) {
            if (parent) {
                QMessageBox::warning(parent, "Insufficient Cash",
                                     QString("Cannot dispense $%1\n\n"
                                             "Possible reasons:\n"
                                             "- Insufficient cash in cassettes\n"
                                             "- Exact change not available\n"
                                             "- CDU hardware not initialized")
                                         .arg(amountDollars, 0, 'f', 2));
            }

            DispenseResult error_result;
            error_result.success = false;
            error_result.error_message = "Cannot dispense - insufficient cash or exact change unavailable";
            return error_result;
        }

        // Dispense (Using cents)
        return ledger->DispenseCash(
            amountCents,
            "CheckCashing",
            checkTxId.toStdString(),
            customerId.toStdString()
            );
    }

    /**
     * Get total available cash in dollars
     *
     * @return Total cash in dollars
     */
    static double GetTotalCashDollars() {
        CashLedgerManager* ledger = CashLedgerSingleton::Instance();
        if (!ledger) return 0.0;

        // FIXED: Use GetTotalCashValueCents() and convert to dollars
        int totalCents = ledger->GetTotalCashValueCents();
        return totalCents / 100.0;
    }

    /**
     * Sync pending records to server
     *
     * @return Number of records synced (0 if failed or nothing to sync)
     */
    static int SyncToServer() {
        CashLedgerManager* ledger = CashLedgerSingleton::Instance();
        if (!ledger) return 0;

        return ledger->SyncToServer();
    }

    /**
     * Shutdown cash management system
     *
     * Call this before application exit
     */
    static void Shutdown() {
        CashLedgerSingleton::Shutdown();
    }

    /**
     * Format DispenseResult as user-friendly string
     *
     * @param result - Dispense result
     * @return Formatted string for display
     */
    static QString FormatDispenseResult(const DispenseResult& result) {
        if (!result.success) {
            return QString("Dispense failed:\n%1")
            .arg(QString::fromStdString(result.error_message));
        }

        // FIXED: Use amount_cents converted to dollars
        QString msg = QString("Successfully dispensed $%1\n\n")
                          .arg(result.amount_cents / 100.0, 0, 'f', 2);

        msg += QString("Total bills: %1\n\n").arg(result.total_bills);

        msg += "Breakdown:\n";
        // Iterate highest denomination first (Phase 2 standard)
        if (result.bills_from_cst6 > 0) msg += QString("  %1 x $100\n").arg(result.bills_from_cst6);
        if (result.bills_from_cst5 > 0) msg += QString("  %1 x $50\n").arg(result.bills_from_cst5);
        if (result.bills_from_cst4 > 0) msg += QString("  %1 x $20\n").arg(result.bills_from_cst4);
        if (result.bills_from_cst3 > 0) msg += QString("  %1 x $10\n").arg(result.bills_from_cst3);
        if (result.bills_from_cst2 > 0) msg += QString("  %1 x $5\n").arg(result.bills_from_cst2);
        if (result.bills_from_cst1 > 0) msg += QString("  %1 x $1\n").arg(result.bills_from_cst1);

        return msg;
    }
};

#endif // CHECKCASHINGINTEGRATION_H
