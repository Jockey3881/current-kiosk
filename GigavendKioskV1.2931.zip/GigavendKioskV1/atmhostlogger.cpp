#include "atmhostlogger.h"

#include <QDateTime>
#include <QFile>
#include <QMutexLocker>
#include <QTextStream>

namespace {
constexpr const char *kLogFile = "atm_host_communications.log";

QString directionLabel(AtmHostLogger::Direction direction)
{
    switch (direction) {
    case AtmHostLogger::Direction::Outbound:
        return QStringLiteral("OUTBOUND");
    case AtmHostLogger::Direction::Inbound:
        return QStringLiteral("INBOUND");
    case AtmHostLogger::Direction::Event:
    default:
        return QStringLiteral("EVENT");
    }
}

QString describeControl(unsigned char value)
{
    switch (value) {
    case 0x02:
        return QStringLiteral("<STX>");
    case 0x03:
        return QStringLiteral("<ETX>");
    case 0x04:
        return QStringLiteral("<EOT>");
    case 0x1C:
        return QStringLiteral("<FS>");
    case 0x1D:
        return QStringLiteral("<GS>");
    case 0x1E:
        return QStringLiteral("<RS>");
    case 0x1F:
        return QStringLiteral("<US>");
    default:
        return QStringLiteral("<0x%1>").arg(value, 2, 16, QLatin1Char('0')).toUpper();
    }
}
}

AtmHostLogger &AtmHostLogger::instance()
{
    static AtmHostLogger logger;
    return logger;
}

AtmHostLogger::AtmHostLogger() = default;

void AtmHostLogger::logOutboundMessage(const QString &summary, const QByteArray &payload)
{
    QString detail = formatPayload(payload);
    if (!payload.isEmpty()) {
        detail = QStringLiteral("bytes=%1 | %2").arg(payload.size()).arg(detail);
    }
    appendEntry(Direction::Outbound, summary, detail);
}

void AtmHostLogger::logInboundMessage(const QString &summary, const QByteArray &payload)
{
    QString detail = formatPayload(payload);
    if (!payload.isEmpty()) {
        detail = QStringLiteral("bytes=%1 | %2").arg(payload.size()).arg(detail);
    }
    appendEntry(Direction::Inbound, summary, detail);
}

void AtmHostLogger::logEvent(const QString &summary, const QVariantMap &details)
{
    appendEntry(Direction::Event, summary, formatDetails(details));
}

void AtmHostLogger::logTotalsUpdate(const QString &context,
                                    const QString &count,
                                    const QStringList &cassetteDetails)
{
    QVariantMap details;
    if (!count.isEmpty()) {
        details.insert(QStringLiteral("count"), count);
    }
    if (!cassetteDetails.isEmpty()) {
        details.insert(QStringLiteral("cassettes"), cassetteDetails.join(QLatin1String(",")));
    }
    appendEntry(Direction::Event,
                QStringLiteral("Totals Update (%1)").arg(context),
                formatDetails(details));
}

void AtmHostLogger::appendEntry(Direction direction,
                                const QString &summary,
                                const QString &detail)
{
    QMutexLocker locker(&m_mutex);

    QFile file(QString::fromLatin1(kLogFile));
    if (!file.open(QIODevice::WriteOnly | QIODevice::Append | QIODevice::Text)) {
        return;
    }

    QTextStream stream(&file);
    stream << QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss.zzz")
           << " | " << directionLabel(direction)
           << " | " << summary;
    if (!detail.isEmpty()) {
        stream << " | " << detail;
    }
    stream << '\n';
    stream.flush();
}

QString AtmHostLogger::formatPayload(const QByteArray &payload) const
{
    if (payload.isEmpty()) {
        return QString();
    }

    const QString hex = QString::fromLatin1(payload.toHex(' ')).toUpper();

    QStringList asciiSegments;
    asciiSegments.reserve(payload.size());
    for (const auto byte : payload) {
        const unsigned char value = static_cast<unsigned char>(byte);
        if (value >= 0x20 && value <= 0x7E) {
            asciiSegments.append(QString(QChar(value)));
        } else {
            asciiSegments.append(describeControl(value));
        }
    }

    return QStringLiteral("payloadHex=%1 | payloadAscii=%2")
        .arg(hex, asciiSegments.join(QString()));
}

QString AtmHostLogger::formatDetails(const QVariantMap &details) const
{
    if (details.isEmpty()) {
        return QString();
    }

    QStringList parts;
    parts.reserve(details.size());
    for (auto it = details.constBegin(); it != details.constEnd(); ++it) {
        parts.append(QStringLiteral("%1=%2").arg(it.key(), it.value().toString()));
    }
    return parts.join(QStringLiteral(" | "));
}
