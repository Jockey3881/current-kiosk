#ifndef ATMWINDOW_H
#define ATMWINDOW_H

#include <QObject>

class AtmWindow : public QObject
{
    Q_OBJECT
    Q_PROPERTY(bool visible READ isVisible WRITE setVisible NOTIFY visibleChanged)
public:
    AtmWindow(QObject *parent = nullptr);
    ~AtmWindow();

    bool isVisible() const {
        return m_visible;
    }
    void setVisible(bool visible);

signals:
    void visibleChanged();

public slots:
    void on_btnKioskHome_clicked();

protected:
    void closeEvent();

private:
    bool m_visible;
};

#endif // ATMWINDOW_H
