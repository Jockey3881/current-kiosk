#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QQmlContext>
#include <QProcessEnvironment>
#include <QFile>
#include <QTextStream>
#include <QDateTime>
#include <QDebug>
#include <QThread>
#include <QQuickWindow>
#include <QStandardPaths>
#include <QDir>
#include <csignal>
#include "kioskwindow.h"
#include "atmwindow.h"
#include "cashingwindow.h"
#include "dispensewindow.h"
#include "ledgerwindow.h"
#include "utils/scanidimageprovider.h"
#include "utils/checkimageprovider.h"
#include "constants.h"
#include <fstream>

// ============================================================================
// PHASE 3: CDU Cash Management Integration
// ============================================================================
#include "CheckCashingIntegration.h"
#include "CashLedgerSingleton.h" // <--- ADDED THIS

// Function to find a process ID by name
pid_t find_pid_by_name(const char *process_name) {
    // This is a placeholder implementation.
    return -1;
}

// Function to kill a process by PID
int kill_process(pid_t pid, int signal_num) {
    if (pid > 0) {
        return kill(pid, signal_num);
    }
    return -1;
}

// Custom message handler for logging
void customMessageOutput(QtMsgType type, const QMessageLogContext &context, const QString &msg) {
    QFile logFile("app.log");

    if (!logFile.open(QIODevice::WriteOnly | QIODevice::Append | QIODevice::Text)) {
        fprintf(stderr, "Failed to open log file: %s\n", qPrintable(logFile.fileName()));
        return;
    }

    QTextStream logStream(&logFile);
    logStream << QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss.zzz ")
              << "[" << QThread::currentThreadId() << "] "
              << msg << " (" << context.file << ":" << context.line << ", " << context.function << ")"
              << "\n";
    logStream.flush();
}


int main(int argc, char *argv[])
{
    // Kill existing ATM application if running
    const char *target_process_name = ATM_APPLICATION_NAME;
    pid_t pid = find_pid_by_name(target_process_name);

    if (pid != -1) {
        kill_process(pid, SIGTERM);
        QThread::sleep(1);
    }

    qInstallMessageHandler(customMessageOutput);
    Q_INIT_RESOURCE(resources);
    QGuiApplication app(argc, argv);

    // Set application metadata (for QStandardPaths)
    QCoreApplication::setOrganizationName("Gigavend");
    QCoreApplication::setOrganizationDomain("gigavend.com");
    QCoreApplication::setApplicationName("GigavendKioskV1");

    QProcessEnvironment env = QProcessEnvironment::systemEnvironment();

    // Load configuration from environment
    QString cduLicenseKey = env.value("CDU_LICENSEKEY", "");

    // ========================================================================
    // PHASE 3: Initialize Cash Management System
    // ========================================================================

    qInfo() << "╔════════════════════════════════════════════════════╗";
    qInfo() << "║  Gigavend Kiosk V1 - Cash Management Init         ║";
    qInfo() << "╚════════════════════════════════════════════════════╝";

    // 1. DEFINE VARIABLES FIRST (This was the cause of your error)
    QString machineId = env.value("KIOSK_MACHINE_ID", "KIOSK-DEV-001");
    QString serverUrl = env.value("SERVER_URL_BASE", "https://checkreview.hardcracker.com");

    // Database path - use Qt standard location
    QString appDataPath = QStandardPaths::writableLocation(QStandardPaths::AppDataLocation);
    QDir().mkpath(appDataPath);  // Create directory if doesn't exist
    QString cashDbPath = appDataPath + "/ej.db";

    qInfo() << "Cash Management Configuration:";
    qInfo() << "  Machine ID:" << machineId;
    qInfo() << "  Server URL:" << serverUrl;
    qInfo() << "  Database:  " << cashDbPath;

    // 2. NOW INITIALIZE SINGLETONS (Variables are now valid)

    // Initialize CashLedgerSingleton specifically for the GUI/LedgerWindow
    CashLedgerSingleton::Initialize(machineId.toStdString(), serverUrl.toStdString(), cashDbPath.toStdString());

    // Initialize the legacy integration (Keep this if you still rely on it for other parts)
   // bool cashMgmtInitialized = CheckCashingIntegration::Initialize(
   //     machineId,
    //    serverUrl,
   //    cashDbPath
    //    );
//
   // if (!cashMgmtInitialized) {
   //     qCritical() << "❌ CRITICAL: Failed to initialize cash management system!";
   //     qCritical() << "Cash dispensing will be UNAVAILABLE.";
   //     qCritical() << "Check logs above for error details.";
  // } else {
   //     qInfo() << "✅ Cash management system initialized successfully";
//
  //      double totalCash = CheckCashingIntegration::GetTotalCashDollars();
  //      qInfo() << "💰 Total cash available: $" << QString::number(totalCash, 'f', 2);
//
  //      if (totalCash == 0.0) {
 //           qWarning() << "⚠️  WARNING: No cash in cassettes! Configure via web dashboard.";
 //       }
 //   }

    qInfo() << "════════════════════════════════════════════════════";

    // ========================================================================
    // Initialize Kiosk Windows
    // ========================================================================

    KioskWindow winKiosk;
    CashingWindow winCashing;
    AtmWindow winAtm;
    DispenseWindow winDispense;
    LedgerWindow winLedger;

    winKiosk.setAtmWindow(&winAtm);
    winKiosk.setCashingWindow(&winCashing);
    winKiosk.setDispenseWindow(&winDispense);
    winKiosk.setLedgerWindow(&winLedger);

    // Only set the CDU key on the main kiosk window
    winKiosk.setCDUKey(cduLicenseKey);

    // CashingWindow has already loaded creds from env, so we can just call this.
    winCashing.getAccessToken();

    // Start ATM application
    winKiosk.StartATMApplication();

    // ========================================================================
    // Setup QML Engine
    // ========================================================================

    ScanIdImageProvider* provider = new ScanIdImageProvider(&winCashing);
    CheckImageProvider* checkProvider = new CheckImageProvider(&winCashing);

    QQmlApplicationEngine engine;
    engine.addImportPath(QStringLiteral("qrc:/"));
    engine.addImageProvider(QLatin1String("scanImageProvider"), provider);
    engine.addImageProvider(QLatin1String("checkImageProvider"), checkProvider);

    QQmlContext* rootContext = engine.rootContext();
    rootContext->setContextProperty("KioskWindow", &winKiosk);
    rootContext->setContextProperty("CashingWindow", &winCashing);
    rootContext->setContextProperty("AtmWindow", &winAtm);
    rootContext->setContextProperty("DispenseWindow", &winDispense);
    rootContext->setContextProperty("LedgerWindow", &winLedger);

    QObject::connect(
        &engine,
        &QQmlApplicationEngine::objectCreationFailed,
        &app,
        []() { QCoreApplication::exit(-1); },
        Qt::QueuedConnection);

    engine.loadFromModule("Kiosk", "Main");

    qInfo() << "╔════════════════════════════════════════════════════╗";
    qInfo() << "║  Kiosk Application Running - Event Loop Started   ║";
    qInfo() << "╚════════════════════════════════════════════════════╝";

    // Run event loop
    int exitCode = app.exec();

    // ========================================================================
    // PHASE 3: Cleanup Cash Management Before Exit
    // ========================================================================

    qInfo() << "";
    qInfo() << "═══════════════════════════════════════════════════";
    qInfo() << "Application shutting down...";
    qInfo() << "Cleaning up cash management system...";

    CashLedgerSingleton::Shutdown(); // <--- ADDED THIS
    CheckCashingIntegration::Shutdown();

    qInfo() << "✅ Cash management shutdown complete";
    qInfo() << "Goodbye! Exit code:" << exitCode;
    qInfo() << "═══════════════════════════════════════════════════";

    return exitCode;
}
