#ifndef ROBUSTCDUDISPENSEMANAGER_H
#define ROBUSTCDUDISPENSEMANAGER_H

#include "CashLedgerManager.h"
#include <string>
#include <vector>
#include <chrono>

// Detailed breakdown struct
struct CassetteDispenseInfo {
    int cassette_number;
    int notes_requested;
    int notes_dispensed;
    int total_rejected;
    // ... other fields optional for now
};

struct RobustDispenseResult : public DispenseResult {
    int attempts_made;
    double partial_amount;
    std::vector<CassetteDispenseInfo> cassette_details;
    std::string recovery_action;
    std::vector<std::string> error_log;
    std::chrono::system_clock::time_point start_time;
    std::chrono::system_clock::time_point end_time;

    RobustDispenseResult() : DispenseResult(), attempts_made(0), partial_amount(0.0) {
        start_time = std::chrono::system_clock::now();
    }
    void Finalize() { end_time = std::chrono::system_clock::now(); }
    long GetDurationMs() const {
        return std::chrono::duration_cast<std::chrono::milliseconds>(end_time - start_time).count();
    }
};

class RobustCDUDispenseManager {
public:
    RobustCDUDispenseManager();
    ~RobustCDUDispenseManager();

    RobustDispenseResult DispenseWithRetry(
        double amount,
        const std::string& source,
        const std::string& checkTxId,
        const std::string& customerId
        );

    void SetMaxRetries(int max) { max_retry_attempts_ = max; }
    void SetMaxRejectionRate(double rate) { max_rejection_rate_ = rate; }
    void SetPCDUMode(bool enabled) { pcdu_mode_ = enabled; }
    void SetCassetteSwitching(bool enabled) { auto_cassette_switch_ = enabled; }

private:
    int max_retry_attempts_;
    double max_rejection_rate_;
    bool pcdu_mode_;
    bool auto_cassette_switch_;

    RobustDispenseResult AttemptDispense(
        const CassetteAllocation& allocation,
        int attemptNum,
        const std::string& source,
        const std::string& checkTxId,
        const std::string& customerId
        );
};

#endif
