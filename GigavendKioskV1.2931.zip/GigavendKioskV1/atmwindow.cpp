#include "atmwindow.h"
#include "LxGenDevAppManager.h"
#include "constants.h"

AtmWindow::AtmWindow(QObject *parent)
    : QObject(parent)
{
    m_visible = false;
}

AtmWindow::~AtmWindow()
{
}

void AtmWindow::on_btnKioskHome_clicked()
{
    APPMGR_NotifyInactiveApp(KIOSK_APPID, KIOSK_HOME_MODE);
}

void AtmWindow::setVisible(bool visible)
{
    if (m_visible != visible) {
        m_visible = visible;
        emit visibleChanged();
    }
}

void AtmWindow::closeEvent()
{
    APPMGR_NotifyInactiveApp(KIOSK_APPID, KIOSK_HOME_MODE);
}

