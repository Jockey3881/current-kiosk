#include "RobustCDUDispenseManager.h"
#include "CashLedgerSingleton.h"
#include "LxGenDevCashDispenser.h" // REAL HARDWARE HEADER
#include <iostream>
#include <sstream>
#include <thread>
#include <chrono>
#include <cmath> // For std::round

// Error Codes
#define CDU_ERR_MISCOUNT           0x40045
#define CDU_ERR_EMPTY_CASSETTE     -22

RobustCDUDispenseManager::RobustCDUDispenseManager()
    : max_retry_attempts_(3), max_rejection_rate_(0.20), pcdu_mode_(false), auto_cassette_switch_(true) {}

RobustCDUDispenseManager::~RobustCDUDispenseManager() {}

RobustDispenseResult RobustCDUDispenseManager::DispenseWithRetry(
    double amount,
    const std::string& source,
    const std::string& checkTxId,
    const std::string& customerId
    ) {
    RobustDispenseResult final_result;
    final_result.amount_cents = static_cast<int>(std::round(amount * 100.0));

    std::cout << "[RobustCDU] Starting robust dispense: $" << amount << std::endl;

    CashLedgerManager* ledger = CashLedgerSingleton::Instance();
    if (!ledger) {
        final_result.success = false;
        final_result.error_message = "Cash management system not initialized";
        final_result.Finalize();
        return final_result;
    }

    // --- FIX: CONVERT TO CENTS BEFORE CALCULATING ALLOCATION ---
    int amount_cents = static_cast<int>(std::round(amount * 100.0));
    CassetteAllocation allocation = ledger->CalculateBillAllocation(amount_cents);
    // -----------------------------------------------------------

    if (allocation.total_bills == 0) {
        final_result.success = false;
        final_result.error_message = "Amount cannot be dispensed with available bills";
        final_result.Finalize();
        return final_result;
    }

    // Retry Loop
    for (int attempt = 1; attempt <= max_retry_attempts_; ++attempt) {
        std::cout << "[RobustCDU] Attempt " << attempt << "..." << std::endl;

        RobustDispenseResult attempt_result = AttemptDispense(allocation, attempt, source, checkTxId, customerId);
        final_result.attempts_made = attempt;

        if (attempt_result.success) {
            std::cout << "[RobustCDU] ✅ Dispense successful on attempt " << attempt << std::endl;

            // Commit to Database
            ledger->RecordDispenseToEJ(
                amount,
                allocation.bills_from_cst1, allocation.bills_from_cst2,
                allocation.bills_from_cst3, allocation.bills_from_cst4,
                allocation.bills_from_cst5, allocation.bills_from_cst6,
                source, checkTxId, customerId
                );

            // Populate Final Result
            final_result.success = true;
            final_result.total_bills = allocation.total_bills;
            final_result.bills_from_cst1 = allocation.bills_from_cst1;
            final_result.bills_from_cst2 = allocation.bills_from_cst2;
            final_result.bills_from_cst3 = allocation.bills_from_cst3;
            final_result.bills_from_cst4 = allocation.bills_from_cst4;
            final_result.bills_from_cst5 = allocation.bills_from_cst5;
            final_result.bills_from_cst6 = allocation.bills_from_cst6;
            final_result.Finalize();
            return final_result;
        }

        std::cout << "[RobustCDU] ❌ Attempt failed: " << attempt_result.error_message << std::endl;
        std::this_thread::sleep_for(std::chrono::seconds(2)); // Wait before retry
    }

    final_result.success = false;
    final_result.error_message = "Max retries exhausted";
    final_result.Finalize();
    return final_result;
}

RobustDispenseResult RobustCDUDispenseManager::AttemptDispense(
    const CassetteAllocation& allocation,
    int attemptNum,
    const std::string& source,
    const std::string& checkTxId,
    const std::string& customerId
    ) {
    RobustDispenseResult result;

    // --- REAL HARDWARE CALL ---
    std::cout << "[RobustCDU] Calling CDUDispense..." << std::endl;
    short cdu_result = CDUDispense(
        static_cast<short>(allocation.bills_from_cst1),
        static_cast<short>(allocation.bills_from_cst2),
        static_cast<short>(allocation.bills_from_cst3),
        static_cast<short>(allocation.bills_from_cst4),
        static_cast<short>(allocation.bills_from_cst5),
        static_cast<short>(allocation.bills_from_cst6)
        );

    if (cdu_result == 0) {
        result.success = true;
    } else {
        result.success = false;
        result.error_message = "Hardware Error: " + std::to_string(cdu_result);

        // Simple auto-recovery for jams
        if (cdu_result == CDU_ERR_MISCOUNT || cdu_result == 0x4004A) {
            std::cout << "[RobustCDU] Jam/Error detected. Resetting..." << std::endl;

            // WRONG: CDUInitializeDevice(2, 0);
            // RIGHT:
            CDUInitializeDevice(false);
        }
    }
    return result;
}

// ... (Rest of helper functions like Validate/Parse can be added later) ...
