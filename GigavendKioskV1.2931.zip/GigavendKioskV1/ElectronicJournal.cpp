#include "ElectronicJournal.h"
#include <iostream>
#include <sstream>
#include <iomanip>
#include <ctime>
#include <uuid/uuid.h>

ElectronicJournal::ElectronicJournal(const std::string& db_path)
    : db_(nullptr), db_path_(db_path) {
}

ElectronicJournal::~ElectronicJournal() {
    Close();
}

bool ElectronicJournal::Initialize() {
    int rc = sqlite3_open(db_path_.c_str(), &db_);
    if (rc != SQLITE_OK) {
        std::cerr << "[EJ] Cannot open database: " << sqlite3_errmsg(db_) << std::endl;
        return false;
    }

    // UPDATED SCHEMA: Uses total_amount_cents (INTEGER)
    std::string schema = R"(
        CREATE TABLE IF NOT EXISTS cash_transactions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            transaction_uuid TEXT UNIQUE NOT NULL,
            machine_id TEXT NOT NULL,
            source TEXT NOT NULL,
            check_tx_id TEXT,
            customer_id TEXT,
            cst1_count INTEGER DEFAULT 0,
            cst2_count INTEGER DEFAULT 0,
            cst3_count INTEGER DEFAULT 0,
            cst4_count INTEGER DEFAULT 0,
            cst5_count INTEGER DEFAULT 0,
            cst6_count INTEGER DEFAULT 0,
            total_bills INTEGER NOT NULL,
            total_amount_cents INTEGER NOT NULL,
            status TEXT NOT NULL,
            error_message TEXT,
            timestamp TEXT NOT NULL,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            synced_to_server INTEGER DEFAULT 0,
            synced_at TEXT,
            sync_attempts INTEGER DEFAULT 0
        );
        CREATE INDEX IF NOT EXISTS idx_tx_sync ON cash_transactions(synced_to_server);

        CREATE TABLE IF NOT EXISTS cash_loader_events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            event_uuid TEXT UNIQUE NOT NULL,
            machine_id TEXT NOT NULL,
            operator_id INTEGER,
            operator_name TEXT,
            action TEXT NOT NULL,
            cassette_number INTEGER NOT NULL,
            old_count INTEGER NOT NULL,
            new_count INTEGER NOT NULL,
            delta INTEGER NOT NULL,
            notes TEXT,
            timestamp TEXT NOT NULL,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            synced_to_server INTEGER DEFAULT 0,
            synced_at TEXT,
            sync_attempts INTEGER DEFAULT 0
        );
        CREATE INDEX IF NOT EXISTS idx_loader_sync ON cash_loader_events(synced_to_server);

        CREATE TABLE IF NOT EXISTS cassette_inventory (
            machine_id TEXT NOT NULL,
            cassette_number INTEGER NOT NULL,
            current_count INTEGER NOT NULL DEFAULT 0,
            last_updated TEXT DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (machine_id, cassette_number)
        );

        CREATE TABLE IF NOT EXISTS cassette_config (
            machine_id TEXT NOT NULL,
            cassette_number INTEGER NOT NULL,
            denomination INTEGER NOT NULL,
            capacity INTEGER NOT NULL,
            low_threshold INTEGER NOT NULL,
            critical_threshold INTEGER NOT NULL,
            is_enabled INTEGER DEFAULT 1,
            last_updated TEXT DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (machine_id, cassette_number)
        );

        CREATE TABLE IF NOT EXISTS device_alerts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            alert_uuid TEXT UNIQUE NOT NULL,
            machine_id TEXT NOT NULL,
            alert_type TEXT NOT NULL,
            severity TEXT NOT NULL,
            cassette_number INTEGER,
            details TEXT,
            error_code TEXT,
            timestamp TEXT NOT NULL,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            resolved_at TEXT,
            synced_to_server INTEGER DEFAULT 0,
            synced_at TEXT,
            sync_attempts INTEGER DEFAULT 0
        );
        CREATE INDEX IF NOT EXISTS idx_alert_sync ON device_alerts(synced_to_server);

        CREATE TABLE IF NOT EXISTS sync_status (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            machine_id TEXT NOT NULL,
            last_sync_attempt TEXT,
            last_successful_sync TEXT,
            pending_transaction_count INTEGER DEFAULT 0,
            pending_loader_event_count INTEGER DEFAULT 0,
            pending_alert_count INTEGER DEFAULT 0,
            last_error TEXT,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            updated_at TEXT DEFAULT CURRENT_TIMESTAMP
        );
    )";

    return ExecuteSQL(schema);
}

void ElectronicJournal::Close() {
    if (db_) {
        sqlite3_close(db_);
        db_ = nullptr;
    }
}

bool ElectronicJournal::RecordTransaction(const CashTransactionRecord& record) {
    const char* sql = "INSERT INTO cash_transactions (transaction_uuid, machine_id, source, "
                      "check_tx_id, customer_id, cst1_count, cst2_count, cst3_count, cst4_count, "
                      "cst5_count, cst6_count, total_bills, total_amount_cents, status, error_message, "
                      "timestamp, synced_to_server) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    sqlite3_stmt* stmt;
    if (sqlite3_prepare_v2(db_, sql, -1, &stmt, nullptr) != SQLITE_OK) {
        std::cerr << "[EJ] Prepare failed: " << sqlite3_errmsg(db_) << std::endl;
        return false;
    }

    sqlite3_bind_text(stmt, 1, record.transaction_uuid.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(stmt, 2, record.machine_id.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(stmt, 3, record.source.c_str(), -1, SQLITE_TRANSIENT);

    if (record.check_tx_id.empty()) {
        sqlite3_bind_null(stmt, 4);
    } else {
        sqlite3_bind_text(stmt, 4, record.check_tx_id.c_str(), -1, SQLITE_TRANSIENT);
    }

    if (record.customer_id.empty()) {
        sqlite3_bind_null(stmt, 5);
    } else {
        sqlite3_bind_text(stmt, 5, record.customer_id.c_str(), -1, SQLITE_TRANSIENT);
    }

    sqlite3_bind_int(stmt, 6, record.cst1_count);
    sqlite3_bind_int(stmt, 7, record.cst2_count);
    sqlite3_bind_int(stmt, 8, record.cst3_count);
    sqlite3_bind_int(stmt, 9, record.cst4_count);
    sqlite3_bind_int(stmt, 10, record.cst5_count);
    sqlite3_bind_int(stmt, 11, record.cst6_count);
    sqlite3_bind_int(stmt, 12, record.total_bills);

    // CORRECTION: Bind as INT, not DOUBLE
    sqlite3_bind_int(stmt, 13, record.total_amount_cents);

    sqlite3_bind_text(stmt, 14, record.status.c_str(), -1, SQLITE_TRANSIENT);

    if (record.error_message.empty()) {
        sqlite3_bind_null(stmt, 15);
    } else {
        sqlite3_bind_text(stmt, 15, record.error_message.c_str(), -1, SQLITE_TRANSIENT);
    }

    sqlite3_bind_text(stmt, 16, record.timestamp.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_int(stmt, 17, record.synced_to_server ? 1 : 0);

    int rc = sqlite3_step(stmt);
    sqlite3_finalize(stmt);

    if (rc != SQLITE_DONE) {
        std::cerr << "[EJ] Insert failed: " << sqlite3_errmsg(db_) << std::endl;
        return false;
    }

    return true;
}

std::vector<CashTransactionRecord> ElectronicJournal::GetUnsyncedTransactions() {
    std::vector<CashTransactionRecord> results;
    const char* sql = "SELECT transaction_uuid, machine_id, source, check_tx_id, customer_id, "
                      "cst1_count, cst2_count, cst3_count, cst4_count, cst5_count, cst6_count, "
                      "total_bills, total_amount_cents, status, error_message, timestamp, sync_attempts "
                      "FROM cash_transactions WHERE synced_to_server = 0";

    sqlite3_stmt* stmt;
    if (sqlite3_prepare_v2(db_, sql, -1, &stmt, nullptr) != SQLITE_OK) {
        return results;
    }

    while (sqlite3_step(stmt) == SQLITE_ROW) {
        CashTransactionRecord r;
        r.transaction_uuid = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 0));
        r.machine_id = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 1));
        r.source = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 2));

        const char* ctx = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 3));
        r.check_tx_id = ctx ? ctx : "";

        const char* cid = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 4));
        r.customer_id = cid ? cid : "";

        r.cst1_count = sqlite3_column_int(stmt, 5);
        r.cst2_count = sqlite3_column_int(stmt, 6);
        r.cst3_count = sqlite3_column_int(stmt, 7);
        r.cst4_count = sqlite3_column_int(stmt, 8);
        r.cst5_count = sqlite3_column_int(stmt, 9);
        r.cst6_count = sqlite3_column_int(stmt, 10);
        r.total_bills = sqlite3_column_int(stmt, 11);
        r.total_amount_cents = sqlite3_column_int(stmt, 12);
        r.status = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 13));

        const char* err = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 14));
        r.error_message = err ? err : "";

        r.timestamp = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 15));
        r.synced_to_server = false;

        results.push_back(r);
    }

    sqlite3_finalize(stmt);
    return results;
}

bool ElectronicJournal::MarkTransactionSynced(const std::string& transaction_uuid) {
    const char* sql = "UPDATE cash_transactions SET synced_to_server = 1, synced_at = ? WHERE transaction_uuid = ?";

    sqlite3_stmt* stmt;
    if (sqlite3_prepare_v2(db_, sql, -1, &stmt, nullptr) != SQLITE_OK) {
        return false;
    }

    std::string now = GetCurrentISO8601();
    sqlite3_bind_text(stmt, 1, now.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(stmt, 2, transaction_uuid.c_str(), -1, SQLITE_TRANSIENT);

    int rc = sqlite3_step(stmt);
    sqlite3_finalize(stmt);

    return (rc == SQLITE_DONE);
}

int ElectronicJournal::GetPendingTransactionCount() {
    const char* sql = "SELECT COUNT(*) FROM cash_transactions WHERE synced_to_server = 0";
    sqlite3_stmt* stmt;
    int count = 0;

    if (sqlite3_prepare_v2(db_, sql, -1, &stmt, nullptr) == SQLITE_OK) {
        if (sqlite3_step(stmt) == SQLITE_ROW) {
            count = sqlite3_column_int(stmt, 0);
        }
        sqlite3_finalize(stmt);
    }

    return count;
}

bool ElectronicJournal::RecordLoaderEvent(const CashLoaderEventRecord& event) {
    const char* sql = "INSERT INTO cash_loader_events (event_uuid, machine_id, operator_id, operator_name, "
                      "action, cassette_number, old_count, new_count, delta, notes, timestamp, synced_to_server) "
                      "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    sqlite3_stmt* stmt;
    if (sqlite3_prepare_v2(db_, sql, -1, &stmt, nullptr) != SQLITE_OK) {
        return false;
    }

    sqlite3_bind_text(stmt, 1, event.event_uuid.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(stmt, 2, event.machine_id.c_str(), -1, SQLITE_TRANSIENT);

    if (event.operator_id > 0) {
        sqlite3_bind_int(stmt, 3, event.operator_id);
    } else {
        sqlite3_bind_null(stmt, 3);
    }

    if (event.operator_name.empty()) {
        sqlite3_bind_null(stmt, 4);
    } else {
        sqlite3_bind_text(stmt, 4, event.operator_name.c_str(), -1, SQLITE_TRANSIENT);
    }

    sqlite3_bind_text(stmt, 5, event.action.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_int(stmt, 6, event.cassette_number);
    sqlite3_bind_int(stmt, 7, event.old_count);
    sqlite3_bind_int(stmt, 8, event.new_count);
    sqlite3_bind_int(stmt, 9, event.delta);

    if (event.notes.empty()) {
        sqlite3_bind_null(stmt, 10);
    } else {
        sqlite3_bind_text(stmt, 10, event.notes.c_str(), -1, SQLITE_TRANSIENT);
    }

    sqlite3_bind_text(stmt, 11, event.timestamp.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_int(stmt, 12, event.synced_to_server ? 1 : 0);

    int rc = sqlite3_step(stmt);
    sqlite3_finalize(stmt);

    return (rc == SQLITE_DONE);
}

std::vector<CashLoaderEventRecord> ElectronicJournal::GetUnsyncedLoaderEvents() {
    std::vector<CashLoaderEventRecord> results;
    const char* sql = "SELECT event_uuid, machine_id, operator_id, operator_name, action, "
                      "cassette_number, old_count, new_count, delta, notes, timestamp, sync_attempts "
                      "FROM cash_loader_events WHERE synced_to_server = 0";

    sqlite3_stmt* stmt;
    if (sqlite3_prepare_v2(db_, sql, -1, &stmt, nullptr) != SQLITE_OK) {
        return results;
    }

    while (sqlite3_step(stmt) == SQLITE_ROW) {
        CashLoaderEventRecord e;
        e.event_uuid = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 0));
        e.machine_id = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 1));
        e.operator_id = sqlite3_column_int(stmt, 2);

        const char* op = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 3));
        e.operator_name = op ? op : "";

        e.action = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 4));
        e.cassette_number = sqlite3_column_int(stmt, 5);
        e.old_count = sqlite3_column_int(stmt, 6);
        e.new_count = sqlite3_column_int(stmt, 7);
        e.delta = sqlite3_column_int(stmt, 8);

        const char* n = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 9));
        e.notes = n ? n : "";

        e.timestamp = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 10));
        e.synced_to_server = false;

        results.push_back(e);
    }

    sqlite3_finalize(stmt);
    return results;
}

bool ElectronicJournal::MarkLoaderEventSynced(const std::string& event_uuid) {
    const char* sql = "UPDATE cash_loader_events SET synced_to_server = 1, synced_at = ? WHERE event_uuid = ?";

    sqlite3_stmt* stmt;
    if (sqlite3_prepare_v2(db_, sql, -1, &stmt, nullptr) != SQLITE_OK) {
        return false;
    }

    std::string now = GetCurrentISO8601();
    sqlite3_bind_text(stmt, 1, now.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(stmt, 2, event_uuid.c_str(), -1, SQLITE_TRANSIENT);

    int rc = sqlite3_step(stmt);
    sqlite3_finalize(stmt);

    return (rc == SQLITE_DONE);
}

int ElectronicJournal::GetPendingLoaderEventCount() {
    const char* sql = "SELECT COUNT(*) FROM cash_loader_events WHERE synced_to_server = 0";
    sqlite3_stmt* stmt;
    int count = 0;

    if (sqlite3_prepare_v2(db_, sql, -1, &stmt, nullptr) == SQLITE_OK) {
        if (sqlite3_step(stmt) == SQLITE_ROW) {
            count = sqlite3_column_int(stmt, 0);
        }
        sqlite3_finalize(stmt);
    }

    return count;
}

bool ElectronicJournal::UpdateCassetteCount(const std::string& machine_id, int cassette_number, int new_count) {
    const char* sql = "INSERT OR REPLACE INTO cassette_inventory (machine_id, cassette_number, current_count, last_updated) "
                      "VALUES (?, ?, ?, ?)";

    sqlite3_stmt* stmt;
    if (sqlite3_prepare_v2(db_, sql, -1, &stmt, nullptr) != SQLITE_OK) {
        return false;
    }

    std::string now = GetCurrentISO8601();
    sqlite3_bind_text(stmt, 1, machine_id.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_int(stmt, 2, cassette_number);
    sqlite3_bind_int(stmt, 3, new_count);
    sqlite3_bind_text(stmt, 4, now.c_str(), -1, SQLITE_TRANSIENT);

    int rc = sqlite3_step(stmt);
    sqlite3_finalize(stmt);

    return (rc == SQLITE_DONE);
}

int ElectronicJournal::GetCassetteCount(const std::string& machine_id, int cassette_number) {
    const char* sql = "SELECT current_count FROM cassette_inventory WHERE machine_id = ? AND cassette_number = ?";

    sqlite3_stmt* stmt;
    int count = 0;

    if (sqlite3_prepare_v2(db_, sql, -1, &stmt, nullptr) == SQLITE_OK) {
        sqlite3_bind_text(stmt, 1, machine_id.c_str(), -1, SQLITE_TRANSIENT);
        sqlite3_bind_int(stmt, 2, cassette_number);

        if (sqlite3_step(stmt) == SQLITE_ROW) {
            count = sqlite3_column_int(stmt, 0);
        }
        sqlite3_finalize(stmt);
    }

    return count;
}

bool ElectronicJournal::SaveCassetteConfig(const std::string& machine_id, int cassette_number, const CassetteConfig& config) {
    const char* sql = "INSERT OR REPLACE INTO cassette_config (machine_id, cassette_number, denomination, capacity, "
                      "low_threshold, critical_threshold, is_enabled, last_updated) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

    sqlite3_stmt* stmt;
    if (sqlite3_prepare_v2(db_, sql, -1, &stmt, nullptr) != SQLITE_OK) {
        return false;
    }

    std::string now = GetCurrentISO8601();
    sqlite3_bind_text(stmt, 1, machine_id.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_int(stmt, 2, cassette_number);
    sqlite3_bind_int(stmt, 3, config.denomination);
    sqlite3_bind_int(stmt, 4, config.capacity);
    sqlite3_bind_int(stmt, 5, config.low_threshold);
    sqlite3_bind_int(stmt, 6, config.critical_threshold);
    sqlite3_bind_int(stmt, 7, config.is_enabled ? 1 : 0);
    sqlite3_bind_text(stmt, 8, now.c_str(), -1, SQLITE_TRANSIENT);

    int rc = sqlite3_step(stmt);
    sqlite3_finalize(stmt);

    return (rc == SQLITE_DONE);
}

CassetteConfig ElectronicJournal::GetCassetteConfig(const std::string& machine_id, int cassette_number) {
    CassetteConfig config = {0};
    const char* sql = "SELECT denomination, capacity, low_threshold, critical_threshold, is_enabled "
                      "FROM cassette_config WHERE machine_id = ? AND cassette_number = ?";

    sqlite3_stmt* stmt;
    if (sqlite3_prepare_v2(db_, sql, -1, &stmt, nullptr) == SQLITE_OK) {
        sqlite3_bind_text(stmt, 1, machine_id.c_str(), -1, SQLITE_TRANSIENT);
        sqlite3_bind_int(stmt, 2, cassette_number);

        if (sqlite3_step(stmt) == SQLITE_ROW) {
            config.denomination = sqlite3_column_int(stmt, 0);
            config.capacity = sqlite3_column_int(stmt, 1);
            config.low_threshold = sqlite3_column_int(stmt, 2);
            config.critical_threshold = sqlite3_column_int(stmt, 3);
            config.is_enabled = sqlite3_column_int(stmt, 4) == 1;
        }
        sqlite3_finalize(stmt);
    }

    return config;
}

bool ElectronicJournal::RecordAlert(const DeviceAlert& alert) {
    const char* sql = "INSERT INTO device_alerts (alert_uuid, machine_id, alert_type, severity, cassette_number, "
                      "details, error_code, timestamp, synced_to_server) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

    sqlite3_stmt* stmt;
    if (sqlite3_prepare_v2(db_, sql, -1, &stmt, nullptr) != SQLITE_OK) {
        return false;
    }

    sqlite3_bind_text(stmt, 1, alert.alert_uuid.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(stmt, 2, alert.machine_id.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(stmt, 3, alert.alert_type.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(stmt, 4, alert.severity.c_str(), -1, SQLITE_TRANSIENT);

    if (alert.cassette_number > 0) {
        sqlite3_bind_int(stmt, 5, alert.cassette_number);
    } else {
        sqlite3_bind_null(stmt, 5);
    }

    if (alert.details.empty()) {
        sqlite3_bind_null(stmt, 6);
    } else {
        sqlite3_bind_text(stmt, 6, alert.details.c_str(), -1, SQLITE_TRANSIENT);
    }

    if (alert.error_code.empty()) {
        sqlite3_bind_null(stmt, 7);
    } else {
        sqlite3_bind_text(stmt, 7, alert.error_code.c_str(), -1, SQLITE_TRANSIENT);
    }

    sqlite3_bind_text(stmt, 8, alert.timestamp.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_int(stmt, 9, alert.synced_to_server ? 1 : 0);

    int rc = sqlite3_step(stmt);
    sqlite3_finalize(stmt);

    return (rc == SQLITE_DONE);
}

std::vector<DeviceAlert> ElectronicJournal::GetUnsyncedAlerts() {
    std::vector<DeviceAlert> results;
    const char* sql = "SELECT alert_uuid, machine_id, alert_type, severity, cassette_number, "
                      "details, error_code, timestamp FROM device_alerts WHERE synced_to_server = 0";

    sqlite3_stmt* stmt;
    if (sqlite3_prepare_v2(db_, sql, -1, &stmt, nullptr) != SQLITE_OK) {
        return results;
    }

    while (sqlite3_step(stmt) == SQLITE_ROW) {
        DeviceAlert a;
        a.alert_uuid = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 0));
        a.machine_id = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 1));
        a.alert_type = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 2));
        a.severity = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 3));
        a.cassette_number = sqlite3_column_int(stmt, 4);

        const char* det = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 5));
        a.details = det ? det : "";

        const char* ec = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 6));
        a.error_code = ec ? ec : "";

        a.timestamp = reinterpret_cast<const char*>(sqlite3_column_text(stmt, 7));
        a.synced_to_server = false;

        results.push_back(a);
    }

    sqlite3_finalize(stmt);
    return results;
}

bool ElectronicJournal::MarkAlertSynced(const std::string& alert_uuid) {
    const char* sql = "UPDATE device_alerts SET synced_to_server = 1, synced_at = ? WHERE alert_uuid = ?";

    sqlite3_stmt* stmt;
    if (sqlite3_prepare_v2(db_, sql, -1, &stmt, nullptr) != SQLITE_OK) {
        return false;
    }

    std::string now = GetCurrentISO8601();
    sqlite3_bind_text(stmt, 1, now.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(stmt, 2, alert_uuid.c_str(), -1, SQLITE_TRANSIENT);

    int rc = sqlite3_step(stmt);
    sqlite3_finalize(stmt);

    return (rc == SQLITE_DONE);
}

int ElectronicJournal::GetPendingAlertCount() {
    const char* sql = "SELECT COUNT(*) FROM device_alerts WHERE synced_to_server = 0";
    sqlite3_stmt* stmt;
    int count = 0;

    if (sqlite3_prepare_v2(db_, sql, -1, &stmt, nullptr) == SQLITE_OK) {
        if (sqlite3_step(stmt) == SQLITE_ROW) {
            count = sqlite3_column_int(stmt, 0);
        }
        sqlite3_finalize(stmt);
    }

    return count;
}

std::string ElectronicJournal::GenerateUUID() {
    uuid_t uuid;
    uuid_generate_random(uuid);

    char uuid_str[37];
    uuid_unparse_lower(uuid, uuid_str);

    return std::string(uuid_str);
}

std::string ElectronicJournal::GetCurrentISO8601() {
    std::time_t now = std::time(nullptr);
    std::tm* utc = std::gmtime(&now);
    std::ostringstream oss;
    oss << std::put_time(utc, "%Y-%m-%dT%H:%M:%SZ");
    return oss.str();
}

bool ElectronicJournal::ExecuteSQL(const std::string& sql) {
    char* err = nullptr;
    int rc = sqlite3_exec(db_, sql.c_str(), nullptr, nullptr, &err);
    if (rc != SQLITE_OK) {
        std::cerr << "[EJ] SQL error: " << err << std::endl;
        sqlite3_free(err);
        return false;
    }
    return true;
}
