#ifndef CASHLEDGERSINGLETON_H
#define CASHLEDGERSINGLETON_H

#include "CashLedgerManager.h"
#include <memory>
#include <mutex>
#include <string>

/**
 * CashLedgerSingleton - Thread-safe singleton wrapper for CashLedgerManager
 *
 * Purpose:
 * - Provides global access point to single CashLedgerManager instance
 * - Ensures thread safety with mutex protection
 * - Prevents multiple instances in multi-threaded Qt application
 *
 * Usage:
 *
 * // In main() or application initialization:
 * if (!CashLedgerSingleton::Initialize("KIOSK-001", "https://api.server.com", "/var/kiosk/ej.db")) {
 *     qCritical() << "Failed to initialize CashLedgerManager";
 *     return -1;
 * }
 *
 * // Anywhere in application:
 * CashLedgerManager* ledger = CashLedgerSingleton::Instance();
 * if (ledger) {
 *     DispenseResult result = ledger->DispenseCash(10000, "CheckCashing", check_tx_id, customer_id);
 * }
 *
 * // Before application exit:
 * CashLedgerSingleton::Shutdown();
 */
class CashLedgerSingleton {
public:
    /**
     * Get singleton instance
     *
     * @return Pointer to CashLedgerManager instance, or nullptr if not initialized
     *
     * Thread-safe: Yes (mutex-protected)
     */
    static CashLedgerManager* Instance();

    /**
     * Initialize the singleton
     *
     * Must be called ONCE before first use (typically in main() or application startup)
     *
     * @param machine_id - Unique kiosk identifier (e.g., "KIOSK-001")
     * @param server_url - Backend API URL (e.g., "https://api.server.com")
     * @param db_path - Path to SQLite database (e.g., "/var/kiosk/ej.db")
     * @return true if initialization successful, false otherwise
     *
     * Thread-safe: Yes (mutex-protected)
     *
     * Example:
     *   CashLedgerSingleton::Initialize("KIOSK-001", "https://api.example.com", "/var/kiosk/ej.db");
     */
    static bool Initialize(const std::string& machine_id,
                           const std::string& server_url,
                           const std::string& db_path);

    /**
     * Shutdown and cleanup singleton
     *
     * Should be called before application exit to ensure proper cleanup
     *
     * Thread-safe: Yes (mutex-protected)
     */
    static void Shutdown();

    /**
     * Check if singleton is initialized
     *
     * @return true if initialized and ready for use
     *
     * Thread-safe: Yes (mutex-protected)
     */
    static bool IsInitialized();

    // Delete copy constructor and assignment operator
    CashLedgerSingleton(const CashLedgerSingleton&) = delete;
    CashLedgerSingleton& operator=(const CashLedgerSingleton&) = delete;

private:
    // Private constructor (singleton pattern)
    CashLedgerSingleton() = default;

    // Singleton instance
    static std::unique_ptr<CashLedgerManager> instance_;

    // Thread safety
    static std::mutex mutex_;

    // Initialization flag
    static bool initialized_;
};

#endif // CASHLEDGERSINGLETON_H
