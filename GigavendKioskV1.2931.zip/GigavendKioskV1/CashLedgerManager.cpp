#include "CashLedgerManager.h"
#include <iostream>
#include <sstream>
#include <iomanip>
#include <cmath>
#include <algorithm>

CashLedgerManager::CashLedgerManager(const std::string& machine_id,
                                     const std::string& server_url,
                                     const std::string& ej_db_path)
    : machine_id_(machine_id), server_url_(server_url), ej_db_path_(ej_db_path),
    initialized_(false), cdu_handle_(nullptr) {
}

CashLedgerManager::~CashLedgerManager() {
    Shutdown();
}

bool CashLedgerManager::Initialize() {
    std::cout << "[CLM] Initializing CashLedgerManager..." << std::endl;

    ej_ = std::make_unique<ElectronicJournal>(ej_db_path_);
    if (!ej_->Initialize()) {
        std::cerr << "[CLM] ERROR: Failed to initialize Electronic Journal" << std::endl;
        return false;
    }

    if (!InitializeCDU()) {
        std::cerr << "[CLM] ERROR: Failed to initialize CDU SDK" << std::endl;
        return false;
    }

    for (int i = 1; i <= 6; i++) {
        CassetteConfig config = ej_->GetCassetteConfig(machine_id_, i);
        if (config.denomination == 0) {
            std::cout << "[CLM] Warning: Cassette " << i << " not configured" << std::endl;
        }
    }

    initialized_ = true;
    std::cout << "[CLM] Initialization complete" << std::endl;
    return true;
}

void CashLedgerManager::Shutdown() {
    if (!initialized_) return;
    if (ej_) {
        ej_->Close();
    }
    initialized_ = false;
    std::cout << "[CLM] Shutdown complete" << std::endl;
}

DispenseResult CashLedgerManager::DispenseCash(int amount_cents, const std::string& source,
                                               const std::string& check_tx_id,
                                               const std::string& customer_id) {
    DispenseResult result;
    result.success = false;
    result.amount_cents = amount_cents;
    result.synced_to_server = false;

    if (!initialized_) {
        result.error_message = "CashLedgerManager not initialized";
        return result;
    }

    if (amount_cents <= 0) {
        result.error_message = "Invalid amount: must be > 0";
        return result;
    }

    if (!CanDispense(amount_cents)) {
        result.error_message = "Cannot dispense: insufficient bills or invalid amount";
        RecordAlert("INSUFFICIENT_CASH", "CRITICAL", 0,
                    "Cannot dispense $" + std::to_string(amount_cents / 100.0));
        return result;
    }

    CassetteAllocation allocation = CalculateBillAllocation(amount_cents);
    if (!allocation.is_exact_match) {
        result.error_message = "Cannot make exact change for $" + std::to_string(amount_cents / 100.0);
        return result;
    }

    if (!SendDispenseCommand(allocation)) {
        result.error_message = "CDU hardware dispense failed";
        RecordAlert("DISPENSE_FAILURE", "CRITICAL", 0,
                    "Hardware failed to dispense $" + std::to_string(amount_cents / 100.0));
        return result;
    }

    // Update local inventory
    for (int i = 1; i <= 6; i++) {
        int dispensed = 0;
        switch (i) {
        case 1: dispensed = allocation.bills_from_cst1; break;
        case 2: dispensed = allocation.bills_from_cst2; break;
        case 3: dispensed = allocation.bills_from_cst3; break;
        case 4: dispensed = allocation.bills_from_cst4; break;
        case 5: dispensed = allocation.bills_from_cst5; break;
        case 6: dispensed = allocation.bills_from_cst6; break;
        }
        if (dispensed > 0) {
            int current = ej_->GetCassetteCount(machine_id_, i);
            int new_count = current - dispensed;
            ej_->UpdateCassetteCount(machine_id_, i, new_count);
        }
    }

    // Create transaction record
    CashTransactionRecord tx;
    tx.transaction_uuid = ej_->GenerateUUID();
    tx.machine_id = machine_id_;
    tx.source = source;
    tx.cst1_count = allocation.bills_from_cst1;
    tx.cst2_count = allocation.bills_from_cst2;
    tx.cst3_count = allocation.bills_from_cst3;
    tx.cst4_count = allocation.bills_from_cst4;
    tx.cst5_count = allocation.bills_from_cst5;
    tx.cst6_count = allocation.bills_from_cst6;
    tx.total_bills = allocation.total_bills;
    tx.total_amount_cents = allocation.amount_cents; // DIRECT ASSIGNMENT (No / 100.0)
    tx.check_tx_id = check_tx_id;
    tx.customer_id = customer_id;
    tx.status = "SUCCESS";
    tx.timestamp = ej_->GetCurrentISO8601();
    tx.synced_to_server = false;

    if (!ej_->RecordTransaction(tx)) {
        std::cerr << "[CLM] ERROR: Failed to record transaction to EJ" << std::endl;
    }

    // Populate result
    result.success = true;
    result.error_message = "";
    result.bills_from_cst1 = allocation.bills_from_cst1;
    result.bills_from_cst2 = allocation.bills_from_cst2;
    result.bills_from_cst3 = allocation.bills_from_cst3;
    result.bills_from_cst4 = allocation.bills_from_cst4;
    result.bills_from_cst5 = allocation.bills_from_cst5;
    result.bills_from_cst6 = allocation.bills_from_cst6;
    result.total_bills = allocation.total_bills;
    result.amount_cents = allocation.amount_cents;
    result.transaction_uuid = tx.transaction_uuid;
    result.timestamp = tx.timestamp;
    result.synced_to_server = false;

    return result;
}

// FIXED: ATM-standard bill allocation (highest denomination first, fewest bills)
CassetteAllocation CashLedgerManager::CalculateBillAllocation(int amount_cents) {
    CassetteAllocation allocation = {0};
    allocation.amount_cents = 0;
    allocation.is_exact_match = false;

    // Convert to dollars (ATMs dispense whole dollars)
    int amount_dollars = amount_cents / 100;

    // Check if we can only dispense whole dollars
    if (amount_cents % 100 != 0) {
        return allocation;  // Cannot dispense cents
    }

    // Collect enabled cassettes with their denomination and current count
    struct CassetteInfo {
        int cassette_number;
        int denomination;
        int available_count;
    };

    std::vector<CassetteInfo> cassettes;
    for (int i = 1; i <= 6; i++) {
        CassetteConfig config = ej_->GetCassetteConfig(machine_id_, i);
        int count = ej_->GetCassetteCount(machine_id_, i);

        if (config.is_enabled && config.denomination > 0 && count > 0) {
            CassetteInfo info;
            info.cassette_number = i;
            info.denomination = config.denomination;
            info.available_count = count;
            cassettes.push_back(info);
        }
    }

    // CRITICAL FIX: Sort by denomination DESCENDING (highest first)
    // This ensures fewest bills algorithm (ATM standard)
    std::sort(cassettes.begin(), cassettes.end(),
              [](const CassetteInfo& a, const CassetteInfo& b) {
                  return a.denomination > b.denomination;  // Descending
              });

    // Greedy allocation from highest denomination
    int remaining_dollars = amount_dollars;
    int bills_used[6] = {0};  // Index by cassette_number - 1

    for (const auto& cst : cassettes) {
        if (remaining_dollars == 0) break;

        int bills_needed = remaining_dollars / cst.denomination;
        int bills_to_use = std::min(bills_needed, cst.available_count);

        if (bills_to_use > 0) {
            bills_used[cst.cassette_number - 1] = bills_to_use;
            remaining_dollars -= bills_to_use * cst.denomination;
            allocation.total_bills += bills_to_use;
            allocation.amount_cents += bills_to_use * cst.denomination * 100;
        }
    }

    // Check if we made exact change
    if (remaining_dollars == 0) {
        allocation.is_exact_match = true;
    }

    // Populate per-cassette counts
    allocation.bills_from_cst1 = bills_used[0];
    allocation.bills_from_cst2 = bills_used[1];
    allocation.bills_from_cst3 = bills_used[2];
    allocation.bills_from_cst4 = bills_used[3];
    allocation.bills_from_cst5 = bills_used[4];
    allocation.bills_from_cst6 = bills_used[5];

    return allocation;
}

bool CashLedgerManager::CanDispense(int amount_cents) {
    CassetteAllocation allocation = CalculateBillAllocation(amount_cents);
    return allocation.is_exact_match;
}

int CashLedgerManager::GetCassetteCount(int cassette_number) {
    if (!initialized_) return 0;
    return ej_->GetCassetteCount(machine_id_, cassette_number);
}

CassetteConfig CashLedgerManager::GetCassetteConfig(int cassette_number) {
    if (!initialized_) {
        CassetteConfig empty = {0};
        return empty;
    }
    return ej_->GetCassetteConfig(machine_id_, cassette_number);
}

int CashLedgerManager::GetTotalCashValueCents() {
    int total_cents = 0;
    if (!initialized_) return total_cents;

    for (int i = 1; i <= 6; i++) {
        int count = ej_->GetCassetteCount(machine_id_, i);
        CassetteConfig config = ej_->GetCassetteConfig(machine_id_, i);
        total_cents += count * config.denomination * 100;  // Convert to cents
    }

    return total_cents;
}

bool CashLedgerManager::UpdateCassetteCount(int cassette_number, int new_count,
                                            const std::string& operator_name,
                                            const std::string& action) {
    if (!initialized_) return false;

    int old_count = ej_->GetCassetteCount(machine_id_, cassette_number);

    if (!ej_->UpdateCassetteCount(machine_id_, cassette_number, new_count)) {
        return false;
    }

    CashLoaderEventRecord event;
    event.event_uuid = ej_->GenerateUUID();
    event.machine_id = machine_id_;
    event.operator_name = operator_name;
    event.action = action;
    event.cassette_number = cassette_number;
    event.old_count = old_count;
    event.new_count = new_count;
    event.delta = new_count - old_count;
    event.timestamp = ej_->GetCurrentISO8601();
    event.synced_to_server = false;

    if (!ej_->RecordLoaderEvent(event)) {
        return false;
    }

    return true;
}

// --- FIXED IMPLEMENTATION: Auto-Enables Cassettes ---
bool CashLedgerManager::UpdateCassetteDenomination(int cassette_number, int new_denomination) {
    if (!initialized_) return false;

    // 1. Get existing config
    CassetteConfig config = ej_->GetCassetteConfig(machine_id_, cassette_number);

    // 2. Update denomination
    config.denomination = new_denomination;

    // 3. AUTO-ENABLE if valid
    if (new_denomination > 0) {
        config.is_enabled = true;

        // 4. Set Defaults if new
        if (config.capacity <= 0) config.capacity = 2000;
        if (config.low_threshold <= 0) config.low_threshold = 50;
        if (config.critical_threshold <= 0) config.critical_threshold = 20;
    }

    // 5. Save back to DB
    return ej_->SaveCassetteConfig(machine_id_, cassette_number, config);
}

int CashLedgerManager::SyncToServer() {
    if (!initialized_) return 0;

    int total_synced = 0;
    std::cout << "[CLM] SyncToServer: " << GetPendingSyncCount()
              << " records pending (HTTP not implemented yet)" << std::endl;

    return total_synced;
}

int CashLedgerManager::GetPendingSyncCount() {
    if (!initialized_) return 0;
    int count = 0;
    count += ej_->GetPendingTransactionCount();
    count += ej_->GetPendingLoaderEventCount();
    count += ej_->GetPendingAlertCount();
    return count;
}

bool CashLedgerManager::RecordAlert(const std::string& alert_type,
                                    const std::string& severity,
                                    int cassette_number,
                                    const std::string& details) {
    if (!initialized_) return false;

    DeviceAlert alert;
    alert.alert_uuid = ej_->GenerateUUID();
    alert.machine_id = machine_id_;
    alert.alert_type = alert_type;
    alert.severity = severity;
    alert.cassette_number = cassette_number;
    alert.details = details;
    alert.timestamp = ej_->GetCurrentISO8601();
    alert.synced_to_server = false;

    return ej_->RecordAlert(alert);
}

bool CashLedgerManager::SendDispenseCommand(const CassetteAllocation& allocation) {
    std::cout << "[CLM] Sending dispense command (STUB):" << std::endl;
    std::cout << "  CST1: " << allocation.bills_from_cst1 << " bills" << std::endl;
    std::cout << "  CST2: " << allocation.bills_from_cst2 << " bills" << std::endl;
    std::cout << "  CST3: " << allocation.bills_from_cst3 << " bills" << std::endl;
    std::cout << "  CST4: " << allocation.bills_from_cst4 << " bills" << std::endl;
    std::cout << "  CST5: " << allocation.bills_from_cst5 << " bills" << std::endl;
    std::cout << "  CST6: " << allocation.bills_from_cst6 << " bills" << std::endl;
    return true;
}

bool CashLedgerManager::InitializeCDU() {
    std::cout << "[CLM] Initializing CDU SDK (STUB)" << std::endl;
    cdu_handle_ = reinterpret_cast<void*>(0x12345678);
    return true;
}
// ... (Existing code) ...

// --- IMPLEMENTATION FOR ROBUST MANAGER ---

std::vector<CassetteConfig> CashLedgerManager::GetCassettes() {
    std::vector<CassetteConfig> cassettes;
    if (!initialized_) return cassettes;
    for (int i = 1; i <= 6; i++) {
        cassettes.push_back(ej_->GetCassetteConfig(machine_id_, i));
    }
    return cassettes;
}

std::string CashLedgerManager::RecordDispenseToEJ(
    double amount,
    int cst1, int cst2, int cst3, int cst4, int cst5, int cst6,
    const std::string& source,
    const std::string& check_tx_id,
    const std::string& customer_id
    ) {
    if (!initialized_) return "";

    // 1. Update cassette counts in DB
    int bills_dispensed[6] = {cst1, cst2, cst3, cst4, cst5, cst6};
    for (int i = 1; i <= 6; i++) {
        if (bills_dispensed[i-1] > 0) {
            int current = ej_->GetCassetteCount(machine_id_, i);
            int new_count = std::max(0, current - bills_dispensed[i-1]);
            ej_->UpdateCassetteCount(machine_id_, i, new_count);
        }
    }

    // 2. Create transaction record
    CashTransactionRecord tx;
    tx.transaction_uuid = ej_->GenerateUUID();
    tx.machine_id = machine_id_;
    tx.source = source;
    tx.cst1_count = cst1;
    tx.cst2_count = cst2;
    tx.cst3_count = cst3;
    tx.cst4_count = cst4;
    tx.cst5_count = cst5;
    tx.cst6_count = cst6;
    tx.total_bills = cst1 + cst2 + cst3 + cst4 + cst5 + cst6;
    // Note: This takes double amount, matching the legacy EJ structure
    tx.total_amount_cents = static_cast<int>(std::round(amount * 100.0));
    tx.check_tx_id = check_tx_id;
    tx.customer_id = customer_id;
    tx.status = "SUCCESS";
    tx.timestamp = ej_->GetCurrentISO8601();
    tx.synced_to_server = false;

    if (!ej_->RecordTransaction(tx)) {
        std::cerr << "[CashLedgerManager] ERROR: Failed to record transaction to EJ" << std::endl;
        return "";
    }

    std::cout << "[CashLedgerManager] Transaction recorded to EJ: " << tx.transaction_uuid << std::endl;
    return tx.transaction_uuid;
}
