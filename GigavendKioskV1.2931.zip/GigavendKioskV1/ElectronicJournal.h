#ifndef ELECTRONICJOURNAL_H
#define ELECTRONICJOURNAL_H

#include <string>
#include <vector>
#include <sqlite3.h>

struct CashTransactionRecord {
    std::string transaction_uuid;
    std::string machine_id;
    std::string source;
    std::string check_tx_id;
    std::string customer_id;
    int cst1_count;
    int cst2_count;
    int cst3_count;
    int cst4_count;
    int cst5_count;
    int cst6_count;
    int total_bills;
    int total_amount_cents;
    std::string status;
    std::string error_message;
    std::string timestamp;
    bool synced_to_server;
};

struct CashLoaderEventRecord {
    std::string event_uuid;
    std::string machine_id;
    int operator_id;
    std::string operator_name;
    std::string action;
    int cassette_number;
    int old_count;
    int new_count;
    int delta;
    std::string notes;
    std::string timestamp;
    bool synced_to_server;
};

struct CassetteConfig {
    int denomination;
    int capacity;
    int low_threshold;
    int critical_threshold;
    bool is_enabled;
};

struct DeviceAlert {
    std::string alert_uuid;
    std::string machine_id;
    std::string alert_type;
    std::string severity;
    int cassette_number;
    std::string details;
    std::string error_code;
    std::string timestamp;
    bool synced_to_server;
};

class ElectronicJournal {
public:
    explicit ElectronicJournal(const std::string& db_path);
    ~ElectronicJournal();

    bool Initialize();
    void Close();

    // Transactions
    bool RecordTransaction(const CashTransactionRecord& record);
    std::vector<CashTransactionRecord> GetUnsyncedTransactions();
    bool MarkTransactionSynced(const std::string& transaction_uuid);
    int GetPendingTransactionCount();

    // Loader Events
    bool RecordLoaderEvent(const CashLoaderEventRecord& event);
    std::vector<CashLoaderEventRecord> GetUnsyncedLoaderEvents();
    bool MarkLoaderEventSynced(const std::string& event_uuid);
    int GetPendingLoaderEventCount();

    // Inventory
    bool UpdateCassetteCount(const std::string& machine_id, int cassette_number, int new_count);
    int GetCassetteCount(const std::string& machine_id, int cassette_number);

    // Config
    bool SaveCassetteConfig(const std::string& machine_id, int cassette_number, const CassetteConfig& config);
    CassetteConfig GetCassetteConfig(const std::string& machine_id, int cassette_number);

    // Alerts
    bool RecordAlert(const DeviceAlert& alert);
    std::vector<DeviceAlert> GetUnsyncedAlerts();
    bool MarkAlertSynced(const std::string& alert_uuid);
    int GetPendingAlertCount();

    // Utilities
    std::string GenerateUUID();
    std::string GetCurrentISO8601();

private:
    sqlite3* db_;
    std::string db_path_;

    bool ExecuteSQL(const std::string& sql);
};

#endif
