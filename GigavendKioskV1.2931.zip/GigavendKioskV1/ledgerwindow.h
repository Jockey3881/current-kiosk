#ifndef LEDGERWINDOW_H
#define LEDGERWINDOW_H

#include <QObject>
#include <QString>
#include <QStringList>
#include <QVariantList>
#include <QVector>
#include <QTimer>
#include <QMutex>

class LedgerWindow : public QObject
{
    Q_OBJECT
    Q_PROPERTY(bool visible READ isVisible WRITE setVisible NOTIFY visibleChanged)
    Q_PROPERTY(QVariantList cassetteData READ cassetteData NOTIFY cassetteDataChanged)
    Q_PROPERTY(int totalBills READ totalBills NOTIFY totalsChanged)
    Q_PROPERTY(qint64 totalAmount READ totalAmount NOTIFY totalsChanged)
    Q_PROPERTY(QString totalAmountFormatted READ totalAmountFormatted NOTIFY totalsChanged)
    Q_PROPERTY(QString statusMessage READ statusMessage NOTIFY statusMessageChanged)

public:
    explicit LedgerWindow(QObject *parent = nullptr);
    ~LedgerWindow() override;

    bool isVisible() const;
    void setVisible(bool visible);

    QVariantList cassetteData() const;
    int totalBills() const;
    qint64 totalAmount() const;
    QString totalAmountFormatted() const;
    QString statusMessage() const;

    Q_INVOKABLE void setCassetteCount(int index, int count);
    Q_INVOKABLE void adjustCassetteCount(int index, int delta);
    Q_INVOKABLE void setCassetteDenomination(int index, int denomination);

    Q_INVOKABLE void on_btnKioskHome_clicked();

    void setAppActive(bool active);
    void setActiveAppContext(const QString &appId, bool active);

    // Call this to force a reload from the DB (e.g. when window becomes visible)
    void refreshFromDatabase();

signals:
    void visibleChanged();
    void cassetteDataChanged();
    void totalsChanged();
    void statusMessageChanged();

private:
    struct CassetteInfo {
        int denomination = 0;
        int count = 0;
    };

    void handleDispenseCompleted(const QString &count,
                                 const QStringList &details,
                                 const QString &source);
    void handleDispenseFailed(short reason,
                              const QString &count,
                              const QStringList &details,
                              const QString &source);
    bool isValidIndex(int index) const;
    void updateStatusMessage(const QString &message);
    void notifyDataChanged();

    // Log Tailing (Kept for dispense log viewing)
    QString resolveDispenseLogPath() const;
    void startLogTail();
    void processLogTail();
    void appendDispenseLog(const QString& source,
                           const QString& count,
                           const QStringList& details);
    void applyDispenseDetails(const QStringList &details, const QString &source);
    int  parseDetailCount(const QString &value);
    QString cassetteLabel(int idx) const;
    QString currentDispenseSource() const;
    QString friendlyAppName(const QString &appId) const;

    static constexpr int kCassetteSlots = 6;

    // --- CDU callback glue ---
    static void on_CDU_DispenseCompleted(void *pObj,
                                         const char *dispCount,
                                         const char *dispInfo1,
                                         const char *dispInfo2,
                                         const char *dispInfo3,
                                         const char *dispInfo4,
                                         const char *dispInfo5,
                                         const char *dispInfo6);
    static void on_CDU_DispenseFailed(void *pObj,
                                      short reason,
                                      const char *dispCount,
                                      const char *dispInfo1,
                                      const char *dispInfo2,
                                      const char *dispInfo3,
                                      const char *dispInfo4,
                                      const char *dispInfo5,
                                      const char *dispInfo6);

    QVector<CassetteInfo> m_cassettes;
    bool m_visible;
    bool m_appActive;
    QString m_statusMessage;
    QString m_activeDispenseAppId;

    QTimer *m_logTailTimer = nullptr;
    QString m_logFilePath;
    qint64  m_logReadPos = 0;
    QMutex  m_logMutex;
};

#endif // LEDGERWINDOW_H
