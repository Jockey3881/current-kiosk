#ifndef ATMHOSTLOGGER_H
#define ATMHOSTLOGGER_H

#include <QByteArray>
#include <QMutex>
#include <QString>
#include <QStringList>
#include <QVariantMap>

// Captures Triton-style ATM host protocol traffic. Triton terminals encapsulate
// ISO 8583 payloads between STX/ETX bytes with FS/GS separators; the logger
// renders both hexadecimal and human-readable control character mnemonics so
// the raw frames can be traced alongside parsed metadata.
class AtmHostLogger
{
public:
    enum class Direction {
        Outbound,
        Inbound,
        Event
    };

    static AtmHostLogger &instance();

    void logOutboundMessage(const QString &summary,
                             const QByteArray &payload = {});
    void logInboundMessage(const QString &summary,
                            const QByteArray &payload = {});
    void logEvent(const QString &summary,
                  const QVariantMap &details = {});
    void logTotalsUpdate(const QString &context,
                         const QString &count,
                         const QStringList &cassetteDetails);

private:
    AtmHostLogger();

    void appendEntry(Direction direction,
                     const QString &summary,
                     const QString &detail);

    QString formatPayload(const QByteArray &payload) const;
    QString formatDetails(const QVariantMap &details) const;

    QMutex m_mutex;
};

#endif // ATMHOSTLOGGER_H
