#ifndef SCANWORKER_H
#define SCANWORKER_H

#include <QObject>
#include <QThread>

class CashingWindow;
class ScanId;
class ScanWorker : public QObject
{
    Q_OBJECT
public:
    explicit ScanWorker(CashingWindow* cashingWnd);
    virtual ~ScanWorker();
    void cancelScanId(QThread* scanThread);

public slots:
    void doWork();

private:
    CashingWindow* m_cashingWnd;
    ScanId* m_scanId;
    bool m_cancel;
};

#endif // SCANWORKER_H
