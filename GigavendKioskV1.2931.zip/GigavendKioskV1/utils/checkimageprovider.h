#ifndef CHECKIMAGEPROVIDER_H
#define CHECKIMAGEPROVIDER_H

#include <QQuickImageProvider>
#include "../cashingwindow.h"

class CheckImageProvider : public QQuickImageProvider
{
public:
    CheckImageProvider(CashingWindow *cashingWindow);
    QImage requestImage(const QString &id, QSize *size, const QSize &requestedSize) override;

private:
    CashingWindow *m_cashingWindow;
};

#endif // CHECKIMAGEPROVIDER_H
