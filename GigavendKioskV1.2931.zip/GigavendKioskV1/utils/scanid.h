#ifndef SCANID_H
#define SCANID_H

#include <QString>
#include "PIScan.h"

#define MAX_IMAGE_SIZE		52428800
#define ID_FRONT         	0x01
#define ID_BACK          	0x02
#define ID_FR_ROTATION   	0x01
#define ID_BK_ROTATION   	0x02
#define ID_EJECT_DIR        0x01
#define ERROR_BUFFER_SIZE   256
// --- Eject tuning (front chute only) ---
#define ID_EJECT_ATTEMPTS     2     // total pulses (first + up to two nudges)
#define ID_EJECT_SETTLE_MS    250   // settle time after each eject pulse
#define ID_EJECT_FINAL_POLL_MS 1500 // final poll window to confirm path clear

class CashingWindow;
class ScanId
{
public:
    ScanId(CashingWindow* cashingWnd);
    virtual ~ScanId();

    bool IsScanDeviceReady();
    bool ScanImage();
    void cancelScanId();
    QString getErrorMsg();
    bool OpenDevice();
    void CloseDevice();
    void ResetVariables();
    bool softReset(); // wraps PiScanSoftResetScanner() with logging
    bool pollStatus(PriStatStr* out = nullptr, int attempts = 20, int msBetween = 100);
    static bool mediaPresentBits(const PriStatStr& s);
    bool waitForMediaClear(int attempts = 30, int msBetween = 100);
    // Clear sticky cancel so next scan can arm
    void clearCancel();

    // Drain any pending image buffers so next scan doesn't encounter stale data
    bool drainImages();

    // Full recovery back to idle/ready (front-eject + soft reset + drain + path clear)
    bool recoverToIdle(const char* reasonTag);


private:
    void GetErrorMessage();

private:
    CashingWindow* m_cashingWnd;
    PriStatStr m_LastStatus;
    WORD m_dpi;
    BYTE m_color;
    WORD m_delay;	// tens of a second
    BYTE m_scan_type;
    // Image settings
    BYTE m_image_format;
    char m_error_msg[ERROR_BUFFER_SIZE];
    int m_error;
    bool m_connected;
    LPBYTE m_rec_buf;
    bool m_bCancel;
};
#endif // SCANID_H
