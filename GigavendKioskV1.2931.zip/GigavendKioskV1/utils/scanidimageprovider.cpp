#include "scanidimageprovider.h"
#include <QDebug>

ScanIdImageProvider::ScanIdImageProvider(CashingWindow *cashingWindow)
    : QQuickImageProvider(QQuickImageProvider::Image), m_cashingWindow(cashingWindow)
{
}

QImage ScanIdImageProvider::requestImage(const QString &id, QSize *size, const QSize &requestedSize)
{
    if (!m_cashingWindow) {
        return QImage();
    }

    if (id == QLatin1String("frontImage")) {
        QImage img = m_cashingWindow->getScanIdFrontImage();
        if (size) {
            *size = img.size();
        }
        return img;
    }

    if (id == QLatin1String("backImage")) {
        QImage img = m_cashingWindow->getScanIdBackImage();
        if (size) {
            *size = img.size();
        }
        return img;
    }

    // Return an empty image for any other unknown ID
    return QImage();
}
