#include <QThread>
#include <QDebug>
#include "scanworker.h"
#include "../cashingwindow.h"
#include "scanid.h"
#include <atomic>
#include <QtCore/qscopeguard.h>

const int NUM_WAITSECS_SCANID = 120;
const int NUM_RETRY_SCANID = 3;
ScanWorker::ScanWorker(CashingWindow* cashingWnd)
    : m_cashingWnd(cashingWnd)
{
    m_cancel = false;
    m_scanId = new ScanId(cashingWnd);
}

ScanWorker::~ScanWorker()
{
    if (m_scanId)
        delete m_scanId;
}

void ScanWorker::doWork()
{
    // prevent overlapping scans
    static std::atomic<bool> scanning{false};
    if (scanning.exchange(true)) {
        qWarning() << "ScanWorker: scan already in progress; skipping reentry.";
        return;
    }

    qInfo() << "ScanWorker::doWork() started.";

    auto resetGuard = qScopeGuard([&]{
        scanning.store(false);
        qInfo() << "ScanWorker::doWork() ended.";
    });

    // ensure a clean start every run
     m_cancel = false;

    unsigned long secs = 1;

    QThread::sleep(secs);

    // Try to open device, with a single retry if it fails once
    bool success = m_scanId->OpenDevice();
    // snapshot the open state for truthful logging later
    const bool deviceOpen = success;
    qInfo() << "[ScanWorker] OpenDevice() ->" << (success ? "OK" : "FAIL");
    if (!success) {
        const QString openErr = m_scanId->getErrorMsg();
        qWarning() << "[ScanWorker] OpenDevice failed; err =" << openErr << " — retrying once";
        m_scanId->CloseDevice();
        QThread::msleep(200);
        success = m_scanId->OpenDevice();
        qInfo() << "[ScanWorker] OpenDevice() retry ->" << (success ? "OK" : "FAIL");
        if (!success) {
         emit m_cashingWnd->scanIdFailure(false, openErr.isEmpty() ? QStringLiteral("Scanner open failed") : openErr);
         return;
        }
    }

    qInfo() << "[ScanWorker] SoftReset before wait loop ="
            << (m_scanId->softReset() ? "OK" : "FAILED");
    // Drain any latent images left in the device buffers so the first wait/scan is clean.
    m_scanId->drainImages();


    int nCount;
    int retriesLeft = 2;
    QString error;

    m_cashingWnd->setScanSuccess(false);
    qInfo() << "[ScanWorker] entering wait-for-ready loop; retriesLeft =" << retriesLeft
            << " timeoutSecs =" << NUM_WAITSECS_SCANID;
     while (!m_cancel && retriesLeft > 0)
    {
         nCount = 0;
        while (!m_cancel && nCount++ < NUM_WAITSECS_SCANID)
        {
            const bool ready = m_scanId->IsScanDeviceReady();
            if (ready) {
                const int waitMs = 150;
                QThread::msleep(waitMs);
                const bool stillReady = m_scanId->IsScanDeviceReady();
                if (stillReady) {
                    qInfo() << "[ScanWorker] device ready after" << nCount << "sec (debounced)";
                    break;
                } else {
                    qInfo() << "[ScanWorker] transient ready; continuing to wait";
                }
            }

            QThread::sleep(1);

            if (nCount % 20 == 0)
            {
                error = m_scanId->getErrorMsg();
                emit m_cashingWnd->scanIdFailure(false, error);
            }
            if (nCount % 60 == 0)
                qDebug() << "Calling IsScanDeviceReady().";
        } // ✅ end inner WAIT loop

        nCount = 0;

        // ---- SCAN PHASE ----
        if (!m_cancel && m_scanId->IsScanDeviceReady())
        {
            // must be visible both inside the retry loop and in the post-loop check
            bool reacquire = false;
            int tries = 0;

            while (!m_cancel && tries++ < NUM_RETRY_SCANID)
            {

                // small bite/settle delay improves reliability right after cancel/soft reset
                QThread::msleep(120);
                // Ensure device is in a non-cancelled state before the scan call
                m_scanId->clearCancel();

                qDebug() << "Calling ScanImage().";
                success = m_scanId->ScanImage();

                if (success) break;
                if (m_cancel) break;

                error = m_scanId->getErrorMsg();

                // if "not ready" style error -> reacquire readiness instead of burning retries
                if (error.contains("Scan device not ready", Qt::CaseInsensitive) ||
                    error.contains("Sensor status is not correct", Qt::CaseInsensitive))
                {
                    qInfo() << "[ScanWorker] ScanImage aborted (not ready). Reacquiring readiness…";
                    QThread::msleep(150);  // back-off to let sensors/firmware settle
                    // Try a quick device recovery so repeated attempts don't churn
                    m_scanId->recoverToIdle("scan-image-abort");

                    reacquire = true;
                    break;   // exit RETRY loop to re-enter WAIT
                }

                emit m_cashingWnd->scanIdFailure(false, error);
                QThread::msleep(300);
            } // end RETRY loop

            if (!m_cancel && !success && reacquire) {
                // IMPORTANT: do NOT decrement retriesLeft for reacquire
                nCount = 0;
                continue;   // go back to WAIT without spending an outer retry
            }
        }

        else
        {
            const bool readyNow = m_scanId->IsScanDeviceReady();
            qWarning() << "[ScanWorker] skipping ScanImage(): cancel =" << m_cancel
                       << " openSuccess =" << success
                       << " ready =" << readyNow;
        }


        // ---- OUTCOME / RETRY ACCOUNTING ----
        if (success)
        {
            m_cashingWnd->setScanSuccess(true);
            emit m_cashingWnd->scanIdCompleted();
            break;  // done successfully
        }
        else
        {
            if (!m_cancel)
            {
                error = m_scanId->getErrorMsg();
                retriesLeft--;  // ⬅ spend one outer retry only on a real failure
                if (retriesLeft > 0) {
                    emit m_cashingWnd->scanIdFailure(false, error + "\nPlease try again.");
                    // loop continues to another outer attempt
                } else {
                    emit m_cashingWnd->scanIdFailure(false, error);
                    break; // no retries left
                }
            }
        }

        if (m_cancel && !success)
        {
            emit m_cashingWnd->scanIdFailure(false, QStringLiteral("The operation has been cancelled"));
            break;
        }
     } // end OUTER loop

     m_scanId->CloseDevice();
     m_cancel = false;
     m_scanId->ResetVariables();
}

void ScanWorker::cancelScanId(QThread* scanThread)
{
    m_cancel = true;
    m_scanId->cancelScanId();
    m_scanId->drainImages();

/*    if (scanThread)
    {
        int nCount = 0;
        while (nCount++ < 5 && scanThread->isRunning())
        {
            QThread::sleep(1);
        }
    }*/
}
