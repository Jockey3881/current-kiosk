#include <fstream>
#include <string>
#include <QDebug>
#include <QThread>
#include <QDateTime>
#include "scanid.h"
#include "../cashingwindow.h"
#include <QString>
#include <QStringList>
#include <limits>

static QString decodeSensors(BYTE sens) {
    QStringList bits;
    if (sens & 0x01) bits << "CheckEntry(front-right)";
    if (sens & 0x02) bits << "CheckInside(right-after-roller)";
    if (sens & 0x04) bits << "IDEntry(front-left)";
    if (sens & 0x08) bits << "IDInside(left-after-roller)";
    if (sens & 0x10) bits << "CoverOpen";
    if (sens & 0x20) bits << "Middle";
    if (sens & 0x80) bits << "MagStripeDataAvail";
    return bits.isEmpty() ? "none" : bits.join("|");
}

// Log a PriStatStr cleanly (fields per Pertech manuals)
static void logStatus(const char* tag, const PriStatStr& s) {
    qDebug().nospace()
    << tag
    << " sens=0x" << QString::number(s.ub_sens, 16)
    << " [" << decodeSensors(s.ub_sens) << "]"
    << " bx=" << int(s.ub_bx)
    << " bs=" << int(s.ub_bs)
    << " stat=" << int(s.ub_stat)
    << " sstat=" << int(s.ub_sstat)
    << " docid=" << int(s.uw_docid)
    << " vlen=" << s.ul_vlen;
}
// --- Idle/readiness helpers -----------------------------------------------

// Safe single read of status
static inline bool readStatus(PriStatStr* out) {
    if (!out) return false;
    DWORD rc = PiEZGetStatus(out);
    if (rc != 0) {
        qWarning().nospace() << "[ScanId] readStatus: PiEZGetStatus rc=" << rc;
        return false;
    }
    return true;
}

// Wait for sensors to be fully idle (sens == 0) for N consecutive polls.
// This prevents the next scan from arming while an entry sensor is still covered.
static bool waitForSensorsIdle(int timeoutMs, int stableCount = 3, int pollMs = 80) {
    const qint64 deadline = QDateTime::currentMSecsSinceEpoch() + timeoutMs;
    int stable = 0;
    PriStatStr st{};
    while (QDateTime::currentMSecsSinceEpoch() < deadline) {
        if (!readStatus(&st)) { QThread::msleep(pollMs); continue; }
        logStatus("[ScanId] waitForSensorsIdle()", st);
        if (st.ub_sens == 0) {
            if (++stable >= stableCount) return true;
        } else {
            stable = 0;
        }
        QThread::msleep(pollMs);
    }
    return false;
}


ScanId::ScanId(CashingWindow* cashingWnd) : m_cashingWnd(cashingWnd)
{
    m_dpi = 600;
    m_color = 0x01;
    m_delay = 0;	// tens of a second
    m_scan_type = 0x1;
    // Image settings
    m_image_format = 0x8;
    m_connected = false;
    m_bCancel = false;
    m_rec_buf = new BYTE[MAX_IMAGE_SIZE];
}

ScanId::~ScanId()
{
    if (m_rec_buf)
        delete[] m_rec_buf;
    if (m_connected)
        PiEZCloseDevice();
}

bool ScanId::OpenDevice()
{
    m_error = PiEZOpenDevice();
    if (m_error != 0)
    {
        GetErrorMessage();
        m_connected = false;
    } else
    {
        m_connected = true;
    }
    return m_connected;
}

void ScanId::CloseDevice()
{
    if (m_connected)
        PiEZCloseDevice();
    m_connected = false;
}

bool ScanId::IsScanDeviceReady()
{
    if (!m_connected) {
        strncpy(m_error_msg, "Not connected to scanner", ERROR_BUFFER_SIZE);
        m_error = -1;
        return false;
    }

    PriStatStr status{};
    m_error = PiEZGetStatus(&status);
    if (m_error != 0) {
        GetErrorMessage();
        qDebug() << "[ScanId] PiEZGetStatus error:" << m_error << getErrorMsg();
        return false;
    }

    logStatus("[ScanId] IsScanDeviceReady()", status); // <-- detailed sensor dump

    // Pertech: bit set == sensor covered.
    // We want only "entry left" (ID entry) OR only "entry right" (check entry) covered, nothing else.
    const bool checkEntry = status.ub_sens & 0x01;
    const bool checkInside = status.ub_sens & 0x02;
    const bool idEntry = status.ub_sens & 0x04;
    const bool idInside = status.ub_sens & 0x08;
    const bool coverOpen = status.ub_sens & 0x10;
    const bool middle = status.ub_sens & 0x20;

    if (coverOpen) {
        strncpy(m_error_msg, "Cover open", ERROR_BUFFER_SIZE);
        m_error = -1;
        return false;
    }

    // Exactly one entry sensor may be on, and no "inside" or "middle" yet.
    const int entryCount = (checkEntry ? 1 : 0) + (idEntry ? 1 : 0);
    const bool anyInside = checkInside || idInside || middle;

    if (entryCount == 1 && !anyInside) {
        return true; // good to start
    }

    strncpy(m_error_msg, "Sensor status is not correct", ERROR_BUFFER_SIZE);
    m_error = -1;
    return false;
}

// Return true when no transport sensors see media after an eject.
// Optionally returns a bitmask of "still covered" sensors.
static bool mediaCleared(int* outMaskBits = nullptr) {
    PriStatStr s{};
    DWORD rc = PiEZGetStatus(&s);
    if (rc != 0) {
        qWarning().nospace() << "[ScanId] mediaCleared GetStatus rc=" << rc;
        return false; // conservative: unknown -> treat as not clear
    }
    logStatus("[ScanId] mediaCleared()", s);

    const bool checkEntry  = s.ub_sens & 0x01;
    const bool checkInside = s.ub_sens & 0x02;
    const bool idEntry     = s.ub_sens & 0x04;
    const bool idInside    = s.ub_sens & 0x08;
    const bool middle      = s.ub_sens & 0x20;

    int mask = 0;
    if (checkEntry)  mask |= 0x01;
    if (checkInside) mask |= 0x02;
    if (idEntry)     mask |= 0x04;
    if (idInside)    mask |= 0x08;
    if (middle)      mask |= 0x20;
    if (outMaskBits) *outMaskBits = mask;

    return mask == 0;
}

// Force an explicit FRONT eject, then verify clear; retry/pulse if needed.
static bool ensureEjectedFront(const char* phaseTag,
                               int attempts = ID_EJECT_ATTEMPTS,
                               int settleMs = ID_EJECT_SETTLE_MS,
                               int finalPollMs = ID_EJECT_FINAL_POLL_MS) {
    auto pollClear = [&](int ms, const char* tag) {
        qint64 start = QDateTime::currentMSecsSinceEpoch();
        while (QDateTime::currentMSecsSinceEpoch() - start < ms) {
            QThread::msleep(100);
            if (mediaCleared(nullptr)) return true;
        }
        return false;
    };

    // 1) Always command a FRONT eject first, regardless of current sensors
    DWORD rc = PiEZEjectDocument(ID_EJECT_DIR);
    qInfo().nospace() << "[ScanId] " << phaseTag << " initial FRONT PiEZEjectDocument rc=" << rc;
    QThread::msleep(settleMs);
    if (pollClear(600, "[ScanId] verifyEject: initial")) return true;

    // 2) Not clear? Nudge a few times
    for (int i = 1; i <= attempts; ++i) {
        rc = PiEZEjectDocument(ID_EJECT_DIR);
        qInfo().nospace() << "[ScanId] " << phaseTag << " nudge#" << i
                          << " FRONT PiEZEjectDocument rc=" << rc;
        QThread::msleep(settleMs);
        if (pollClear(600, "[ScanId] verifyEject: nudge")) return true;
    }

    // 3) Still not clear? Soft reset + one final front eject, then final poll
    qWarning().nospace() << "[ScanId] " << phaseTag
                         << " verifyEject: still not clear -> soft reset + final FRONT eject";
    rc = PiScanSoftResetScanner();
    qInfo().nospace() << "[ScanId] " << phaseTag << " PiScanSoftResetScanner rc=" << rc;
    QThread::msleep(150);

    rc = PiEZEjectDocument(ID_EJECT_DIR);
    qInfo().nospace() << "[ScanId] " << phaseTag << " final FRONT PiEZEjectDocument rc=" << rc;
    QThread::msleep(settleMs);

    return pollClear(finalPollMs, "[ScanId] verifyEject: final-check");
}





bool ScanId::ScanImage()
{
    qInfo() << "[ScanId] entering ScanImage()";
    if(!m_connected) {
        strncpy(m_error_msg, "Not connected to scanner", ERROR_BUFFER_SIZE);
        return false;
    }
    // Clear any leftover cancel state before starting the new scan attempt
    clearCancel();


    if (m_bCancel)
        return false;

    // Trust the worker's debounced ready; just sample for logs and give the transport a tiny "bite"
    // (prevents the immediate-abort churn you saw after cancel/soft-reset)
    PriStatStr pre{};
    pollStatus(&pre, /*attempts*/3, /*msBetween*/50);
    logStatus("[ScanId] pre-scan status", pre);

    // small settle/bite so rollers consistently grab after ready
    QThread::msleep(200);

    // Tolerant readiness sampler: accept 3/5 samples OR the last two in a row.
    // This prevents "not ready (unstable)" churn from brief entry-sensor blips.
    {
        int readyCount = 0;
        bool lastWasReady = false;
        bool lastTwoReady = false;

        for (int i = 0; i < 5; ++i) {
            const bool r = IsScanDeviceReady();
            if (r) ++readyCount;
            lastTwoReady = lastWasReady && r;
            lastWasReady = r;
            QThread::msleep(60);
        }

        if (!(readyCount >= 3 || lastTwoReady)) {
            strncpy(m_error_msg, "Scan device not ready (unstable)", ERROR_BUFFER_SIZE);
            qWarning().nospace() << "[ScanId] ScanImage(): not ready after tolerant debounce "
                                 << "(readyCount=" << readyCount << ", lastTwo=" << (lastTwoReady ? "Y" : "N") << ")";
            return false;
        }
    }



    if (m_bCancel)
        return false;
    m_error = PiEZPerformScan(m_color, m_dpi, m_scan_type, m_delay);
    if (m_error != 0) {
        qWarning() << "[ScanId] PiEZPerformScan failed (code)" << m_error;
        GetErrorMessage();
        qWarning() << "[ScanId] error msg:" << m_error_msg;
        return false;
    }
    if (m_bCancel)
        return false;
    qDebug() << "PiEZPerformScan successfully";
    m_error = PiEZWaitForScanComplete();
    if (m_error != 0) {
        qWarning() << "GetStatus AFTER scan failed (code)" << m_error;
        GetErrorMessage();
        qWarning() << "GetStatus AFTER scan error msg:" << m_error_msg;
        return false;

    }
    if (m_bCancel)
        return false;
    qDebug() << "PiEZWaitForScanComplete successfully";
    m_error = PiEZGetStatus(&m_LastStatus);
    if (m_error != 0) {
        GetErrorMessage();
        return false;
    }
    if (m_bCancel)
        return false;
    DWORD rec_len = MAX_IMAGE_SIZE;

    // get document front
    BYTE doc_side = ID_FRONT;
    BYTE doc_rotation = ID_FR_ROTATION;
    rec_len = MAX_IMAGE_SIZE;  // <-- ensure full buffer for front every time
    m_error = PiEZGetLastDocument(m_image_format, doc_side, doc_rotation, &rec_len, m_rec_buf);
    if (m_error != 0) {
         qWarning() << "PiEZGetLastDocument FRONT failed (code)" << m_error;
        GetErrorMessage();
         qWarning() << "Front image error msg:" << m_error_msg << " rec_len=" << rec_len;
         return false;
            }
    if (m_bCancel)
        return false;
    m_cashingWnd->setScanFrontImage(m_rec_buf, rec_len);
 /*   std::string id_front_filename = "id_image_front.jpeg";
    std::ofstream id_front_file(id_front_filename, std::ios::binary);
    if (id_front_file.is_open()) {
        id_front_file.write(reinterpret_cast<const char*>(m_rec_buf), rec_len);
        id_front_file.close();
    } else {
        strncat(m_error_msg, "\nFailed to open file for writing: ", ERROR_BUFFER_SIZE);
        strncat(m_error_msg, id_front_filename.c_str(), ERROR_BUFFER_SIZE);
    }
*/
    if (m_bCancel)
        return false;
    // get document back
     // IMPORTANT: reset length before second PiEZGetLastDocument
    rec_len = MAX_IMAGE_SIZE;
    doc_side = ID_BACK;
    doc_rotation = ID_BK_ROTATION;
    m_error = PiEZGetLastDocument(m_image_format, doc_side, doc_rotation, &rec_len, m_rec_buf);
    if (m_error != 0) {
        qWarning() << "PiEZGetLastDocument BACK failed (code)" << m_error;
        GetErrorMessage();
        qWarning() << "Back image error msg:" << m_error_msg << " rec_len=" << rec_len;
        return false;
    }

    m_cashingWnd->setScanBackImage(m_rec_buf, rec_len);
/*    std::string id_back_filename = "id_image_back.jpeg";
    std::ofstream id_back_file(id_back_filename, std::ios::binary);
    if (id_back_file.is_open()) {
        id_back_file.write(reinterpret_cast<const char*>(m_rec_buf), rec_len);
        id_back_file.close();
    } else {
        strncat(m_error_msg, "\nFailed to open file for writing: ", ERROR_BUFFER_SIZE);
        strncat(m_error_msg,  id_back_filename.c_str(), ERROR_BUFFER_SIZE);
    }
*/
    // Force front eject and verify transport is clear
    if (!ensureEjectedFront("after-scan")) {
        qWarning() << "[ScanId] Eject verification FAILED: media still detected in path";
        m_error = 61;
        strncpy(m_error_msg, (char*)"Eject failed: ID still in path", ERROR_BUFFER_SIZE);
        return false;
    }

    // After a successful eject, require FULL idle (sens == 0) before we re-arm.
    if (!waitForSensorsIdle(/*timeoutMs*/ 3000, /*stableCount*/ 3, /*pollMs*/ 80)) {
        qWarning() << "[ScanId] Sensors did not reach idle after eject — attempting soft reset assist.";
    }

    // Small soft reset to clear any sticky state before next scan
    {
        DWORD rc = PiScanSoftResetScanner();
        qInfo().nospace() << "[ScanId] SoftReset after verified front-eject rc=" << rc;
        QThread::msleep(200);
    }

    // Final guard: ensure we hand back an idle device.
    waitForSensorsIdle(/*timeoutMs*/ 1500, /*stableCount*/ 2, /*pollMs*/ 90);


    qInfo() << "[ScanId] leaving ScanImage() success";
    return true;
}



void ScanId::GetErrorMessage()
{
    switch (m_error)
    {
    case 1:
        strncpy(m_error_msg, (char *)"Jam", ERROR_BUFFER_SIZE);
        break;
    case 2:
        strncpy(m_error_msg, (char *)"No Buffer", ERROR_BUFFER_SIZE);
        break;
    case 3:
        strncpy(m_error_msg, (char *)"Parameter N/A", ERROR_BUFFER_SIZE);
        break;
    case 4:
        strncpy(m_error_msg, (char *)"Parameter Fail", ERROR_BUFFER_SIZE);
        break;
    case 5:
        strncpy(m_error_msg, (char *)"Waiting", ERROR_BUFFER_SIZE);
        break;
    case 6:
        strncpy(m_error_msg, (char *)"In Progress", ERROR_BUFFER_SIZE);
        break;
    case 7:
        strncpy(m_error_msg, (char *)"Operation Fail", ERROR_BUFFER_SIZE);
        break;
    case 8:
        strncpy(m_error_msg, (char *)"TimeOut", ERROR_BUFFER_SIZE);
        break;
    case 9:
        strncpy(m_error_msg, (char *)"Invalid Buffer", ERROR_BUFFER_SIZE);
        break;
    case 10:
        strncpy(m_error_msg, (char *)"Document Length", ERROR_BUFFER_SIZE);
        break;
    case 11:
        strncpy(m_error_msg, (char *)"No Image", ERROR_BUFFER_SIZE);
        break;
    case 12:
        strncpy(m_error_msg, (char *)"Small Crop", ERROR_BUFFER_SIZE);
        break;
    case 13:
        strncpy(m_error_msg, (char *)"Reset", ERROR_BUFFER_SIZE);
        break;
    case 14:
        strncpy(m_error_msg, (char *)"Motor Time", ERROR_BUFFER_SIZE);
        break;
    case 15:
        strncpy(m_error_msg, (char *)"No MICR", ERROR_BUFFER_SIZE);
        break;
    case 16:
        strncpy(m_error_msg, (char *)"Cover Open", ERROR_BUFFER_SIZE);
        break;
    case 17:
        strncpy(m_error_msg, (char *)"Document Size", ERROR_BUFFER_SIZE);
        break;
    case 18:
        strncpy(m_error_msg, (char *)"Not Implemented", ERROR_BUFFER_SIZE);
        break;
    case 19:
        strncpy(m_error_msg, (char *)"No Document", ERROR_BUFFER_SIZE);
        break;
    case 20:
        strncpy(m_error_msg, (char *)"Skew", ERROR_BUFFER_SIZE);
        break;
    case 21:
        strncpy(m_error_msg, (char *)"Not Waiting", ERROR_BUFFER_SIZE);
        break;
    case 22:
        strncpy(m_error_msg, (char *)"MICR OverFlow", ERROR_BUFFER_SIZE);
        break;
    case 23:
        strncpy(m_error_msg, (char *)"Low Power", ERROR_BUFFER_SIZE);
        break;
    case 24:
        strncpy(m_error_msg, (char *)"Xmit N/A", ERROR_BUFFER_SIZE);
        break;
    case 25:
        strncpy(m_error_msg, (char *)"Warmup", ERROR_BUFFER_SIZE);
        break;
    case 26:
        strncpy(m_error_msg, (char *)" No Swipe", ERROR_BUFFER_SIZE);
        break;
    case 27:
        strncpy(m_error_msg, (char *)"BMP Error", ERROR_BUFFER_SIZE);
        break;
    case 28:
        strncpy(m_error_msg, (char *)"Too Short", ERROR_BUFFER_SIZE);
        break;
    case 29:
        strncpy(m_error_msg, (char *)"Double Feed", ERROR_BUFFER_SIZE);
        break;
    case 30:
        strncpy(m_error_msg, (char *)"Stacker Error", ERROR_BUFFER_SIZE);
        break;
    case 31:
        strncpy(m_error_msg, (char *)"Not Connected", ERROR_BUFFER_SIZE);
        break;
    case 32:
        strncpy(m_error_msg, (char *)"Not Open", ERROR_BUFFER_SIZE);
        break;
    case 33:
        strncpy(m_error_msg, (char *)"Data Overflow", ERROR_BUFFER_SIZE);
        break;
    case 34:
        strncpy(m_error_msg, (char *)"Small Buffer", ERROR_BUFFER_SIZE);
        break;
    case 35:
        strncpy(m_error_msg, (char *)"Not Compatible", ERROR_BUFFER_SIZE);
        break;
    case 36:
        strncpy(m_error_msg, (char *)"FW Download", ERROR_BUFFER_SIZE);
        break;
    case 37:
        strncpy(m_error_msg, (char *)"Bad Size Buffer", ERROR_BUFFER_SIZE);
        break;
    case 38:
        strncpy(m_error_msg, (char *)"No Acknowledge", ERROR_BUFFER_SIZE);
        break;
    case 42:
        strncpy(m_error_msg, (char *)"Illogical", ERROR_BUFFER_SIZE);
        break;
    case 50:
        strncpy(m_error_msg, (char *)"Lockup", ERROR_BUFFER_SIZE);
        break;
    case 51:
        strncpy(m_error_msg, (char *)"System Error", ERROR_BUFFER_SIZE);
        break;
    case 52:
        strncpy(m_error_msg, (char *)"MICR Decode Fwd Err", ERROR_BUFFER_SIZE);
        break;
    case 53:
        strncpy(m_error_msg, (char *)"MICR Decode Rev Err", ERROR_BUFFER_SIZE);
        break;
    case 54:
        strncpy(m_error_msg, (char *)"MICR Sec Lib Err", ERROR_BUFFER_SIZE);
        break;
    case 55:
        strncpy(m_error_msg, (char *)"MICR Decode CMC Err", ERROR_BUFFER_SIZE);
        break;
    case 56:
        strncpy(m_error_msg, (char *)"Thread Err", ERROR_BUFFER_SIZE);
        break;
    case 57:
        strncpy(m_error_msg, (char *)"Data Retrieve Err", ERROR_BUFFER_SIZE);
        break;
    case 58:
        strncpy(m_error_msg, (char *)"Unexpected Data Err", ERROR_BUFFER_SIZE);
        break;
    case 59:
        strncpy(m_error_msg, (char *)"Internal Memory Err", ERROR_BUFFER_SIZE);
        break;
    case 60:
        strncpy(m_error_msg, (char *)"File Err", ERROR_BUFFER_SIZE);
        break;
    case 61:
        strncpy(m_error_msg, (char *)"Output Err", ERROR_BUFFER_SIZE);
        break;
    case 62:
        strncpy(m_error_msg, (char *)"Unexpected document in path/blocking path", ERROR_BUFFER_SIZE);
        break;
    }
}

void ScanId::cancelScanId()
{
    m_bCancel = true;
    PiEZCancelScanWait();

    // Try to front-eject whatever might be in the path
    (void)ensureEjectedFront("on-cancel");

    // Soft reset to a known state
    if (m_connected) {
        DWORD rc = PiScanSoftResetScanner();
        qInfo() << "[ScanId] SoftReset on cancel =" << (rc == 0 ? "OK" : "FAILED") << " rc=" << rc;
        QThread::msleep(150);
    }

    // Drain any possible latent images from the device
    (void)drainImages();

    // DO NOT leave sticky cancel set forever — the worker controls overall cancel loop.
    // We clear it so a fresh arm can occur the next time the worker runs.
    m_bCancel = false;
}




QString ScanId::getErrorMsg()
{
    QString sError = m_error_msg;
    return sError;
}

void ScanId::ResetVariables() {
    memset(m_error_msg, 0, ERROR_BUFFER_SIZE);
    m_error = 0;
    m_connected = false;
    m_bCancel = false;
}
// --- DROP-IN: readiness / reset helpers ---

bool ScanId::softReset() {
    DWORD rc = PiScanSoftResetScanner(); // Correct Linux API symbol
    if (rc == 0) {
        qDebug() << "[ScanId] Soft reset ok";
        return true;
    } else {
        qWarning() << "[ScanId] Soft reset FAILED rc=" << rc;
        return false;
    }
}

bool ScanId::pollStatus(PriStatStr* out, int attempts, int msBetween) {
    PriStatStr s{};
    for (int i = 0; i < attempts; ++i) {
        DWORD rc = PiEZGetStatus(&s);
        if (rc != 0) {
            qWarning() << "[ScanId] pollStatus PiEZGetStatus rc=" << rc;
            return false;
        }
        // Optional: verbose sensor trace you already use
        logStatus("[ScanId] pollStatus()", s);

        if (out) *out = s;
        QThread::msleep(msBetween);
    }
    if (out) *out = s;
    return true;
}

bool ScanId::mediaPresentBits(const PriStatStr& s) {
    // Interpret Pertech sensors (bit set == covered)
    const bool checkInside = s.ub_sens & 0x02; // right-after-roller
    const bool idInside    = s.ub_sens & 0x08; // left-after-roller
    const bool middle      = s.ub_sens & 0x20; // middle path

    // If any "inside/middle" bit is set, media still in the transport path
    return checkInside || idInside || middle;
}

void ScanId::clearCancel() {
    if (m_bCancel) {
        qInfo() << "[ScanId] clearCancel(): clearing sticky cancel flag";
    }
    m_bCancel = false;
}

bool ScanId::drainImages() {
    if (!m_connected) return false;
    DWORD rec_len; BYTE doc_side; BYTE doc_rotation;
    auto tryOne = [&](BYTE side, BYTE rot){
        rec_len = MAX_IMAGE_SIZE;
        DWORD rc = PiEZGetLastDocument(m_image_format, side, rot, &rec_len, m_rec_buf);
        if (rc == 0) qInfo().nospace() << "[ScanId] drainImages: side=" << int(side) << " rot=" << int(rot) << " len=" << rec_len;
        else if (rc != 11) qInfo().nospace() << "[ScanId] drainImages: side=" << int(side) << " rc=" << rc << " (ignored)";
    };
    tryOne(ID_FRONT, ID_FR_ROTATION);
    tryOne(ID_BACK,  ID_BK_ROTATION);
    return true;
}

bool ScanId::recoverToIdle(const char* reasonTag) {
    qInfo().nospace() << "[ScanId] recoverToIdle(" << (reasonTag ? reasonTag : "") << ")";
    (void)ensureEjectedFront("recoverToIdle");
    DWORD rc = PiScanSoftResetScanner();
    qInfo().nospace() << "[ScanId] recoverToIdle: SoftReset rc=" << rc;
    QThread::msleep(150);
    (void)drainImages();
    if (!waitForMediaClear(15, 120)) qWarning() << "[ScanId] recoverToIdle: transport did not clear";
    m_bCancel = false;
    qInfo() << "[ScanId] recoverToIdle: complete";
    return true;
}



bool ScanId::waitForMediaClear(int attempts, int msBetween) {
    PriStatStr s{};
    for (int i = 0; i < attempts; ++i) {
        DWORD rc = PiEZGetStatus(&s);
        if (rc != 0) {
            qWarning() << "[ScanId] waitForMediaClear GetStatus rc=" << rc;
            return false;
        }
        logStatus("[ScanId] mediaCleared()", s);

        if (!mediaPresentBits(s)) {
            return true; // transport clear
        }
        QThread::msleep(msBetween);
    }
    return false; // timed out waiting for clear
}

