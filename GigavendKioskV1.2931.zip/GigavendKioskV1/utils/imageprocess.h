#ifndef IMAGEPROCESS_H
#define IMAGEPROCESS_H

#include <QObject>
#include <QThread>

class CashingWindow;
class FingerPrint;
class FingerWorker : public QObject {
    Q_OBJECT
public:
    FingerWorker(CashingWindow* cashingWnd);
    virtual ~FingerWorker();
    void cancelFingerPrint(QThread* fingerThread);
public slots:
    void doWork();

private:
    CashingWindow* m_cashingWnd;
    FingerPrint* m_fingerPrint;
};
/*
class ImageProcessThread : public QThread
{

};
*/
#endif // IMAGEPROCESSTHREAD_H
