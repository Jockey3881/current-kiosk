// CheckImageProvider.cpp
// Full file — paste this over your existing implementation.

#include "checkimageprovider.h"
#include "cashingwindow.h"

#include <QDebug>
#include <QImage>
#include <QSize>

CheckImageProvider::CheckImageProvider(CashingWindow *cashingWindow)
    : QQuickImageProvider(QQuickImageProvider::Image),
      m_cashingWindow(cashingWindow)
{
}

QImage CheckImageProvider::requestImage(const QString &id, QSize *size, const QSize &requestedSize)
{
    // Log the raw id we receive from QML (often has query params like ?t=123)
    qInfo() << "[CheckImageProvider] requestImage id:" << id << "requestedSize:" << requestedSize;

    // Normalize the id by stripping any query string and path segments.
    QString key = id;
    const int qpos = key.indexOf('?');
    if (qpos >= 0)
        key = key.left(qpos);
    const int slash = key.lastIndexOf('/');
    if (slash >= 0)
        key = key.mid(slash + 1);

    QImage image;

    if (key == QLatin1String("checkFront")) {
        image = m_cashingWindow ? m_cashingWindow->getCheckFrontImage() : QImage();
    } else if (key == QLatin1String("checkBack")) {
        image = m_cashingWindow ? m_cashingWindow->getCheckBackImage() : QImage();
    } else if (key == QLatin1String("kioskPhoto")) {
        image = m_cashingWindow ? m_cashingWindow->getKioskPhoto() : QImage();
    } else {
        qWarning() << "[CheckImageProvider] Unknown image key:" << key;
    }

    if (size)
        *size = image.size();

    // Only scale if a valid target size was requested
    if (requestedSize.width() > 0 && requestedSize.height() > 0) {
        image = image.scaled(requestedSize, Qt::KeepAspectRatio, Qt::SmoothTransformation);
    }

    return image;
}

