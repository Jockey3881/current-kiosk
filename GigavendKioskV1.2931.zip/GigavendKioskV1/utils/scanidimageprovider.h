#ifndef SCANIDIMAGEPROVIDER_H
#define SCANIDIMAGEPROVIDER_H

#include <QQuickImageProvider>
#include "../cashingwindow.h"

class ScanIdImageProvider : public QQuickImageProvider
{
public:
    // This is a declaration. The implementation is in the .cpp file.
    ScanIdImageProvider(CashingWindow *cashingWindow);

    // This is also just a declaration.
    QImage requestImage(const QString &id, QSize *size, const QSize &requestedSize) override;

private:
    CashingWindow *m_cashingWindow;
};

#endif // SCANIDIMAGEPROVIDER_H
