#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <fstream>
#include <sys/time.h>
#include <locale.h>
#include <QThread>
#include "fingerprint.h"
#include "../cashingwindow.h"

const int NUM_FINGERPRINT_RETRY = 5;
FingerPrint::FingerPrint(CashingWindow* cashingWnd) : m_cashingWnd(cashingWnd)
{
    m_hReader = NULL; //handle of the selected reader
    m_canCaptureImage = false;
    m_canStreamImage = false;
    m_bCancel = false;
    m_DPFJ_FMD = DPFJ_FMD_ANSI_378_2004;
    m_dpi = 508;
}

FingerPrint::~FingerPrint()
{
}

int FingerPrint::CaptureFinger()
{
    int result = 0, res;
    char szReader[MAX_DEVICE_NAME_LENGTH]; //name of the selected reader
    m_bCancel = false;
    result = dpfpdd_init();
    if(DPFPDD_SUCCESS != result) {
        print_error("dpfpdd_init()", result);
        result = -1;
    } else{
        if (SelectAndOpenReader(szReader, sizeof(szReader)))
        {
            if (m_hReader == NULL)
            {
                print_error("CaptureFinger", -1);
                result = -1;
            } else if(!m_canCaptureImage)
            {
                m_Error = "This reader cannot work in capture mode \n\n";
                result = -1;
            } else
            {
                result = Enrollment();
            }
        } else
        {
            result = -1;
        }
        //close reader
        if(NULL != m_hReader){
            res = dpfpdd_close(m_hReader);
            if(DPFPDD_SUCCESS != res)
            {
                print_error("dpfpdd_close()", res);
                result = res;
            }
            m_hReader = NULL;
        }

        //release capture library
        dpfpdd_exit();
    }

    return result;
}

void FingerPrint::print_error(const char* szFunctionName, int nError){

    char sz[512];

    if(_DP_FACILITY == (nError >> 16)){
        char szError[256];

        switch(nError){

        case DPFPDD_E_NOT_IMPLEMENTED: strncpy(szError, "API call is not implemented.", 256); break;

        case DPFPDD_E_FAILURE: strncpy(szError, "Unspecified failure.", 256); break;

        case DPFPDD_E_NO_DATA: strncpy(szError, "No data is available.", 256); break;

        case DPFPDD_E_MORE_DATA: strncpy(szError, "The memory allocated by the application is not big enough for the data which is expected.", 256); break;

        case DPFPDD_E_INVALID_PARAMETER: strncpy(szError, "One or more parameters passed to the API call are invalid.", 256); break;

        case DPFPDD_E_INVALID_DEVICE: strncpy(szError, "Reader handle is not valid.", 256); break;

        case DPFPDD_E_DEVICE_BUSY: strncpy(szError, "The API call cannot be completed because another call is in progress.", 256); break;

        case DPFPDD_E_DEVICE_FAILURE: strncpy(szError, "The reader is not working properly.", 256); break;

        case DPFJ_E_INVALID_FID: strncpy(szError, "FID is invalid.", 256); break;

        case DPFJ_E_TOO_SMALL_AREA: strncpy(szError, "Image is too small.", 256); break;

        case DPFJ_E_INVALID_FMD: strncpy(szError, "FMD is invalid.", 256); break;

        case DPFJ_E_ENROLLMENT_IN_PROGRESS: strncpy(szError, "Enrollment operation is in progress.", 256); break;

        case DPFJ_E_ENROLLMENT_NOT_STARTED: strncpy(szError, "Enrollment operation has not begun.", 256); break;

        case DPFJ_E_ENROLLMENT_NOT_READY: strncpy(szError, "Not enough in the pool of FMDs to create enrollment FMD.", 256); break;

        case DPFJ_E_ENROLLMENT_INVALID_SET: strncpy(szError, "Unable to create enrollment FMD with the collected set of FMDs.", 256); break;

        case DPFJ_E_COMPRESSION_IN_PROGRESS: strncpy(szError, "Compression or decompression operation is in progress", 256); break;

        case DPFJ_E_COMPRESSION_NOT_STARTED: strncpy(szError, "Compression or decompression operation was not started.", 256); break;

        case DPFJ_E_COMPRESSION_INVALID_WSQ_PARAMETER: strncpy(szError, "One or more parameters passed for WSQ compression are invalid.", 256); break;

        case DPFJ_E_COMPRESSION_WSQ_FAILURE: strncpy(szError, "Unspecified error during WSQ compression or decompression.", 256); break;

        case DPFJ_E_COMPRESSION_WSQ_LIB_NOT_FOUND: strncpy(szError, "Library for WSQ compression is not found or not built-in.", 256); break;

        case DPFJ_E_QUALITY_NO_IMAGE: strncpy(szError, "Image is invalid or absent.", 256); break;

        case DPFJ_E_QUALITY_TOO_FEW_MINUTIA: strncpy(szError, "Too few minutia detected in the fingerprint image.", 256); break;

        case DPFJ_E_QUALITY_FAILURE: strncpy(szError, "Unspecified error during execution.", 256); break;

        case DPFJ_E_QUALITY_LIB_NOT_FOUND: strncpy(szError, "Library for image quality is not found or not built-in.", 256); break;

        }

        sprintf(sz, "%s returned DP error: 0x%x \n%s", szFunctionName, (0xffff & nError), (const char*)szError);
    }
    else{
        sprintf(sz, "%s returned system error: 0x%x", szFunctionName, (0xffff & nError));
    }

    m_Error = sz;
}

int FingerPrint::Enrollment(){
    int bStop = 0;
    int result = 0, res;
    while(!m_bCancel && !bStop){
        unsigned char* pFmd = NULL;
        unsigned int nFmdSize = 0;

        printf("Enrollment started\n\n");

        //start the enrollment
        result = dpfj_start_enrollment(m_DPFJ_FMD);
        if(DPFJ_SUCCESS != result){
            print_error("dpfj_start_enrollment()", result);
            return result;
        }

        //capture fingers, create templates
        int bDone = 0;
        int num_retry = 0;
        while(!m_bCancel && !bDone){
            //capture finger, create template
            result = CaptureFinger(&pFmd, &nFmdSize);
            if(0 != result){
                if (num_retry++ < NUM_FINGERPRINT_RETRY)
                    continue;
                else
                {
                    bStop = 1;
                    break;
                }
            }

            //add template to enrollment
            res = dpfj_add_to_enrollment(m_DPFJ_FMD, pFmd, nFmdSize, 0);

            //template is not needed anymore
            free(pFmd);
            pFmd = NULL;

            if(DPFJ_E_MORE_DATA == res){
                //need to add another template
                continue;
            }
            else if(DPFJ_SUCCESS == res){
                //enrollment is ready
                bDone = 1;
                result = res;
                break;
            }
            else{
                print_error("dpfj_add_to_enrollment()", res);
                result = res;
                break;
            }
        }

        //determine size (optional, MAX_FMR_SIZE can be used)
        unsigned char* pEnrollmentFmd = NULL;
        unsigned int nEnrollmentFmdSize = 0;

        if(!m_bCancel && bDone){
            result = dpfj_create_enrollment_fmd(NULL, &nEnrollmentFmdSize);

            if(DPFJ_E_MORE_DATA == result){
                pEnrollmentFmd = (unsigned char*)malloc(nEnrollmentFmdSize);
                if(NULL == pEnrollmentFmd){
                    print_error("malloc()", result);
                }
                else{
                    result = dpfj_create_enrollment_fmd(pEnrollmentFmd, &nEnrollmentFmdSize);
                }
            }
            if(DPFJ_SUCCESS != result){
                print_error("dpfj_create_enrollment_fmd()", result);
                nEnrollmentFmdSize = 0;
            }

            if(NULL != pEnrollmentFmd && 0 != nEnrollmentFmdSize){
                printf("Enrollment template created, size: %d\n\n\n", nEnrollmentFmdSize);

                //now enrollment template can be stored in the database
                if (m_cashingWnd != nullptr)
                {
                    m_cashingWnd->setFingerImage(pEnrollmentFmd, nEnrollmentFmdSize);
                    emit m_cashingWnd->fingerPrintCompleted();
                    bStop = 1;
                    bDone = 1;
/*
                    std::string id_front_filename = "fingerprint_minutia.fmd";
                    std::ofstream id_front_file(id_front_filename, std::ios::binary);
                    if (id_front_file.is_open()) {
                        id_front_file.write(reinterpret_cast<const char*>(pEnrollmentFmd), nEnrollmentFmdSize);
                        id_front_file.close();
                    }*/
                }
            }
            if(NULL != pEnrollmentFmd)
            {
                //release memory
                free(pEnrollmentFmd);
                pEnrollmentFmd = NULL;
            }
        }

        //finish the enrollment
        res = dpfj_finish_enrollment();
        if(DPFJ_SUCCESS != res){
            print_error("dpfj_finish_enrollment()", res);
            result = res;
        }
    }
    
    return result;
}

bool FingerPrint::SelectAndOpenReader(char* szReader, size_t nReaderLen)
{
    strncpy(szReader, "", nReaderLen);
    DPFPDD_DEV_INFO* pReaderInfo = NULL;
    DPFPDD_DEV_CAPS* pCaps = NULL;
    bool res = false;

    //enumerate the readers
    unsigned int nReaderCnt = 1;
    pReaderInfo = (DPFPDD_DEV_INFO*)malloc(sizeof(DPFPDD_DEV_INFO) * nReaderCnt);

    while(!m_bCancel && NULL != pReaderInfo){
        unsigned int i = 0;
        for(i = 0; i < nReaderCnt; i++){
            pReaderInfo[i].size = sizeof(DPFPDD_DEV_INFO);
        }

        unsigned int nNewReaderCnt = nReaderCnt;
        int result = dpfpdd_query_devices(&nNewReaderCnt, pReaderInfo);

        //quit if error
        if(DPFPDD_SUCCESS != result && DPFPDD_E_MORE_DATA != result){
            print_error("dpfpdd_query_devices()", result);
            break;
        }

        //allocate memory if needed and do over
        if(DPFPDD_E_MORE_DATA == result){
            DPFPDD_DEV_INFO* pri = (DPFPDD_DEV_INFO*)realloc(pReaderInfo, sizeof(DPFPDD_DEV_INFO) * nNewReaderCnt);
            if(NULL == pri){
                print_error("realloc()", ENOMEM);
                break;
            }
            pReaderInfo = pri;
            nReaderCnt = nNewReaderCnt;
            continue;
        }
        //success
        nReaderCnt = nNewReaderCnt;
        break;
    }

    if (!m_bCancel && pReaderInfo != NULL)
    {
        //open reader
        int result = dpfpdd_open(pReaderInfo[0].name, &m_hReader);
        if(DPFPDD_SUCCESS == result){
            strncpy(szReader, pReaderInfo[0].name, nReaderLen);
            //read capabilities
            unsigned int nCapsSize = sizeof(DPFPDD_DEV_CAPS);
            while(!m_bCancel){
                pCaps = (DPFPDD_DEV_CAPS*)malloc(nCapsSize);
                if(NULL == pCaps){
                    print_error("malloc()", ENOMEM);
                    break;
                }
                pCaps->size = nCapsSize;
                result = dpfpdd_get_device_capabilities(m_hReader, pCaps);
                if(DPFPDD_SUCCESS != result && DPFPDD_E_MORE_DATA != result){
                    print_error("dpfpdd_get_device_capabilities()", result);
//                        free(pCaps);
                    break;
                }
                if(DPFPDD_E_MORE_DATA == result){
                    nCapsSize = pCaps->size;
                    free(pCaps);
                    continue;
                }
                //capabilities acquired
                m_canCaptureImage = pCaps->can_capture_image;
                m_canStreamImage = pCaps->can_stream_image;
//                m_dpi = pCaps->resolutions[0];
                res = true;
                break;
            }
        } else {
            print_error("dpfpdd_open()", result);
        }
    }

    if(NULL != pReaderInfo) free(pReaderInfo);
    if (NULL != pCaps) free(pCaps);

    if (!m_bCancel && res)
    {
        // configure the led
        int result = dpfpdd_led_config(m_hReader, DPFPDD_LED_MAIN, DPFPDD_LED_AUTO, NULL);
        if (result != DPFPDD_SUCCESS) {
            char szError[256];
            sprintf(szError, "Failed to configure LED with code: %d", result);
            m_Error = szError;
            res = false;
        }
    }

    return res;
}

int FingerPrint::IsDeviceReady(unsigned int nOrigImageSize)
{
    unsigned int nImageSize = nOrigImageSize;
    int is_ready = 0;
    int result = 0;

    while(!m_bCancel){
        DPFPDD_DEV_STATUS ds;
        ds.size = sizeof(DPFPDD_DEV_STATUS);

        result = dpfpdd_get_device_status(m_hReader, &ds);
        if(DPFPDD_SUCCESS != result){
            print_error("dpfpdd_get_device_status()", result);
            break;
        }
        if(DPFPDD_STATUS_FAILURE == ds.status){
            print_error("Reader failure", DPFPDD_STATUS_FAILURE);
            result = DPFPDD_STATUS_FAILURE;
            break;
        }

        if(DPFPDD_STATUS_READY == ds.status || DPFPDD_STATUS_NEED_CALIBRATION == ds.status){
            is_ready = 1;
            break;
        }

        unsigned long secs = 1;
        QThread::sleep(secs);
    }

    return is_ready;
}

int FingerPrint::CaptureFinger(unsigned char** ppFt, unsigned int* pFtSize)
{
	int result = 0;
	*ppFt = NULL;
	*pFtSize = 0;
    char sz[512], tmp[256];
    const unsigned int CBEFF_ID = 0x003F;
	//prepare capture parameters and result
	DPFPDD_CAPTURE_PARAM cparam = {0};
	cparam.size = sizeof(cparam);
	cparam.image_fmt = DPFPDD_IMG_FMT_PIXEL_BUFFER;  // Raw format
	cparam.image_proc = DPFPDD_IMG_PROC_DEFAULT;     // Default processing
	cparam.image_res = m_dpi;

	DPFPDD_CAPTURE_RESULT cresult = {0};
	cresult.size = sizeof(cresult);
	cresult.info.size = sizeof(cresult.info);

	//get size of the image
	unsigned int nOrigImageSize = 0;
	result = dpfpdd_capture(m_hReader, &cparam, 0, &cresult, &nOrigImageSize, NULL);
	if(DPFPDD_E_MORE_DATA != result){
		print_error("dpfpdd_capture()", result);
		return result;
	}

	unsigned char* pImage = (unsigned char*)malloc(nOrigImageSize);
	if(NULL == pImage){
		print_error("malloc()", ENOMEM);
		return ENOMEM;
	}

	while(!m_bCancel){
		//wait until ready
		unsigned int nImageSize = nOrigImageSize;
        int is_ready = IsDeviceReady(nOrigImageSize);
        if(!is_ready) break;

		//capture fingerprint
        printf("Put any finger on the reader\r\n");

		result = dpfpdd_capture(m_hReader, &cparam, -1, &cresult, &nImageSize, pImage);
		if(DPFPDD_SUCCESS != result){
			print_error("dpfpdd_capture()", result);
		}
		else
        {
			if(cresult.success){
				//captured
				printf("    fingerprint captured,\n");

				//get max size for the feature template
				unsigned int nFeaturesSize = MAX_FMD_SIZE;
				unsigned char* pFeatures = (unsigned char*)malloc(nFeaturesSize);
				if(NULL == pFeatures){
					print_error("malloc()", ENOMEM);
					result = ENOMEM;
				}
				else
                {
					//create template
					long mseconds;
					struct timeval tv1, tv2;
					gettimeofday(&tv1, NULL);

//					result = dpfj_create_fmd_from_fid(DPFJ_FID_ISO_19794_4_2005, pImage, nImageSize, m_DPFJ_FMD, pFeatures, &nFeaturesSize);

                    result = dpfj_create_fmd_from_raw(
                        pImage,
                        nImageSize,
                        cresult.info.width,
                        cresult.info.height,
                        cparam.image_res,
                        DPFJ_POSITION_UNKNOWN,
                        CBEFF_ID,
                        m_DPFJ_FMD,
                        pFeatures,
                        &nFeaturesSize);

					gettimeofday(&tv2, NULL);

					mseconds = (tv2.tv_sec - tv1.tv_sec) * 1000 + (tv2.tv_usec - tv1.tv_usec) / 1000; //time of operation in milliseconds

					if(DPFJ_SUCCESS == result){
						*ppFt = pFeatures;
						*pFtSize = nFeaturesSize;
						printf("    features extracted (%ldms).\n\n", mseconds);
					}
					else{
                        print_error("dpfj_create_fmd_from_raw()", result);
						free(pFeatures);
                        pFeatures = NULL;
					}
				}
			}
			else if(DPFPDD_QUALITY_CANCELED == cresult.quality){
				//capture canceled
				result = EINTR;
			}
			else{
				//bad capture
                sprintf(sz, "bad capture, quality feedback: 0x%x\n", cresult.quality);

				unsigned int i = 0;

                for(i = 1; i < 0x80000000 && !m_bCancel; i <<= 1){

					switch(cresult.quality & i){

					case 0: break;

                    case DPFPDD_QUALITY_TIMED_OUT:            strncat(sz, "timeout expired \n", 256); break;

                    case DPFPDD_QUALITY_CANCELED:             strncat(sz, "capture was canceled \n", 256); break;

                    case DPFPDD_QUALITY_NO_FINGER:            strncat(sz, "not a finger detected \n", 256); break;

                    case DPFPDD_QUALITY_FAKE_FINGER:          strncat(sz, "fake finger detected \n", 256); break;

                    case DPFPDD_QUALITY_FINGER_TOO_LEFT:      strncat(sz, "finger is too far left on the reader \n", 256); break;

                    case DPFPDD_QUALITY_FINGER_TOO_RIGHT:     strncat(sz, "finger is too far right on the reader \n", 256); break;

                    case DPFPDD_QUALITY_FINGER_TOO_HIGH:      strncat(sz, "finger is too high on the reader \n", 256); break;

                    case DPFPDD_QUALITY_FINGER_TOO_LOW:       strncat(sz, "finger is too low in the reader \n", 256); break;

                    case DPFPDD_QUALITY_FINGER_OFF_CENTER:    strncat(sz, "finger is not centered on the reader \n", 256); break;

                    case DPFPDD_QUALITY_SCAN_SKEWED:          strncat(sz, "scan is skewed too much \n", 256); break;

                    case DPFPDD_QUALITY_SCAN_TOO_SHORT:       strncat(sz, "scan is too short \n", 256); break;

                    case DPFPDD_QUALITY_SCAN_TOO_LONG:        strncat(sz, "scan is too long \n", 256); break;

                    case DPFPDD_QUALITY_SCAN_TOO_SLOW:        strncat(sz, "speed of the swipe is too slow \n", 256); break;

                    case DPFPDD_QUALITY_SCAN_TOO_FAST:        strncat(sz, "speed of the swipe is too fast \n", 256); break;

                    case DPFPDD_QUALITY_SCAN_WRONG_DIRECTION: strncat(sz, "direction of the swipe is wrong \n", 256); break;

                    case DPFPDD_QUALITY_READER_DIRTY:         strncat(sz, "reader needs cleaning \n", 256); break;

                    default:
                        sprintf(tmp, "unknown quality bitmask: 0x%x \n", i);
                        strncat(sz, tmp, 256);
                        break;

					}
				}
                m_Error = sz;
				continue;
			}
		}
		break;
	}

	if(NULL != pImage) free(pImage);

	return result;
}


void FingerPrint::cancelFingerPrint()
{
    m_bCancel = true;
    if (m_hReader)
        dpfpdd_cancel(m_hReader);
}
