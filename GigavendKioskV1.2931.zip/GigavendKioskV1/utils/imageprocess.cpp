#include "imageprocess.h"
#include "../cashingwindow.h"
#include "fingerprint.h"

FingerWorker::FingerWorker(CashingWindow* cashingWnd)
    : m_cashingWnd(cashingWnd)
{
    m_fingerPrint = new FingerPrint(cashingWnd);
}

FingerWorker::~FingerWorker()
{
    if (m_fingerPrint)
        delete m_fingerPrint;
}

void FingerWorker::doWork()
{
    // Notify QML that fingerprint capture is starting (spinner animation, etc.)
    if (m_cashingWnd) {
        emit m_cashingWnd->fingerPrintStarted();
    }

    // Run the actual capture
    int result = m_fingerPrint->CaptureFinger();

    // If error, propagate failure back to QML
    if (result != 0) {
        QString sError = m_fingerPrint->getError();
        if (m_cashingWnd) {
            emit m_cashingWnd->fingerPrintFailure(true, sError);
        }
    }
    // On success, FingerPrint::Enrollment() / CaptureFinger() itself
    // emits fingerPrintCompleted() through m_cashingWnd.
}

void FingerWorker::cancelFingerPrint(QThread* fingerThread)
{
    if (m_fingerPrint)
        m_fingerPrint->cancelFingerPrint();

    // Optional: wait for the worker thread to stop (commented out for now)
    /*
    if (fingerThread)
    {
        int nCount = 0;
        while (nCount++ < 5 && fingerThread->isRunning())
        {
            QThread::sleep(1);
        }
    }
    */
}
