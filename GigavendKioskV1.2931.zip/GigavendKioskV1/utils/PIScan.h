/*******************************************************************************
* Copyright 2016-2017 (c) Pertech Industries Inc.
* All Rights Reserved
*
* The information contained herein is confidential property of Pertech Industries Inc.
* The use, copying, transfer, or disclosure of such information is prohibited
* except by express written agreement with Pertech Resources.
*
* Project:     Pertech Industries 6100 API Header File
* Description: This DLL provides functions communicate with the 6100 check scanner.
*
*
* Revision history:
*	DATE		NAME	CHANGE
*	2016.12.01	CP		Initial Rewrite
*******************************************************************************/
#ifndef PISCAN_H_
#define PISCAN_H_

#include <stdlib.h>
#include <stdint.h>

#define WINAPI

typedef uint8_t   		BYTE;
typedef uint8_t   		UCHAR;
typedef uint8_t   		TCHAR;
typedef int16_t  		SHORT;
typedef uint16_t  		USHORT;
typedef uint32_t  		DWORD;
typedef uint32_t  		ULONG;
typedef uint16_t  		WORD;
typedef int16_t *  		LPWORD;
typedef uint8_t *  		LPBYTE;
typedef uint32_t *		LPDWORD;
typedef bool			BOOL;
typedef int32_t			__int32;
typedef int32_t			LONG;			// may be int64_t
typedef void * 			PVOID;
typedef char * 			LPCTSTR;
typedef void * 			HANDLE;
typedef void * 			HWND;
typedef int64_t			__int64;
typedef void * 			HHOOK;

union			LARGE_INTEGER {
	struct {
		DWORD LowPart;
		LONG HighPart;
	} u;
	int64_t QuadPart;
};

typedef struct
{
	BYTE   ub_uf; 		// Unique Flag:
						//     Always equal to 0x1A.
						//     Indicates this is a response from a
						//     commanded function.

	BYTE   ub_id;      	// Identification of the device class:
						//     Always equal to  0xCC.

	BYTE   ub_cc;      	// 2nd byte of the firmware command code:
						//     Values are from the command specification.

	BYTE   ub_sens;    	// Sensor State:
						// Bits indicating sensors:
						// 	(0 is open, 1 is currently covered)
						// 	Bit 0 = front right entry
						// 	Bit 1 = front right inside
						// 	Bit 2 = front left entry
						// 	Bit 3 = front left inside
						// 	Bit 4 = cover open
						// 	Bit 5 = middle sensor

	BYTE   ub_bx;      	// Image buffer index:
						//     When returned from the PriBESelectScanFunctions
						//     method, this may refer to the next free buffer
						//     to be used as a parameter to several other
						//     methods.
						//     It may also identify the device's buffer that is
						//     holding the data relevant to this status return.
						//	Values start at 1, as 0 stands for none or not
						//     applicable.

	BYTE   ub_bs;      	// Image buffer state:
						//     Values:
						//     0 = free
						//     1 = in current use,
						//     2 = data ready,
						//     3 = successfully transmitted at least once.
						//     Not applicable if ub_bx is zero.


	BYTE   ub_stat;    	// Primary status:
						//     The value will be equal to one of
						//     the Error Codes listed in this guide.
						//     e.g. PrsStat_OK = 0.


	BYTE   ub_sstat;   	// Secondary status:
						// 	Additional status to alert application
						//	to conditions of possible interest;
						//	Mostly used when Primary status = 0.

	WORD   uw_cmdno;	// 2 byte reserved for future use.

	SHORT  uw_docid;   	// Document number:
						//     Internally generated image counter
						//     value for the data in the buffer;
						//     Equal to -1 if none. Note that this
						//     rolls over at 32,767.

	DWORD  ul_vlen;    	// Length of following data:
						//     Not applicable to all methods.
						//     If a command does not return any data,
						//     this will be equal to zero.
						//     (Check command description for specific
						//     use;  e.g. For transmit image command,
						//     this will be size of scanned image.)

} PriStatStr;

const DWORD statLen = sizeof(PriStatStr);

#ifdef __cplusplus
extern "C" {
#endif

#define DLLEXPORT __attribute__ ((visibility("default")))
#define DLL_LOCAL  __attribute__ ((visibility("hidden")))

#ifdef __cplusplus
} /* extern "C" */
#endif

extern "C" {
	DLLEXPORT	DWORD	PiScanGetPropAPIVersion(LPBYTE stringVersion);
	DLLEXPORT	DWORD	PiScanXmitRawMICR(BYTE bufIndex, LPDWORD recLen, LPBYTE recBUF);
	DLLEXPORT	DWORD	PiScanResetScanner(void);
	DLLEXPORT	DWORD	PiScanSoftResetScanner(void);
	DLLEXPORT	DWORD	PiScanCalibrateScannerWhite();
	DLLEXPORT	DWORD	PiScanXfn(BYTE diagFn, LPDWORD recLen, LPBYTE recBuf);

	//--------------------- Start EZ Commands ------------------------------------
	DLLEXPORT DWORD    PiEZOpenDevice();
	DLLEXPORT DWORD    PiEZCloseDevice();
	DLLEXPORT DWORD    PiEZGetStatus(PriStatStr *statStruct);
	DLLEXPORT DWORD    PiEZControlLEDBlink(BYTE color, BYTE blinkOptions);
	DLLEXPORT DWORD    PiEZSetDeskew(BYTE tolerance);
	DLLEXPORT DWORD    PiEZPerformScan(BYTE color, WORD dpi, BYTE scanType, WORD waitTime);
  DLLEXPORT DWORD    PiEZWaitForScanComplete();
	DLLEXPORT DWORD    PiEZCancelScanWait();
	DLLEXPORT DWORD    PiEZGetOrientation(LPBYTE docSide, BYTE mode);
	DLLEXPORT DWORD    PiEZGetLastDocument(BYTE format, BYTE docSide, BYTE rotation, LPDWORD recLen, LPBYTE recBuf);
	DLLEXPORT DWORD    PiEZGetLastMICR(DWORD scheme, DWORD font, LPDWORD recLen, LPBYTE recBuf);
	DLLEXPORT DWORD    PiEZGetPropLastMICRDecodeScheme(LPDWORD scheme);
	DLLEXPORT DWORD    PiEZGetPropLastMICRDecodeFont(LPDWORD font);
	DLLEXPORT DWORD    PiEZRewind();
	DLLEXPORT DWORD    PiEZFwdFeedAndStamp(WORD stampPosition);
	DLLEXPORT DWORD    PiEZEjectDocument(BYTE direction);
	DLLEXPORT DWORD    PiEZAcceleratedRearEject();
	DLLEXPORT DWORD    PiEZStampAndEject(WORD stampPosition, BYTE direction);
	DLLEXPORT DWORD    PiEZSetDebugMode(BYTE debugMode);
	//--------------------- End EZ Commands --------------------------------------


	//--------------------- Start Cortex Specific ------------------------------------
	DLLEXPORT DWORD    PiScanCortexSetSerialNum(LPBYTE SerialNum);
	DLLEXPORT DWORD    PiScanCortexSetUSBDescriptorMode(BYTE descriptorMode);
	DLLEXPORT DWORD    PiScanCortexSetSkew(BYTE SkewTolerance, BYTE SkewReject);
	DLLEXPORT DWORD	   PiScanCortexSetDoubleFeedDetection(BYTE enableState);
	DLLEXPORT DWORD	   PiScanCortexSetDoubleFeedTolerances(WORD paperPresenceTrigger, WORD doublePaperPresenceTrigger, WORD doubleFeedDistanceTrigger, BYTE reserved1, BYTE reserved2);
	DLLEXPORT DWORD    PiScanCortexUpdateFirmware(BYTE* md5, BYTE* firmware, int firmwareSize);
	DLLEXPORT DWORD    PiScanCortexAdjustUVCutoff(BYTE UVThreshold);
	DLLEXPORT DWORD	   PiScanCortexProcessWatermark(BYTE processLevel);
	//--------------------- End Cortex Specific ------------------------------------
}

// These defines can be used for orientation if MICR characters are present
#define PRIBE_ORIENT_UNKNOWN 0
#define PRIBE_ORIENT_FACEDWN_RIGHT 1    /* MICR is face down and to the right edge  */
#define PRIBE_ORIENT_FACEDWN_LEFT  2    /* MICR is face down and to the left edge   */
#define PRIBE_ORIENT_FACEUP_RIGHT  3    /* MICR is face up and to the right edge    */
#define PRIBE_ORIENT_FACEUP_LEFT   4    /* MICR is face up and to the left edge     */

//------------------- Start Status Values ---------------------
#define PrsStat_OK					0					// generated by device
#define PrsStat_JAM					1
#define PrsStat_NoBuf				2
#define PrsStat_ParamNA				3
#define PrsStat_ParamFail			4
#define PrsStat_TagFail				5
#define PrsStat_InProgress			6
#define PrsStat_OpFail				7
#define PrsStat_TimeOut				8
#define PrsStat_InvBuf				9
#define PrsStat_DocLength			10
#define PrsStat_NoImage				11
#define PrsStat_SmallCrop			12
#define PrsStat_Reset				13
#define PrsStat_MotorTime			14
#define PrsStat_NoMICR				15
#define PrsStat_CoverOpen			16
#define PrsStat_DocumentSize		17
#define PrsStat_NotImplemented		18
#define PrsStat_NoDocument			19
#define PrsStat_Skew				20
#define PrsStat_NotWaiting			21
#define PrsStat_MICROverFlow		22
#define PrsStat_LowPower			23
#define PrsStat_XmitNA				24
#define PrsStat_Warmup				25
#define PrsStat_NoSwipe				26
#define PrsStat_BMPError			27
#define PrsStat_TooShort			28
#define PrsStat_DoubleFeed			29
#define PrsStat_StackerError		30
#define PrsStat_NotConnected		31				// these values are generated by API
#define PrsStat_NotOpen				32
#define PrsStat_DataOverflow		33
#define PrsStat_SmallBuf			34
#define PrsStat_NotCompatible		35				// Firmware not compatible
#define PrsStat_FWDownload			36
#define PrsStat_BadSizeBuffer		37
#define PrsStat_NoAcknowledge		38
#define PrsStat_Illogical			42				// catch all during code implementation
#define PrsStat_Lockup				50
#define PrsStat_SysErr				51				// bad news in OS function
#define PrsStat_MICRDecodeFwdErr	52
#define PrsStat_MICRDecodeRevErr	53
#define PrsStat_MICRSecLibErr		54
#define PrsStat_MICRDecodeCMCErr	55
#define PrsStat_ThreadErr			56
#define PrsStat_DataRetrieveErr		57
#define	PrsStat_UnexpectedDataErr	58
#define	PrsStat_InternalMemoryErr	59
#define	PrsStat_FileErr				60
#define	PrsStat_OutputErr			61
// values 51-99 are used to pinpoint which system function failed: treat all >50 as SysErr
//------------------- End Status Values -----------------------

#endif /* PISCAN_H_ */