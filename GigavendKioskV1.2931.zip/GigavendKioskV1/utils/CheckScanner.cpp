#include "CheckScanner.h"
#include <QDebug>
#include "PIScan.h"

// --- ScannerWorker Implementation ---

ScannerWorker::ScannerWorker(QObject *parent) : QObject(parent) {}

void ScannerWorker::doScan() {
    qInfo() << "[Pertech] ScannerWorker::doScan() starting (check)";

    PriStatStr status {};
    // Brief pre-wait (~2.5s) for RIGHT path sensor (bit 0) so we don't fail
    // if the user inserts immediately after pressing Scan.
    const int sensorWaitMs = 2500;
    const int stepMs = 100;
    int waited = 0;
    for (;;) {
        DWORD r = PiEZGetStatus(&status);
        if (r == 0 && (status.ub_sens & 0x01)) {
            qInfo() << "[Pertech] right sensor active; proceeding to scan";
            break;
        }
        if (waited >= sensorWaitMs) {
            qWarning() << "[Pertech] pre-wait timeout; no document on right path";
            emit scanFailed("Insert check on right path and press Scan.");
            return;
        }
        QThread::msleep(stepMs);
        waited += stepMs;
    }

    // ---- Perform scan with retry-on-media-errors (20, 28, 29) ----
    // Keep names/values you already use elsewhere.
    const int maxAttempts = 3;         // small, bounded retry
    const int retryBackoffMs = 200;    // brief pause before retry
    int attempt = 0;

    for (attempt = 1; attempt <= maxAttempts; ++attempt) {
        qInfo() << "[Pertech] PiEZPerformScan"
                << " color=" << m_CHECK_SCAN_COLOR
                << " dpi="   << m_CHECK_SCAN_DPI
                << " type="  << m_CHECK_SCAN_TYPE
                << " wait="  << m_SCAN_WAIT_TIME;

        DWORD scan_result = PiEZPerformScan(m_CHECK_SCAN_COLOR,
                                            m_CHECK_SCAN_DPI,
                                            m_CHECK_SCAN_TYPE,
                                            m_SCAN_WAIT_TIME);
        if (scan_result != 0) {
            // Retryable media conditions per Pertech:
            // 20 = Skew, 28 = Too Short, 29 = Double Feed
            if (scan_result == 20 || scan_result == 28 || scan_result == 29) {
                qWarning() << "[Pertech] PiEZPerformScan failed with media error"
                           << scan_result << "— ejecting and retrying"
                           << attempt << "/" << maxAttempts;
                (void)PiEZEjectDocument(m_CHECK_EJECT_DIR);
                QThread::msleep(retryBackoffMs);
                if (attempt < maxAttempts) {
                    continue;   // retry perform scan
                }
            }
            // Non-retryable, or out of attempts
            emit scanFailed(QString("PiEZPerformScan failed: %1").arg(scan_result));
            return;
        }

        DWORD rc = PiEZWaitForScanComplete();
        if (rc == 0) {
            // Completed successfully; break out to fetch images.
            break;
        }

        // Retryable media conditions per Pertech (wait phase too)
        if (rc == 20 || rc == 28 || rc == 29) {
            qWarning() << "[Pertech] PiEZWaitForScanComplete failed with media error"
                       << rc << "— ejecting and retrying"
                       << attempt << "/" << maxAttempts;

            (void)PiEZEjectDocument(m_CHECK_EJECT_DIR);
            QThread::msleep(retryBackoffMs);

            if (attempt < maxAttempts) {
                continue;      // retry full scan sequence
            }
        }

        // Non-retryable error or out of attempts
        emit scanFailed(QString("PiEZWaitForScanComplete failed: %1").arg(rc));
        return;
    }

    // ----- Fetch images and MICR -----
    DWORD max_image_size = 52428800; // 50 MB buffer
    LPBYTE rec_buf = new BYTE[max_image_size];
    QByteArray frontJpeg, backJpeg, frontTiff, backTiff;
    QString micrData;

    // Get front JPEG
    DWORD rec_len = max_image_size;
    if (PiEZGetLastDocument(m_CHECK_JPEG_FORMAT, m_CHECK_FRONT, m_CHECK_FR_ROTATION, &rec_len, rec_buf) == 0) {
        frontJpeg = QByteArray(reinterpret_cast<const char*>(rec_buf), rec_len);
    } else {
        emit scanFailed("Failed to retrieve front JPEG image.");
        delete[] rec_buf;
        return;
    }

    // Get back JPEG
    rec_len = max_image_size;
    if (PiEZGetLastDocument(m_CHECK_JPEG_FORMAT, m_CHECK_BACK, m_CHECK_BK_ROTATION, &rec_len, rec_buf) == 0) {
        backJpeg = QByteArray(reinterpret_cast<const char*>(rec_buf), rec_len);
    } else {
        emit scanFailed("Failed to retrieve back JPEG image.");
        delete[] rec_buf;
        return;
    }

    // Get front TIFF
    rec_len = max_image_size;
    if (PiEZGetLastDocument(m_CHECK_TIFF_FORMAT, m_CHECK_FRONT, m_CHECK_FR_ROTATION, &rec_len, rec_buf) == 0) {
        frontTiff = QByteArray(reinterpret_cast<const char*>(rec_buf), rec_len);
    } else {
        emit scanFailed("Failed to retrieve front TIFF image.");
        delete[] rec_buf;
        return;
    }

    // Get back TIFF
    rec_len = max_image_size;
    if (PiEZGetLastDocument(m_CHECK_TIFF_FORMAT, m_CHECK_BACK, m_CHECK_BK_ROTATION, &rec_len, rec_buf) == 0) {
        backTiff = QByteArray(reinterpret_cast<const char*>(rec_buf), rec_len);
    } else {
        emit scanFailed("Failed to retrieve back TIFF image.");
        delete[] rec_buf;
        return;
    }

    // Get MICR (best-effort)
    DWORD micr_size = 81;
    rec_len = micr_size;
    if (PiEZGetLastMICR(MICR_SCHEME, MICR_FONT, &rec_len, rec_buf) == 0 && rec_len > 0) {
        micrData = QString::fromLatin1(reinterpret_cast<const char*>(rec_buf), rec_len);
    }

    PiEZEjectDocument(m_CHECK_EJECT_DIR);
    delete[] rec_buf;

    // Emit all 5 results (unchanged signature)
    emit resultReady(frontJpeg, backJpeg, frontTiff, backTiff, micrData);
}


// --- CheckScanner Implementation ---

CheckScanner::CheckScanner(QObject *parent) : QObject(parent)
{
    // create worker
    auto *worker = new ScannerWorker();
    worker->moveToThread(&workerThread);

    // when scanner is requested, run the worker’s doScan() on its thread
    connect(this, &CheckScanner::scanRequested, worker, &ScannerWorker::doScan, Qt::QueuedConnection);

    // bubble up results (match actual worker signal names)
    connect(worker, &ScannerWorker::resultReady,
            this,   &CheckScanner::scanSuccess,  Qt::QueuedConnection);
    connect(worker, &ScannerWorker::scanFailed,
            this,   &CheckScanner::scanFailure,  Qt::QueuedConnection);

    // tidy up the worker when the thread exits
    connect(&workerThread, &QThread::finished, worker, &QObject::deleteLater);

    // start the thread
    workerThread.start();
}

CheckScanner::~CheckScanner() {
    workerThread.quit();
    workerThread.wait();
}

void CheckScanner::startScan()
{
    qInfo() << "[Pertech] CheckScanner::startScan() -> emit scanRequested()";
    emit scanRequested();
}

bool CheckScanner::connectScanner() {
    DWORD rc = PiEZOpenDevice();
    if (rc == 0) {
        m_connected = true;
        qDebug() << "Pertech check scanner connected.";
        emit scannerConnected(true);
        return true;
    }
    m_connected = false;
    qDebug() << "Failed to connect to Pertech check scanner.";
    emit scannerConnected(false);
    return false;
}

bool CheckScanner::softRearm()
{
    // Cancel any pending waits (safe even if none active)
    (void)PiEZCancelScanWait();

    // Soft reset clears internal buffers/state without USB disconnect
    DWORD rc = PiScanSoftResetScanner();
    if (rc == 0) {
        qDebug() << "[Pertech] Soft reset complete; device state is clean.";
        return true;
    }

    qWarning() << "[Pertech] Soft reset failed, rc=" << rc;
    return false;
}

void CheckScanner::disconnectScanner() {
    if (m_connected) {
        PiEZCloseDevice();
        qDebug() << "Pertech check scanner disconnected.";
    }
}
