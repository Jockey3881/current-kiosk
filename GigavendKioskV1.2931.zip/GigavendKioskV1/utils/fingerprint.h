#ifndef FINGERPRINT_H
#define FINGERPRINT_H

#include <QString>
#include <dpfpdd.h>
#include <dpfj.h>
#include <dpfj_compression.h>
#include <dpfj_quality.h>

class CashingWindow;
class FingerPrint
{
public:
    FingerPrint(CashingWindow* cashingWnd);
    virtual ~FingerPrint();

    int CaptureFinger();
    void cancelFingerPrint();
    QString getError() const {
        return m_Error;
    }

private:
    void print_error(const char* szFunctionName, int nError);
    int IsDeviceReady(unsigned int nOrigImageSize);
    bool SelectAndOpenReader(char* szReader, size_t nReaderLen);
    int CaptureFinger(unsigned char** ppFt, unsigned int* pFtSize);
    int Enrollment();
public:
    bool m_bCancel;

private:
    DPFPDD_DEV m_hReader; //handle of the selected reader
    bool m_canCaptureImage;
    bool m_canStreamImage;
    CashingWindow* m_cashingWnd;
    QString m_Error;
    DPFJ_FMD_FORMAT m_DPFJ_FMD;
    int m_dpi;
};

#endif // FINGERPRINT_H
