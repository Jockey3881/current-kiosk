#ifndef CHECKSCANNER_H
#define CHECKSCANNER_H

#include <QObject>
#include <QByteArray>
#include <QString>
#include <QThread>
#include "PIScan.h"

// Worker class to run scan on a separate thread
class ScannerWorker : public QObject
{
    Q_OBJECT
public:
    explicit ScannerWorker(QObject *parent = nullptr);

public slots:
    void doScan();

signals:
    // This signal now has 5 arguments
    void resultReady(QByteArray frontJpeg, QByteArray backJpeg, QByteArray frontTiff, QByteArray backTiff, QString micrData);
    void scanFailed(QString error);

private:
    // Scanner settings from Pertech template
    BYTE m_CHECK_SCAN_COLOR     = 0x00; // Grayscale
    WORD m_CHECK_SCAN_DPI       = 200;  // MODIFIED: Lowered DPI to 200
    BYTE m_CHECK_SCAN_TYPE      = 0x00; // Check Scan
    WORD m_SCAN_WAIT_TIME       = 80;
    BYTE m_CHECK_JPEG_FORMAT    = 0x07;
    BYTE m_CHECK_TIFF_FORMAT    = 0x01;
    BYTE m_CHECK_FRONT          = 0x01;
    BYTE m_CHECK_BACK           = 0x02;
    BYTE m_CHECK_BK_ROTATION    = 0x02;
    BYTE m_CHECK_FR_ROTATION    = 0x01;
    BYTE m_CHECK_EJECT_DIR      = 0x01;
    DWORD MICR_SCHEME           = 0x00;
    DWORD MICR_FONT             = 0x00;
};

// Main controller class
class CheckScanner : public QObject
{
    Q_OBJECT
public:
    explicit CheckScanner(QObject *parent = nullptr);
    ~CheckScanner();
    Q_INVOKABLE bool connectScanner();
    Q_INVOKABLE bool softRearm();
    Q_INVOKABLE bool isConnected() const { return m_connected; }
   
    void disconnectScanner();

public slots:
    void startScan();

signals:
    // This signal now has 5 arguments
    void scanSuccess(QByteArray frontJpeg, QByteArray backJpeg, QByteArray frontTiff, QByteArray backTiff, QString micrData);
    void scanFailure(QString error);
    void scanRequested();
    void scannerConnected(bool ok);
private:
    QThread workerThread;
    bool m_connected = false;
};

#endif // CHECKSCANNER_H
